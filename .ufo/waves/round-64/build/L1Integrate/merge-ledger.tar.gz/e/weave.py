import re,subprocess
s=open('.ufo/waves/round-64/build/L1Integrate/e/next-table.md').read()
def rep(a,b):
    global s
    assert a in s, a[:90]
    s=s.replace(a,b,1)
out=subprocess.run(['bash','/home/vgpnk/Projects/shokunin/kumitate-shokunin/scripts/jj-seat-demo.sh'],capture_output=True,text=True,cwd='/tmp').stdout
keys=[l[len('JJ_SEAT: '):].strip() for l in out.split('\n') if l.startswith('JJ_SEAT: ')]
V=dict(k.split('=',1) for k in keys)
assert len(keys)==27,len(keys)
rep("coverage-map: isolation substrates for parallel agents (git worktrees, harness isolation backends) (PROVINCE.md §Frontier)","coverage-map: isolation substrates for parallel agents (git worktrees, harness isolation backends, jj workspaces) (PROVINCE.md §Frontier)")
rep("prints\n21 outcome keys","prints\n27 outcome keys")
rep("(the tree of the seat's\npreviously recorded working-copy commit against the tree of its new working-copy commit — not the kind of operation and not\nunsnapshotted files on disk)","(the tree of the seat's\npreviously recorded working-copy commit against the tree of its new working-copy commit — not the kind of operation and not\nunsnapshotted files on disk; [INFERENCE], a fit to the measured outcomes, see Limits)")
i=s.index("## Demo outcomes"); j=s.index("## Located quotes")
s=s[:i]+"## Demo outcomes\n\n"+"\n".join("- "+k for k in keys)+"\n\n"+s[j:]
anchor="The working trees are separate and the log is shared."
extra=f"""Six keys added after the first wave pin what the staleness rule does and does not turn on. A describe keeps the change id and
changes the commit id (`rewrite_preserves_change_id_changes_commit_id={V['rewrite_preserves_change_id_changes_commit_id']}`), so an identifier captured before the
rewrite is the change id, never the commit id. After a tree-changing rewrite, `update-stale` keeps the seat's file and merges the squashed
one (`update_stale_treechange_seat_file={V['update_stale_treechange_seat_file']}`). The fresh/stale outcome follows the seat's last **snapshotted** tree, not the live
files: an unsnapshotted edit does not stale a seat on a describe (`pending_edit_on_tree_preserving_rewrite_seat_state={V['pending_edit_on_tree_preserving_rewrite_seat_state']}`) and an
unsnapshotted deletion that makes the disk equal the new commit does not save it from an abandon
(`pending_delete_matching_abandoned_tree_seat_state={V['pending_delete_matching_abandoned_tree_seat_state']}`); a squash of the seat's commit into its parent leaves the seat fresh
(`squash_seat_into_parent_seat_state={V['squash_seat_into_parent_seat_state']}`). A stale seat can still abandon a peer's commit when it passes `--ignore-working-copy`
(`stale_seat_iwc_can_abandon_peer={V['stale_seat_iwc_can_abandon_peer']}`): staleness refuses unflagged commands, it is not an access control.

"""
rep(anchor,extra+anchor)
i=s.index("**Version skew.**"); j=s.index("## Decision table")
skew="""**Version skew.** S198 and S200 cite the immutable `v0.46.0` jj docs (`latest` served the same bytes on 2026-10-25), while S199 is
unversioned Firefox contributor documentation and the host binary is jj 0.45.1. The concurrency page is identical in both
versions (S198's v0.45.1 HTML rendering and raw markdown are byte-identical to v0.46.0); the working-copy page differs in
§Workspaces: v0.46.0 rewrites the `jj workspace forget` sentence and adds `jj workspace remove`, which is not a subcommand of the
host's jj (`jj workspace --help`, K64ExecRowsDraft, 2026-10-25). S067 pins the raw v0.45.1 `docs/working-copy.md` source of the same page.
Measured on both binaries (K64R2ExecJjOtherVersion: the official `jj 0.46.0-7d382314…` release binary run from a scratch directory, host
untouched): the 27 `JJ_SEAT:` keys are identical on 0.45.1 and 0.46.0 once the demo pins `jj workspace add --no-colocate` where the flag exists;
**without** it, 0.46.0 colocates every seat as a Git worktree of the default repository (`seat_has_git_dir` reads `yes`) because `git.colocate`
defaults to true there — a seat then has plain git and can write refs into the default repository. The demo prints `JJ_SKEW:` lines (not compared by
the counter) for the version-dependent surface: on 0.46.0 `jj workspace remove` removes the seat directory, records an operation, refuses the
main workspace and a stale seat, and recovers a seat's unsnapshotted change through the snapshot it takes first; on 0.45.1 the subcommand is absent.

"""
s=s[:i]+skew+s[j:]
rep("- **One jj version, sequential drivers.** Measured on jj 0.45.1 only, with two or three workspaces","- **Two jj versions, sequential drivers.** Measured on jj 0.45.1 (host) and re-run on 0.46.0 (`JJ_SKEW:` lines), with two or three workspaces")
rep("- **What the counter cannot tell.**","""- **Auto-track.** The demo runs with jj's default `snapshot.auto-track` (everything), so a new file is snapshotted by the first unflagged
  command (`seat_snapshot_in_shared_op_log=1`); the lane's operating rule is `snapshot.auto-track = "none()"` (souji
  `corpus/knowledge/jj-colocation-receipts.md`, M1 of `agent-isolation-substrates.md`), under which an unflagged command on a new path adds no
  snapshot. The staleness outcomes were measured with auto-track on; they were not re-run with it off.
- **Git-side effects of a colocated default workspace** are souji's ground (`jj-colocation-receipts.md`) and are not restated here; the entry
  records only that a seat created by `jj workspace add` has no git directory on jj 0.45.1 and, on 0.46.0 without `--no-colocate`, has a Git worktree.
- **A stale seat "cannot act" only for unflagged jj commands.** `stale_seat_iwc_can_abandon_peer=yes`, and a stale seat's shell still writes
  files: staleness is not a sandbox.
- **What the counter cannot tell.**""")
open('corpus/knowledge/jj-workspace-seat-containment.md','w').write(s)
print('ok')

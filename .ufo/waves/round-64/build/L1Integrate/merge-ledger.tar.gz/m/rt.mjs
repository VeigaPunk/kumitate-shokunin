#!/usr/bin/env node
/**
 * report-receipt-diff.mjs — diff a round report against the committed receipts it cites.
 * Contract: kumitate-report-receipt-diff-v2 (round 64, capability report-receipt-diff;
 * considerthese/2026-10-25.md idea 2: "diff reports against receipts").
 *
 *   node scripts/report-receipt-diff.mjs --lane <lane-dir> --round N --report <file> [--rev <lane-rev>] [--fleet <fleet-dir>]
 *   node scripts/report-receipt-diff.mjs --selftest
 */
import { spawnSync } from "node:child_process";
import { existsSync, lstatSync, mkdtempSync, mkdirSync, readFileSync, readdirSync, realpathSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const REQUIRED = [
  ["Work performed", /^ {0,3}#{1,6}[ \t]+\**[ \t]*Work performed/im],
  ["Landed changes", /^ {0,3}#{1,6}[ \t]+\**[ \t]*Landed changes/im],
  ["Before → after measurements", /^ {0,3}#{1,6}[ \t]+\**[ \t]*Before[ \t]*(?:→|->)[ \t]*after measurements/im],
  ["Sources & frontier", /^ {0,3}#{1,6}[ \t]+\**[ \t]*Sources[ \t]*&[ \t]*frontier/im],
  ["Trend verdicts", /^ {0,3}#{1,6}[ \t]+\**[ \t]*Trend verdicts/im],
  ["SHONEN", /^ {0,3}#{1,6}[ \t]+\**[ \t]*SHONEN/im],
];
const PLACEHOLDER = /__[A-Za-z][A-Za-z0-9_]{1,}__|\bLANE_HASH\b|\bTBD\b|\{\{[A-Za-z][A-Za-z0-9_]*\}\}|\bX{4,}\b|\bto\s+be\s+filled\b|<(?:measured|measured_rev|tip_hash|rev_hash|placeholder|tbd|todo)>/gi;
const TALLY = /(?:^|(?<![A-Za-z0-9]))([A-Za-z][A-Za-z0-9_]*_(?:HELD|UNMET))\s+held=(\d+)\/(\d+)(?![0-9/])/g;
const TALLY_LOWER = /(?:^|(?<![A-Za-z0-9_]))([a-z][a-z0-9]*\d[a-z0-9_]*_(?:held|unmet))\s+held=(\d+)\/(\d+)(?![0-9/])/gi;
const RECEIPT_PATH = (round) => new RegExp(`\\.ufo/waves/round-${round}/(?:base|close)/[A-Za-z0-9._*/-]*`, "g");
const REL_RECEIPT = /(?<![\w./-])(?:base|close)\/[A-Za-z0-9._*/-]+/g;
const HASH = /\b[0-9a-fA-F]{39,40}\b(?![\u2026])/g;
// Scan copy: invisible chars, inline markdown/table formatting, and spaced held=/checks= operators normalised
// without corrupting path slashes or prose outside tallies.
const scan = (s) => s
  .replace(/[\u00AD\u034F\u200B-\u200F\u2060-\u2064\uFEFF]/g, "")
  .replace(/\u00A0/g, " ")
  .replace(/\|/g, " ")
  .replace(/([A-Za-z0-9_])[\`*:]+(\s+held\b)/gi, "$1$2")
  .replace(/[\`*]+(held\s*=\s*\d+\s*\/\s*\d+)[\`*]+/gi, "$1")
  .replace(/\b(held|checks)[ \t]*=[ \t]*/gi, "$1=")
  .replace(/(held=\d+)[ \t]*\/[ \t]*(\d+)/gi, "$1/$2");
// Prose copy: CommonMark fenced blocks blanked (fence char & length matched; inline triple-backtick code spans ignored).
const unfence = (text) => {
  let openCh = ""; let openLen = 0;
  return text.split("\n").map((l) => {
    if (!openLen) {
      const m = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(l);
      if (m && !(m[1][0] === "`" && m[2].includes("`"))) { openCh = m[1][0]; openLen = m[1].length; return ""; }
      return l;
    }
    const c = /^ {0,3}(`{3,}|~{3,})[ \t]*$/.exec(l);
    if (c && c[1][0] === openCh && c[1].length >= openLen) { openCh = ""; openLen = 0; }
    return "";
  }).join("\n");
};
const tallyKey = (label, x, y) => `${label.toUpperCase()} held=${x}/${y}`;

function git(dir, args) { return spawnSync("git", ["-C", dir, ...args], { encoding: "utf8", maxBuffer: 256 * 1024 * 1024 }); }

function walkWorktree(baseDir, relPrefix, outMap) {
  const full = join(baseDir, relPrefix);
  if (!existsSync(full)) return;
  for (const n of readdirSync(full)) {
    const p = join(full, n);
    const rel = `${relPrefix}/${n}`;
    try {
      const st = lstatSync(p);
      if (st.isSymbolicLink()) continue;
      if (st.isDirectory()) walkWorktree(baseDir, rel, outMap);
      else if (st.isFile()) outMap.set(rel, readFileSync(p, "utf8").replace(/\r\n?/g, "\n"));
    } catch { /* unreadable */ }
  }
}

export function diffReport({ lane, round, reportText, rev, fleet }) {
  const findings = [];
  const add = (id, detail) => findings.push({ id, detail });
  const text = reportText.replace(/\r\n?/g, "\n");
  const prose = unfence(text);
  for (const m of text.matchAll(PLACEHOLDER)) add("PLACEHOLDER", m[0]);
  for (const [name, re] of REQUIRED) if (!re.test(prose)) add("SECTION_MISSING", name);
  const sh = [...prose.matchAll(/^ {0,3}#{1,6}[ \t]+\**[ \t]*SHONEN/gim)];
  if (sh.length !== 1) add("SHONEN_COUNT", `headings=${sh.length}`);
  else {
    const level = sh[0][0].match(/^#+/)[0].trim().length;
    let boxes = 0; let bulletLines = 0;
    for (const l of prose.slice(sh[0].index).split("\n").slice(1)) {
      const h = /^ {0,3}(#{1,6})(?:[ \t]|\*)\s*\S/.exec(l);
      if (h && h[1].length <= level) break;
      if (/^\s*[-*]\s/.test(l)) {
        const b = (l.match(/`?\[[xX~ ]\]`?/g) || []).length;
        if (b > 0) { bulletLines += 1; boxes += Math.min(b, 2); }
      }
    }
    if (boxes < 4 || bulletLines < 2) add("SHONEN_COUNT", `boxes=${boxes}`);
  }
  const receiptNames = new Map();
  for (const d of ["base", "close"]) {
    const rel = `.ufo/waves/round-${round}/${d}`;
    if (rev) {
      const ls = git(lane, ["ls-tree", "-r", "-z", rev, "--", rel]);
      if (ls.status !== 0) continue;
      for (const row of ls.stdout.split("\0").filter(Boolean)) {
        const m = /^(\d{6}) \w+ [0-9a-f]+\t(.+)$/.exec(row);
        if (!m || m[1] === "120000") continue;
        const b = spawnSync("git", ["-C", lane, "show", `${rev}:${m[2]}`], { encoding: "utf8", maxBuffer: 256 * 1024 * 1024 });
        if (b.status === 0) receiptNames.set(m[2], b.stdout.replace(/\r\n?/g, "\n"));
      }
    } else {
      walkWorktree(lane, rel, receiptNames);
    }
  }
  const stripPunct = (raw) => raw.replace(/(?:\.{3,}|[,;:]+|(?<!\.)\.(?!\.))+$/, "");
  const cited = (s) => [...new Set([...[...s.matchAll(RECEIPT_PATH(round))].map((x) => stripPunct(x[0])), ...[...s.matchAll(REL_RECEIPT)].map((x) => stripPunct(`.ufo/waves/round-${round}/${x[0]}`))])];
  const globRe = (g) => new RegExp(`^${g.split("**/").map((seg) => seg.split("**").map((part) => part.split("*").map((x) => x.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join("[^/]*")).join(".*")).join("(?:.+/)?")}$`);
  const isPath = (p) => Boolean(p) && !p.split("/").some((seg) => seg === ".." || seg === ".");
  const matchSpec = (sp, file) => (sp.endsWith("/") ? file.startsWith(sp) : sp.includes("*") ? globRe(sp).test(file) : sp === file);
  for (const p of cited(text)) {
    if (!isPath(p)) { add("RECEIPT_MISSING", `${p} (escape-or-dir)`); continue; }
    if (p.endsWith("/")) {
      const under = [...receiptNames.keys()].filter((f) => f.startsWith(p));
      if (!under.length) add("RECEIPT_MISSING", `${p} (no receipt under it)`);
      else if (!under.some((f) => receiptNames.get(f).trim())) add("RECEIPT_EMPTY", p);
      continue;
    }
    if (p.includes("*")) {
      const matched = [...receiptNames.keys()].filter((f) => globRe(p).test(f));
      if (!matched.length) add("RECEIPT_MISSING", p);
      else if (!matched.some((f) => receiptNames.get(f).trim())) add("RECEIPT_EMPTY", p);
      continue;
    }
    if (!receiptNames.has(p)) add("RECEIPT_MISSING", p);
    else if (!receiptNames.get(p).trim()) add("RECEIPT_EMPTY", p);
  }
  const extractTallies = (line) => {
    const out = []; const seen = new Set();
    for (const re of [TALLY, TALLY_LOWER]) {
      for (const m of line.matchAll(re)) {
        if (seen.has(m.index)) continue;
        seen.add(m.index);
        out.push(m);
      }
    }
    return out.sort((a, b) => a.index - b.index);
  };
  const index = new Map();
  for (const [file, body] of receiptNames) {
    for (const line of scan(body).split("\n")) {
      for (const m of extractTallies(line)) {
        const key = tallyKey(m[1], m[2], m[3]);
        const c = /^[^\n;]*?\bchecks=(\d+)/i.exec(line.slice(m.index + m[0].length));
        if (!index.has(key)) index.set(key, []);
        index.get(key).push({ file, checks: c ? c[1] : null });
      }
    }
  }
  const joinedText = text.replace(/([A-Za-z0-9_]+_(?:HELD|UNMET))[ \t]*\n[ \t]*(held\b)/gi, "$1 $2");
  const rawLines = joinedText.split("\n");
  for (let i = 0; i < rawLines.length; i += 1) {
    const rawLine = rawLines[i];
    let lineCitations = cited(rawLine);
    if (!lineCitations.length && i + 1 < rawLines.length && !/^ {0,3}#/.test(rawLines[i + 1]) && cited(rawLines[i + 1]).length > 0 && !extractTallies(scan(rawLines[i + 1])).length) {
      lineCitations = cited(rawLines[i + 1]);
    }
    const clauses = rawLine.split(";");
    const multiClauseScoped = clauses.length > 1 && clauses.some((cl) => cited(cl).length > 0);
    for (const rawClause of (multiClauseScoped ? clauses : [rawLine])) {
      const clauseCitations = multiClauseScoped ? cited(rawClause) : lineCitations;
      const scannedClause = scan(rawClause);
      for (const m of extractTallies(scannedClause)) {
        const key = tallyKey(m[1], m[2], m[3]);
        if (clauseCitations.some((sp) => !isPath(sp))) { add("TALLY_UNRECEIPTED", key); continue; }
        const hits = (index.get(key) || []).filter((h) => !clauseCitations.length || clauseCitations.some((sp) => matchSpec(sp, h.file)));
        if (!hits.length) { add("TALLY_UNRECEIPTED", key); continue; }
        const c = /^[^\n;]*?\bchecks=(\d+)/i.exec(scannedClause.slice(m.index + m[0].length));
        if (c && !hits.some((h) => h.checks !== null && h.checks === c[1])) add("TALLY_CHECKS_MISMATCH", `${key} checks=${c[1]}`);
      }
    }
  }
  const headRes = rev ? null : git(lane, ["rev-parse", "--verify", "HEAD^{commit}"]);
  const tip = rev || (headRes.status === 0 ? headRes.stdout.trim() : null);
  const urlStripped = text.replace(/(?:https?:\/\/|\b(?:github|gitlab)\.com\/)[^\s)\]>`]+/gi, "");
  for (const raw of new Set(urlStripped.match(HASH) || [])) {
    const h = raw.toLowerCase();
    const inLane = git(lane, ["cat-file", "-e", `${h}^{commit}`]).status === 0;
    const inFleet = fleet && git(fleet, ["cat-file", "-e", `${h}^{commit}`]).status === 0;
    if (!inLane && !inFleet) { add("HASH_DEAD", raw.length === 40 ? raw : `${raw} (len=${raw.length})`); continue; }
    if (inLane && tip && git(lane, ["merge-base", "--is-ancestor", h, tip]).status !== 0) add("HASH_ORPHAN", h);
  }
  return findings;
}

function render(findings, meta) {
  if (!findings.length) return { code: 0, out: `REPORT_RECEIPT: CLEAN (${meta})\n` };
  const ids = [...new Set(findings.map((f) => f.id))].join(",");
  return { code: 1, out: `REPORT_RECEIPT: DRIFT ${ids} (${meta})\n${findings.map((f) => `${f.id} ${f.detail}`).join("\n")}\n` };
}

function selftest() {
  const results = [];
  const t = (name, ok) => results.push([name, ok]);
  const T = mkdtempSync(join(tmpdir(), 'rrd-self.'));
  const D = realpathSync(T);
  const g = (...a) => spawnSync('git', ['-C', D, '-c', 'user.name=fixture', '-c', 'user.email=fixture@example.invalid', ...a], { encoding: 'utf8' });
  if (g('init', '-q').status !== 0) { rmSync(T, { recursive: true, force: true }); process.stdout.write('REPORT_RECEIPT_SELFTEST: FAIL (git unavailable)\n'); process.exit(1); }
  if (git(D, ['rev-parse', '--show-toplevel']).stdout.trim() !== D) { process.stdout.write('REPORT_RECEIPT_SELFTEST: FAIL (fixture root)\n'); process.exit(1); }
  mkdirSync(join(D, '.ufo/waves/round-9/close'), { recursive: true });
  mkdirSync(join(D, '.ufo/waves/round-9/base'), { recursive: true });
  writeFileSync(join(D, '.ufo/waves/round-9/close/p-tip.txt'), 'X9_HELD held=3/3 checks=3 rev=abc rule=X9\n');
  writeFileSync(join(D, '.ufo/waves/round-9/base/p-base.txt'), 'X9_UNMET held=0/3 checks=3 rev=abc rule=X9\n');
  // ratchet fixture (round-64 wave-1 forgery controls k15..k18): a plan target in a base file, a superseded close
  // receipt, a receipt line that carries another label's tally, an empty receipt, and a receipt that is a symlink
  // out of the receipt tree.
  writeFileSync(join(D, '.ufo/waves/round-9/base/p-target.txt'), 'W9_HELD held=4/4 target=plan\n');
  writeFileSync(join(D, '.ufo/waves/round-9/close/r-tip.txt'), 'X9_HELD held=9/9 checks=9 rev=ccc rule=X9\n');
  writeFileSync(join(D, '.ufo/waves/round-9/close/s-tip.txt'), 'X9_HELD held=1/3 checks=3 rev=ddd rule=X9 prior X8_HELD held=7/7\n');
  writeFileSync(join(D, '.ufo/waves/round-9/close/empty.txt'), '');
  writeFileSync(join(D, '.ufo/outside.txt'), 'X9_HELD held=3/3 checks=3 rev=eee rule=X9\n');
  symlinkSync('../../../outside.txt', join(D, '.ufo/waves/round-9/close/link.txt'));
  writeFileSync(join(D, 'f.txt'), 'a');
  g('add', '-A'); g('commit', '-q', '-m', 'one');
  const c1 = g('rev-parse', 'HEAD').stdout.trim();
  g('checkout', '-q', '-b', 'side'); writeFileSync(join(D, 'g.txt'), 'b'); g('add', '-A'); g('commit', '-q', '-m', 'side');
  const orphan = g('rev-parse', 'HEAD').stdout.trim();
  g('checkout', '-q', '-'); g('checkout', '-q', '-B', 'main2', c1);
  const body = (extra = '', skip = '') => [
    '# report', skip === 'wp' ? '' : '## Work performed', 'x', '## Landed changes', 'x', '## Before → after measurements',
    'X9_UNMET held=0/3 base (`.ufo/waves/round-9/base/p-base.txt`); X9_HELD held=3/3 tip (`.ufo/waves/round-9/close/p-tip.txt`)', '## Sources & frontier', 'x', '## Trend verdicts', 'x',
    skip === 'sh' ? '' : '## SHONEN', '- [~] a', '- [~] b', '- [ ] c', '- [~] d', extra,
  ].join('\n');
  const run = (text) => diffReport({ lane: D, round: 9, reportText: text, rev: c1, fleet: null });
  const ids = (text) => [...new Set(run(text).map((f) => f.id))].join(',');
  t('honest-clean', run(body()).length === 0);
  t('placeholder-measured', ids(body('rev __MEASURED__')) === 'PLACEHOLDER');
  t('placeholder-lane-hash', ids(body('LANE_HASH')) === 'PLACEHOLDER');
  t('placeholder-tbd', ids(body('tip TBD')) === 'PLACEHOLDER');
  t('placeholder-count', run(body('__A_B__ and __C_D__')).filter((f) => f.id === 'PLACEHOLDER').length === 2);
  t('tally-wrong-xy', ids(body('X9_HELD held=10/10')) === 'TALLY_UNRECEIPTED');
  t('tally-wrong-label', ids(body('Y9_HELD held=3/3')) === 'TALLY_UNRECEIPTED');
  t('tally-verdict-flip', ids(body('X9_UNMET held=3/3')) === 'TALLY_UNRECEIPTED');
  t('tally-bare-not-checked', run(body('held=10/10')).length === 0);
  t('receipt-missing', ids(body('see `.ufo/waves/round-9/close/none.txt`')) === 'RECEIPT_MISSING');
  t('receipt-present', run(body('see `.ufo/waves/round-9/base/p-base.txt`')).length === 0);
  t('hash-dead', ids(body('0123456789abcdef0123456789abcdef01234567')) === 'HASH_DEAD');
  t('hash-orphan', ids(body(orphan)) === 'HASH_ORPHAN');
  t('hash-live', run(body(c1)).length === 0);
  t('section-missing', ids(body('', 'wp')) === 'SECTION_MISSING');
  t('shonen-absent', /SHONEN_COUNT/.test(ids(body('', 'sh'))) && /SECTION_MISSING/.test(ids(body('', 'sh'))));
  t('shonen-twice', ids(body('## SHONEN\n- [~] a')) === 'SHONEN_COUNT');
  t('shonen-short', /SHONEN_COUNT/.test(ids(body().replace('- [~] d', ''))));
  t('round-scoped', diffReport({ lane: D, round: 8, reportText: body(), rev: c1, fleet: null }).some((f) => f.id === 'TALLY_UNRECEIPTED'));
  // Ratchet arms (round-64 wave-1 controls cases/k1..k19): every one of these lies read CLEAN on the first build.
  t('tally-spaced-eq', ids(body('X9_HELD held = 6 / 6')) === 'TALLY_UNRECEIPTED');
  t('tally-lowercase-label', ids(body('x9_HELD held=6/6')) === 'TALLY_UNRECEIPTED');
  t('tally-table-cell', ids(body('| X9_HELD | held=6/6 |')) === 'TALLY_UNRECEIPTED');
  t('tally-zero-width', ids(body('X9_\u200bHELD held=6/6')) === 'TALLY_UNRECEIPTED');
  t('tally-substring-bypass', ids(body('X9_HELD held=7/7')) === 'TALLY_UNRECEIPTED');
  t('tally-cited-mismatch', ids(body('X9_HELD held=9/9 (`.ufo/waves/round-9/close/p-tip.txt`)')) === 'TALLY_UNRECEIPTED');
  t('tally-checks-mismatch', ids(body('X9_HELD held=3/3 checks=9')) === 'TALLY_CHECKS_MISMATCH');
  t('tally-base-only', ids(body('W9_HELD held=4/4 (`.ufo/waves/round-9/close/p-tip.txt`)')) === 'TALLY_UNRECEIPTED');
  t('receipt-empty', ids(body('see `.ufo/waves/round-9/close/empty.txt`')) === 'RECEIPT_EMPTY');
  t('receipt-symlink', ids(body('see `.ufo/waves/round-9/close/link.txt`')) === 'RECEIPT_MISSING');
  t('receipt-escape', ids(body('see `.ufo/waves/round-9/close/p-tip.txt/../../../base/p-base.txt`')) === 'RECEIPT_MISSING');
  t('hash-uppercase-dead', ids(body('0123456789ABCDEF0123456789ABCDEF01234567')) === 'HASH_DEAD');
  t('hash-39-abbrev-dead', ids(body('0123456789abcdef0123456789abcdef0123456')) === 'HASH_DEAD');
  t('placeholder-braces', ids(body('measured at {{MEASURED_REV}}')) === 'PLACEHOLDER');
  t('placeholder-angle-measured', ids(body('the revision is <measured>')) === 'PLACEHOLDER');
  t('placeholder-xxxx', ids(body('the revision is XXXX')) === 'PLACEHOLDER');
  t('placeholder-to-be-filled', ids(body('the hash is to be filled')) === 'PLACEHOLDER');
  t('placeholder-lowercase-token', ids(body('the revision is __measured__')) === 'PLACEHOLDER');
  t('placeholder-command-args-clean', run(body('`node probe.mjs <lane> <rev> <tip>`')).length === 0);
  const fenceAll = ['# report', '```', '## Work performed', '## Landed changes', '## Before → after measurements', '## Sources & frontier', '## Trend verdicts', '## SHONEN', '- [~] a', '- [~] b', '- [ ] c', '- [~] d', '```'].join('\n');
  t('sections-in-fence', ids(fenceAll) === 'SECTION_MISSING,SHONEN_COUNT');
  const shonenFenced = ['# report', '## Work performed', 'x', '## Landed changes', 'x', '## Before → after measurements', 'x', '## Sources & frontier', 'x', '## Trend verdicts', 'x', '```', '## SHONEN', '- [~] a', '- [~] b', '- [ ] c', '- [~] d', '```'].join('\n');
  t('shonen-in-fence', ids(shonenFenced) === 'SECTION_MISSING,SHONEN_COUNT');
  const boxesElsewhere = ['# report', '## Work performed', 'x', '## Landed changes', 'x', '## Before → after measurements', 'x', '## Sources & frontier', 'x', '## Trend verdicts', 'x', '## SHONEN', '', '## Appendix', '- [~] a', '- [~] b', '- [ ] c', '- [~] d'].join('\n');
  t('shonen-boxes-outside-section', ids(boxesElsewhere) === 'SHONEN_COUNT');
  // wave-1 ratchet (L1 integration of K64ExecReceiptRealRun / K64ReviewTool findings)
  const bt = body().replace('- [~] a', '- `[~]` a').replace('- [~] b', '- `[~]` b');
  t('shonen-backticked-boxes', run(bt).length === 0);
  t('shonen-two-boxes-one-line', run(body().replace('- [~] a\n- [~] b', '- [~] a — [~] b')).length === 0);
  t('receipt-glob-match', run(body('see `.ufo/waves/round-9/close/p-*.txt`')).length === 0);
  t('receipt-glob-miss', ids(body('see `.ufo/waves/round-9/close/zz-*.txt`')) === 'RECEIPT_MISSING');
  t('receipt-dir-citation-ok', run(body('see `.ufo/waves/round-9/close/`')).length === 0);
  t('receipt-dir-citation-empty', ids(body('see `.ufo/waves/round-9/base/nope/`')) === 'RECEIPT_MISSING');
  t('hash-in-url-skipped', run(body('https://example.invalid/tree/0123456789abcdef0123456789abcdef01234567')).length === 0);
  const rf = join(T, 'r.md'); writeFileSync(rf, body());
  const cli = (...a) => spawnSync(process.execPath, [process.argv[1], '--lane', D, '--round', '9', '--report', rf, ...a], { encoding: 'utf8' });
  t('cli-rev-space-form-bad-rev', cli('--rev', 'deadbeef00').status === 2);
  t('cli-rev-equals-form-bad-rev', cli('--rev=deadbeef00').status === 2);
  t('cli-rev-equals-form-good-rev', cli(`--rev=${c1}`).status === 0);
  t('render-clean-exit', render([], 'm').code === 0 && render([{ id: 'PLACEHOLDER', detail: 'x' }], 'm').code === 1);
  rmSync(T, { recursive: true, force: true });
  const pass = results.filter(([, ok]) => ok).length;
  for (const [n, ok] of results) if (!ok) process.stdout.write(`FAIL ${n}\n`);
  process.stdout.write(`REPORT_RECEIPT_SELFTEST: ${pass === results.length ? 'PASS' : 'FAIL'} (${pass}/${results.length})\n`);
  process.exit(pass === results.length ? 0 : 1);
}


const rawArgv = process.argv.slice(2);
const isMain = (() => {
  if (!process.argv[1]) return false;
  try { return import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href || import.meta.url === pathToFileURL(resolve(process.argv[1])).href; }
  catch { return import.meta.url === pathToFileURL(resolve(process.argv[1])).href; }
})();
if (isMain) {
  if (rawArgv.length === 1 && rawArgv[0] === "--selftest") selftest();
  const opts = new Map();
  for (let i = 0; i < rawArgv.length; i += 1) {
    const a = rawArgv[i];
    if (a === "--selftest") { process.stderr.write("usage: report-receipt-diff.mjs --lane DIR --round N --report FILE [--rev REV] [--fleet DIR] | --selftest\n"); process.exit(64); }
    const eq = /^(--[a-z][a-z0-9-]*)=(.*)$/s.exec(a);
    if (eq) { opts.set(eq[1], eq[2]); continue; }
    if (a.startsWith("--")) {
      if (i + 1 >= rawArgv.length || rawArgv[i + 1].startsWith("--")) { opts.set(a, ""); }
      else { opts.set(a, rawArgv[i + 1]); i += 1; }
    }
  }
  const lane = opts.get("--lane"); const round = opts.get("--round"); const report = opts.get("--report");
  if (!lane || !round || !report || !/^\d+$/.test(round)) { process.stderr.write("usage: report-receipt-diff.mjs --lane DIR --round N --report FILE [--rev REV] [--fleet DIR] | --selftest\n"); process.exit(64); }
  const laneAbs = resolve(lane);
  let revFull = opts.get("--rev");
  if (opts.has("--rev")) {
    if (!revFull) { process.stdout.write("REPORT_RECEIPT: FAIL-CLOSED rev-unreadable (empty)\n"); process.exit(2); }
    const rv = git(laneAbs, ["rev-parse", "--verify", `${revFull}^{commit}`]);
    if (rv.status !== 0) { process.stdout.write(`REPORT_RECEIPT: FAIL-CLOSED rev-unreadable ${revFull}\n`); process.exit(2); }
    revFull = rv.stdout.trim();
  }
  let reportText;
  try { reportText = readFileSync(resolve(report), "utf8"); } catch { process.stdout.write(`REPORT_RECEIPT: FAIL-CLOSED report-unreadable ${report}\n`); process.exit(2); }
  const fleet = opts.has("--fleet") ? (opts.get("--fleet") ? resolve(opts.get("--fleet")) : null) : (existsSync(join(dirname(laneAbs), ".git")) ? dirname(laneAbs) : null);
  const findings = diffReport({ lane: laneAbs, round, reportText, rev: revFull, fleet });
  const r = render(findings, `round=${round} rev=${revFull || "worktree"} bytes=${Buffer.byteLength(reportText)}`);
  process.stdout.write(r.out);
  process.exit(r.code);
}

#!/usr/bin/env node
// ExecMapUnpinned sweep — for EVERY pinned `covered` entry: remove exactly that
// one registry entry (files + README rows byte-identical), run the committed
// readme-map gate, require DRIFT `unpinned:<entry>` and exit 1.
// Also: independent file<->covered/row recomputation (not the gate's code),
// the empty-covered arm (frozen probe B3(e) analogue), and a clean control.
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const ROOT = resolve(process.argv[2] || '.');
const SCRATCH = join(ROOT, 'scratch');
const PRISTINE = join(ROOT, '03-registry-pristine.json');
const SWEEP_REG = '.ufo/pins/sweep-reg.json';
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');
const fail = [];
const check = (name, ok, detail) => {
  if (!ok) fail.push(`${name}: ${detail}`);
  console.log(`arm ${name}: ${ok ? 'PASS' : `FAIL ${detail}`}`);
};

const registrySrc = readFileSync(PRISTINE, 'utf8');
const doc = JSON.parse(registrySrc);
const covered = doc.covered;

// --- registry shape (the B2 pin properties) ---
check('registry-version', doc.version === 1, `version=${JSON.stringify(doc.version)}`);
check('covered-array', Array.isArray(covered) && covered.length > 0, `len=${covered?.length}`);
check('covered-sorted-unique',
  covered.every((p, i) => i === 0 || covered[i - 1] < p) && new Set(covered).size === covered.length,
  'not strictly increasing / has duplicates');
check('covered-namespace', covered.every((p) => /^(knowledge|lessons)\/[A-Za-z0-9._-]+\.md$/.test(p)),
  'entry outside knowledge|lessons');

// --- live corpus (independent of the gate) ---
const live = [];
for (const d of ['knowledge', 'lessons']) {
  for (const n of readdirSync(join(SCRATCH, 'corpus', d))) if (n.endsWith('.md')) live.push(`${d}/${n}`);
}
live.sort();
const readme = readFileSync(join(SCRATCH, 'corpus', 'README.md'), 'utf8');
const rows = [];
for (const line0 of readme.split('\n')) {
  const m = line0.replace(/^ {0,3}/, '').match(/^\|\s*`((?:knowledge|lessons)\/[^`]+)`\s*\|/);
  if (m) rows.push(m[1]);
}
const setDiff = (a, b) => a.filter((x) => !b.includes(x));
check('live-count', live.length === 135, `live=${live.length}`);
check('covered-eq-live', covered.length === live.length && setDiff(live, covered).length === 0, `diff=${setDiff(live, covered)}`);
check('rows-eq-live', rows.length === live.length && setDiff(live, rows).length === 0 && setDiff(rows, live).length === 0, 'row bimap broken');
check('no-dup-rows', new Set(rows).size === rows.length, `rows=${rows.length} unique=${new Set(rows).size}`);

// --- gate runner ---
const gate = (reg) => spawnSync(process.execPath, ['scripts/readme-map.mjs', '--registry', reg],
  { cwd: SCRATCH, encoding: 'utf8', timeout: 120_000 });
const lines = (r) => `${r.stdout || ''}`.trim().split('\n');
const last = (r) => lines(r).pop() || '';

// clean control through the same --registry path the mutants use
writeFileSync(join(SCRATCH, SWEEP_REG), registrySrc);
{
  const r = gate(SWEEP_REG);
  check('control-clean', r.status === 0 && last(r) === 'README_MAP: CLEAN files=135 rows=135 covered=135',
    `exit=${r.status} last=${JSON.stringify(last(r))}`);
}

// --- per-entry mutants ---
let swept = 0;
for (const victim of covered) {
  const mutantDoc = { ...doc, covered: covered.filter((p) => p !== victim) };
  if (mutantDoc.covered.length !== covered.length - 1) {
    check(`mutant-${victim}`, false, `removed ${covered.length - mutantDoc.covered.length} entries, want 1`);
    continue;
  }
  writeFileSync(join(SCRATCH, SWEEP_REG), JSON.stringify(mutantDoc, null, 2) + '\n');
  const r = gate(SWEEP_REG);
  const out = lines(r);
  const want = `README_MAP: DRIFT files=135 rows=135 covered=134 bad=1 first=unpinned:${victim}`;
  const indep = setDiff(live, JSON.parse(readFileSync(join(SCRATCH, SWEEP_REG), 'utf8')).covered);
  const ok = r.status === 1 && out.length === 1 && out[0] === want
    && indep.length === 1 && indep[0] === victim;
  if (!ok) {
    check(`mutant-${victim}`, false,
      `exit=${r.status} out=${JSON.stringify(out)} indep=${JSON.stringify(indep)}`);
  } else {
    swept++;
    console.log(`arm mutant-${victim}: PASS first=unpinned:${victim} exit=1 bad=1`);
  }
}
check('sweep-all-entries', swept === covered.length,
  `swept=${swept}/${covered.length} individually-unpinned arms passed`);
console.log(`sweep: removed each of ${covered.length} covered entries once; ${swept} => DRIFT unpinned + exit 1, 0 escaped`);

// --- empty-covered arm (frozen probe B3(e) analogue) ---
writeFileSync(join(SCRATCH, SWEEP_REG), JSON.stringify({ version: 1, covered: [] }, null, 2) + '\n');
{
  const r = gate(SWEEP_REG);
  const out = lines(r);
  const drift = last(r);
  check('empty-covered', r.status === 1
    && drift === 'README_MAP: DRIFT files=135 rows=135 covered=0 bad=135 first=unpinned:knowledge/agent-isolation-substrates.md',
    `exit=${r.status} last=${JSON.stringify(drift)}`);
  check('empty-covered-notes', out.filter((l) => l.startsWith('README_MAP: note unpinned:')).length === 134,
    `notes=${out.filter((l) => l.startsWith('README_MAP: note ')).length}`);
}

// --- restore + post-conditions ---
writeFileSync(join(SCRATCH, SWEEP_REG), registrySrc);
{
  const r = gate(SWEEP_REG);
  check('restored-clean', r.status === 0 && last(r) === 'README_MAP: CLEAN files=135 rows=135 covered=135',
    `exit=${r.status} last=${JSON.stringify(last(r))}`);
}
rmSync(join(SCRATCH, SWEEP_REG), { force: true });
check('scratch-registry-pristine', sha(join(SCRATCH, '.ufo/pins/readme-map.json')) === sha(PRISTINE), 'registry bytes drifted');
check('sweep-reg-removed', !existsSync(join(SCRATCH, SWEEP_REG)), 'sweep registry left behind');

console.log(fail.length === 0 ? 'SWEEP_VERDICT: PASS' : `SWEEP_VERDICT: FAIL (${fail.length})`);
if (fail.length) for (const f of fail) console.log(`  FAIL ${f}`);
process.exit(fail.length === 0 ? 0 : 1);

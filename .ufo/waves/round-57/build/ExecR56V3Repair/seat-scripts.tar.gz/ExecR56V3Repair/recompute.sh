#!/bin/sh
# Independent corpus bimap recomputation (ExecR56V3Repair).
# comm of `find corpus/knowledge corpus/lessons -name '*.md'` (normalized by
# stripping the `corpus/` prefix) against the `| `path` |` first-cell rows of
# corpus/README.md. Base 7178bfd3 via `git archive` extraction; tip 8c6f5b01 via
# the lane working tree (whose README sha256 is checked == the tip commit blob).
set -u
B=$(cd "$(dirname "$0")" && pwd)
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
BASE=7178bfd3643c0fac74c8eb637cd6e985faadd0cf
TIP=8c6f5b01
export LC_ALL=C

ROW_RE='^[ ]{0,3}\|[[:space:]]*`((knowledge|lessons)/[^`]+)`[[:space:]]*\|'

emit_files() { # $1 = corpus parent dir (contains knowledge/ lessons/)
  ( cd "$1" && find corpus/knowledge corpus/lessons -name '*.md' -print ) \
    | sed 's|^corpus/||' | LC_ALL=C sort
}
emit_rows() { # $1 = README path
  sed -nE 's#^[ ]{0,3}\|[[:space:]]*`((knowledge|lessons)/[^`]+)`[[:space:]]*\|.*$#\1#p' "$1" | LC_ALL=C sort
}
bimap() { # $1 = label, $2 = corpus parent, $3 = README
  label=$1; parent=$2; readme=$3
  emit_files "$parent" > "$B/$label-files.txt"
  emit_rows "$readme"   > "$B/$label-rows.txt"
  comm -23 "$B/$label-files.txt" "$B/$label-rows.txt" > "$B/$label-uncovered.txt"
  comm -13 "$B/$label-files.txt" "$B/$label-rows.txt" > "$B/$label-orphan-rows.txt"
  comm -12 "$B/$label-files.txt" "$B/$label-rows.txt" > "$B/$label-intersection.txt"
  LC_ALL=C sort "$B/$label-rows.txt" | uniq -d > "$B/$label-duplicate-rows.txt"
  echo "== $label =="
  echo "files=$(wc -l < "$B/$label-files.txt") unique_files=$(LC_ALL=C sort -u "$B/$label-files.txt" | wc -l)"
  echo "rows=$(wc -l < "$B/$label-rows.txt") unique_rows=$(LC_ALL=C sort -u "$B/$label-rows.txt" | wc -l) duplicate_rows=$(wc -l < "$B/$label-duplicate-rows.txt")"
  echo "matched=$(wc -l < "$B/$label-intersection.txt") uncovered=$(wc -l < "$B/$label-uncovered.txt") orphan_rows=$(wc -l < "$B/$label-orphan-rows.txt")"
  echo "-- uncovered:"; sed 's/^/   /' "$B/$label-uncovered.txt"
  echo "-- orphan rows:"; sed 's/^/   /' "$B/$label-orphan-rows.txt"
  echo "-- duplicate rows:"; sed 's/^/   /' "$B/$label-duplicate-rows.txt"
}

echo "### ExecR56V3Repair independent corpus bimap recompute"
echo "### utc=$(date -u +%Y-%m-%dT%H:%M:%SZ) host=$(hostname) cwd=$LANE"
echo
echo "== revision identity =="
echo "base=${BASE}"
echo "tip=$(cd "$LANE" && git rev-parse "$TIP")"
echo "base README blob sha256: $(sha256sum "$B/base-tree/corpus/README.md" | cut -d' ' -f1)"
echo "base README git blob : $(cd "$LANE" && git show "${BASE}:corpus/README.md" | sha256sum | cut -d' ' -f1)"
echo "tip  README worktree  : $(sha256sum "$LANE/corpus/README.md" | cut -d' ' -f1)"
echo "tip  README commit    : $(cd "$LANE" && git show "$TIP:corpus/README.md" | sha256sum | cut -d' ' -f1)"
echo
bimap base "$B/base-tree" "$B/base-tree/corpus/README.md"
echo
bimap tip "$LANE" "$LANE/corpus/README.md"
echo
echo "== base -> tip file-set delta (comm) =="
echo "-- added files at tip:"; comm -13 "$B/base-files.txt" "$B/tip-files.txt" | sed 's/^/   /'
echo "-- removed files at tip:"; comm -23 "$B/base-files.txt" "$B/tip-files.txt" | sed 's/^/   /'
echo
echo "== base -> tip row-set delta (comm) =="
echo "-- added rows at tip:"; comm -13 "$B/base-rows.txt" "$B/tip-rows.txt" | sed 's/^/   /'
echo "-- removed rows at tip:"; comm -23 "$B/base-rows.txt" "$B/tip-rows.txt" | sed 's/^/   /'

#!/usr/bin/env node
// SimplifyEntryProse — prose-vs-receipt audit of corpus/knowledge/worker-heartbeat-liveness.md
// Read-only wrt the lane: reads via `git show <REV>:<path>`; writes only its own build dir.
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { writeFileSync } from 'node:fs';

const LANE = '/home/vgpnk/Projects/shokunin/kumitate-shokunin';
const REV = 'f0dc6d1160e66af65355bd353665adac22bbf4a9';
const ENTRY = 'corpus/knowledge/worker-heartbeat-liveness.md';
const OUT = '/home/vgpnk/Projects/shokunin/kumitate-shokunin/.ufo/waves/round-57/build/SimplifyEntryProse/audit.json';

const gitShow = (p) => {
  try { return execFileSync('git', ['-C', LANE, 'show', `${REV}:${p}`], { maxBuffer: 64 << 20 }); }
  catch (e) { return null; }
};
const norm = (s) => s.toString('utf8')
  .replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"')
  .replace(/\s+/g, ' ');

const entry = gitShow(ENTRY);
if (!entry) { console.error('entry missing at rev'); process.exit(2); }
const entryText = entry.toString('utf8');
const lines = entryText.split('\n');
const clauses = [];
lines.forEach((line, i) => {
  if (line.startsWith('- ')) clauses.push({ n: clauses.length + 1, lineno: i + 1, line });
});

const results = [];
for (const c of clauses) {
  const binds = [...c.line.matchAll(/`?receipt:([^`\s]+)@sha256:([0-9a-f]{64})`?/g)].map(m => ({ path: m[1], sha: m[2] }));
  const blobs = [];
  for (const b of binds) {
    const blob = gitShow(b.path);
    const ok = !!blob && createHash('sha256').update(blob).digest('hex') === b.sha;
    blobs.push({ ...b, exists: !!blob, shaOk: ok, bytes: blob ? blob.length : 0, text: blob ? blob.toString('utf8') : '' });
  }
  const hay = norm(blobs.map(b => b.text).join('\n'));
  // straight-double-quoted strings (incl. ellipsized ones); ignore the receipt spans already extracted
  const prose = c.line.replace(/`?receipt:[^`]*?`?/g, '');
  const quotes = [...prose.matchAll(/"([^"]+)"/g)].map(m => m[1]);
  const qchecks = quotes.map(q => {
    const frags = q.split(/…|\.\.\./).map(f => norm(f)).filter(f => f.length > 0);
    return { quote: q, frags: frags.map(f => ({ frag: f, found: hay.includes(f) })) };
  });
  // backticked code tokens (non-receipt)
  const codeTokens = [...prose.matchAll(/`([^`]+)`/g)].map(m => m[1]).filter(t => !t.startsWith('receipt:'));
  const cchecks = codeTokens.map(t => ({ token: t, found: hay.includes(norm(t)) }));
  results.push({ n: c.n, lineno: c.lineno, headline: (c.line.match(/\*\*(.+?)\*\*/) || [])[1], receipts: blobs.map(({ text, ...r }) => r), quoteChecks: qchecks, codeChecks: cchecks, hayLen: hay.length, _hay: hay });
}
writeFileSync(OUT, JSON.stringify(results, null, 1));
// console summary
for (const r of results) {
  const badSha = r.receipts.filter(x => !x.exists || !x.shaOk);
  const badQ = r.quoteChecks.filter(q => q.frags.some(f => !f.found));
  const badC = r.codeChecks.filter(x => !x.found);
  console.log(`clause ${r.n} (line ${r.lineno}) [${r.headline}] receipts=${r.receipts.length}${badSha.length ? ' SHA-BAD:' + JSON.stringify(badSha) : ''}${badQ.length ? ' QUOTE-MISS:' + JSON.stringify(badQ) : ''}${badC.length ? ' TOKEN-MISS:' + JSON.stringify(badC) : ''}`);
}
console.log('clauses:', results.length, 'distinct paths:', new Set(results.flatMap(r => r.receipts.map(x => x.path))).size);
// working tree vs rev byte identity for the entry
import('node:fs').then(fs => {
  const wt = fs.readFileSync(`${LANE}/${ENTRY}`);
  console.log('entry working-tree == rev bytes:', wt.equals(entry));
});

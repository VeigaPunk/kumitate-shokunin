#!/usr/bin/env node
// ExecD57Close — quote-location corroboration: do the entry's quoted phrases actually
// occur in the pinned capture bytes at the rev? (Reads only the extracted tree.)
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const X = process.argv[2];
const norm = (s) => s
  .replace(/<script[\s\S]*?<\/script>/gi, ' ')
  .replace(/<style[\s\S]*?<\/style>/gi, ' ')
  .replace(/<[^>]+>/g, ' ')
  .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
  .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&nbsp;/g, ' ')
  .replace(/[`*_]/g, '')
  .replace(/\s+/g, ' ')
  .toLowerCase();

const cases = [
  ['S117', '.ufo/waves/round-57/build/ScoutTemporalHb/temporal-activity-failures.html',
    'An Activity Heartbeat is a ping from the Worker that is executing the Activity to the Temporal Service'],
  ['S117', '.ufo/waves/round-57/build/ScoutTemporalHb/temporal-activity-failures.html',
    'informs the Temporal Service that the Activity Execution is making progress and the Worker has not crashed'],
  ['S117', '.ufo/waves/round-57/build/ScoutTemporalHb/temporal-activity-failures.html',
    'Activity Heartbeats work in conjunction with a Heartbeat Timeout'],
  ['S117', '.ufo/waves/round-57/build/ScoutTemporalHb/temporal-activity-failures.html',
    'We recommend using a relatively short Heartbeat Timeout and a frequent Heartbeat'],
  ['S118', '.ufo/waves/round-57/build/ScoutKafka/kafka-consumer-configs.html',
    'The timeout used to detect client failures when using Kafka\'s group management facility'],
  ['S118', '.ufo/waves/round-57/build/ScoutKafka/kafka-consumer-configs.html',
    'The client sends periodic heartbeats to indicate its liveness to the broker'],
  ['S118', '.ufo/waves/round-57/build/ScoutKafka/kafka-consumer-configs.html',
    'typically should be set no higher than 1/3'],
  ['S118', '.ufo/waves/round-57/build/ScoutKafka/kafka-consumer-configs.html',
    'the broker will remove this client from the group and initiate a rebalance'],
  ['S119', '.ufo/waves/round-57/build/ScoutK8s/k8s-liveness-probes.html',
    'Kubernetes provides liveness probes to detect and remedy'],
  ['S119', '.ufo/waves/round-57/build/ScoutK8s/k8s-liveness-probes.html',
    'the kubelet should perform a liveness probe every 5 seconds'],
  ['S120', '.ufo/waves/round-57/build/ScoutRabbitmqHb/rabbitmq-heartbeats.html',
    'ensure that the application layer promptly finds out about disrupted connections'],
];

let pass = 0;
for (const [id, p, phrase] of cases) {
  let body = '';
  try { body = norm(readFileSync(join(X, p), 'utf8')); } catch { body = ''; }
  const ok = body.includes(norm(phrase));
  if (ok) pass += 1;
  console.log(`${ok ? 'FOUND  ' : 'ABSENT '} ${id} ${p} :: ${phrase.slice(0, 70)}${phrase.length > 70 ? '…' : ''}`);
}
console.log(`QUOTE-LOCATION found=${pass}/${cases.length}`);
process.exit(pass === cases.length ? 0 : 1);

#!/usr/bin/env bash
# ExecD57Close mutation probes — only the scratch clone under this build dir is altered.
set -u
B="$(cd "$(dirname "$0")" && pwd)"
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
PROBE="$LANE/.ufo/waves/round-57/probe/doctrine57-probe.mjs"
SANDBOX="$B/sandbox"
REPO="$SANDBOX/repo"
rm -rf "$SANDBOX"
mkdir -p "$SANDBOX"
git clone --no-hardlinks --quiet "$LANE" "$REPO" || exit 2
cd "$REPO" || exit 2
BASE_REV=$(git rev-parse HEAD)
echo "sandbox clone of lane at $BASE_REV" | tee "$B/mut-summary.txt"
git config user.email execd57@local
git config user.name execd57

run_probe () { # $1 = label
  local label="$1"
  node "$PROBE" "$REPO" "$(git rev-parse HEAD)" > "$B/mut-$label.stdout.txt" 2> "$B/mut-$label.stderr.txt"
  echo "exit=$?" > "$B/mut-$label.exit.txt"
  echo "MUTANT $label: $(cat "$B/mut-$label.stdout.txt") $(cat "$B/mut-$label.exit.txt")" | tee -a "$B/mut-summary.txt"
}

# M1 — drop two clause lines (13 -> 11): expect E2 MISS (clause floor)
node -e '
const fs=require("fs");const p="corpus/knowledge/worker-heartbeat-liveness.md";
const L=fs.readFileSync(p,"utf8").split("\n");
const idx=L.map((l,i)=>[l,i]).filter(([l])=>l.startsWith("- ")).map(([,i])=>i);
const drop=new Set([idx[idx.length-1],idx[idx.length-2]]);
fs.writeFileSync(p,L.filter((_,i)=>!drop.has(i)).join("\n"));'
git commit -aqm "M1 drop two clause lines" && run_probe M1-drop-clauses

# M2 — corrupt one digit of a receipt sha256 token: expect E2 MISS (hash-miss)
git checkout -q -- corpus/knowledge/worker-heartbeat-liveness.md
node -e '
const fs=require("fs");const p="corpus/knowledge/worker-heartbeat-liveness.md";
let s=fs.readFileSync(p,"utf8");
s=s.replace(/receipt:([^\s@]+)@sha256:([0-9a-f])/, (m,pth,c)=>`receipt:${pth}@sha256:${c==="a"?"b":"a"}`);
fs.writeFileSync(p,s);'
git commit -aqm "M2 corrupt receipt hash" && run_probe M2-corrupt-hash

# M3 — flip S118 status mined -> queued in SOURCES.md: expect E3 MISS
git checkout -q -- corpus/knowledge/worker-heartbeat-liveness.md
node -e '
const fs=require("fs");const p="corpus/SOURCES.md";
const L=fs.readFileSync(p,"utf8").split("\n");
const n=L.map((l,i)=>l.startsWith("| S118 |")?i:-1).filter(i=>i>=0);
if(n.length!==1){console.error("S118 rows="+n.length);process.exit(3);}
L[n[0]]=L[n[0]].replace("| mined |","| queued |");
fs.writeFileSync(p,L.join("\n"));'
git commit -aqm "M3 S118 status queued" && run_probe M3-status-queued

# M4 — delete the verified-at provenance line: expect E1 MISS
git checkout -q -- corpus/SOURCES.md
node -e '
const fs=require("fs");const p="corpus/knowledge/worker-heartbeat-liveness.md";
const L=fs.readFileSync(p,"utf8").split("\n");
fs.writeFileSync(p,L.filter(l=>!l.startsWith("verified-at:")).join("\n"));'
git commit -aqm "M4 drop verified-at" && run_probe M4-drop-verified-at

# M5 — restore all: expect HELD 5/5 again at the sandbox tip (control for the mutant series)
git checkout -q -- corpus/knowledge/worker-heartbeat-liveness.md
git commit -aqm "M5 restore conformant tree" --allow-empty
run_probe M5-restored
echo "=== sandbox log ===" | tee -a "$B/mut-summary.txt"
git log --oneline | tee -a "$B/mut-summary.txt"

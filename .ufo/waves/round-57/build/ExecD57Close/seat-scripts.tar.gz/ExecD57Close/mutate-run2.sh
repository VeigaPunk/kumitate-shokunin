#!/usr/bin/env bash
# ExecD57Close mutation probes (v2, corrected) — each mutant is derived from the
# pristine lane tip, never cumulatively. Only the scratch clone here is altered.
set -u
B="$(cd "$(dirname "$0")" && pwd)"
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
PROBE="$LANE/.ufo/waves/round-57/probe/doctrine57-probe.mjs"
REPO="$B/sandbox2/repo"
rm -rf "$B/sandbox2"
mkdir -p "$B/sandbox2"
git clone --no-hardlinks --quiet "$LANE" "$REPO" || exit 2
cd "$REPO" || exit 2
PRISTINE=$(git rev-parse HEAD)
git config user.email execd57@local
git config user.name execd57
echo "pristine=$PRISTINE" | tee "$B/mut2-summary.txt"

run_probe () { # $1 label
  local label="$1" rev
  rev=$(git rev-parse HEAD)
  node "$PROBE" "$REPO" "$rev" > "$B/mut2-$label.stdout.txt" 2> "$B/mut2-$label.stderr.txt"
  echo "exit=$?" > "$B/mut2-$label.exit.txt"
  echo "MUTANT $label rev=$rev :: $(cat "$B/mut2-$label.stdout.txt") $(cat "$B/mut2-$label.exit.txt")" \
    | tee -a "$B/mut2-summary.txt"
}

fresh () { git reset --hard -q "$PRISTINE" || exit 2; }

# M1 — drop two of 13 clause lines: expect E2 MISS (clause floor), others PASS
fresh
node -e '
const fs=require("fs"),p="corpus/knowledge/worker-heartbeat-liveness.md";
const L=fs.readFileSync(p,"utf8").split("\n");
const idx=L.map((l,i)=>[l,i]).filter(([l])=>l.startsWith("- ")).map(([,i])=>i);
const drop=new Set([idx[idx.length-1],idx[idx.length-2]]);
fs.writeFileSync(p,L.filter((_,i)=>!drop.has(i)).join("\n"));'
git commit -aqm "M1 drop two clause lines"; run_probe M1-drop-clauses

# M2 — corrupt one hex digit of the first receipt token: expect E2 MISS hash-miss=1
fresh
node -e '
const fs=require("fs"),p="corpus/knowledge/worker-heartbeat-liveness.md";
let s=fs.readFileSync(p,"utf8");
s=s.replace(/receipt:([^\s@]+)@sha256:([0-9a-f])/,(m,pth,c)=>`receipt:${pth}@sha256:${c==="a"?"b":"a"}`);
fs.writeFileSync(p,s);'
git commit -aqm "M2 corrupt receipt hash"; run_probe M2-corrupt-hash

# M3 — S118 status mined -> queued: expect E3 MISS only
fresh
node -e '
const fs=require("fs"),p="corpus/SOURCES.md";
const L=fs.readFileSync(p,"utf8").split("\n");
const n=L.map((l,i)=>l.startsWith("| S118 |")?i:-1).filter(i=>i>=0);
if(n.length!==1){console.error("S118 rows="+n.length);process.exit(3);}
L[n[0]]=L[n[0]].replace("| mined |","| queued |");
fs.writeFileSync(p,L.join("\n"));'
git commit -aqm "M3 S118 status queued"; run_probe M3-status-queued

# M4 — drop the verified-at provenance line: expect E1 MISS (and E4 coupling, observed not assumed)
fresh
node -e '
const fs=require("fs"),p="corpus/knowledge/worker-heartbeat-liveness.md";
const L=fs.readFileSync(p,"utf8").split("\n");
fs.writeFileSync(p,L.filter(l=>!l.startsWith("verified-at:")).join("\n"));'
git commit -aqm "M4 drop verified-at"; run_probe M4-drop-verified-at

# C — control: pristine tree restored, expect DOCTRINE57_HELD 5/5 again
fresh
run_probe C-pristine-control
echo "final-HEAD=$(git rev-parse HEAD) expected-pristine=$PRISTINE" | tee -a "$B/mut2-summary.txt"

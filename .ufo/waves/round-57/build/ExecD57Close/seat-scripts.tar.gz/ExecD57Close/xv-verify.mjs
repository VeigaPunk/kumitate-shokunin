#!/usr/bin/env node
// ExecD57Close independent recomputation of D57 E1/E2/E3 — deliberately NOT
// reusing the frozen probe's code paths (own extraction, own regexes, own hash).
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, rmSync, mkdirSync } from 'node:fs';
import { join, resolve } from 'node:path';

const [laneArg, rev] = process.argv.slice(2);
const lane = resolve(laneArg);
const X = join(new URL('.', import.meta.url).pathname, `xtract-${rev.slice(0, 8)}`);

rmSync(X, { recursive: true, force: true });
mkdirSync(X, { recursive: true });
const tar = spawnSync('bash', ['-c',
  `git -C ${JSON.stringify(lane)} archive ${JSON.stringify(rev)} | tar -x -C ${JSON.stringify(X)}`],
  { encoding: 'utf8', timeout: 180_000 });
if (tar.status !== 0) { console.log(`XV: EXTRACTION-FAILED status=${tar.status}`); process.exit(2); }

const rd = (p) => { try { return readFileSync(join(X, p)); } catch { return null; } };
const h = (b) => createHash('sha256').update(b).digest('hex');
const out = [];
let ok1 = 0, ok2 = 0, ok3 = 0;

// E1 — provenance trio in first five lines, own regexes
{
  const e = rd('corpus/knowledge/worker-heartbeat-liveness.md');
  if (!e) out.push('E1 miss entry-absent');
  else {
    const head5 = e.toString('utf8').split('\n').slice(0, 5);
    const joined = head5.join('\n');
    const src = head5.find((l) => l.startsWith('source:')) || '';
    const cond = src.includes('S117') && /docs\.temporal\.io/.test(src)
      && src.includes('S118') && src.includes('S119')
      && head5.some((l) => l.startsWith('verified-at:'))
      && head5.some((l) => l.startsWith('recheck:'));
    ok1 = cond ? 1 : 0;
    out.push(`E1 ${cond ? 'PASS' : 'MISS'} source-line-chars=${src.length} verified-at=${head5.some((l)=>l.startsWith('verified-at:'))} recheck=${head5.some((l)=>l.startsWith('recheck:'))}`);
  }
}

// E2 — own clause scan: >=12 '- ' lines, every line bound, paths distinct, blob hash equal
{
  const e = rd('corpus/knowledge/worker-heartbeat-liveness.md');
  if (!e) out.push('E2 miss entry-absent');
  else {
    const clauses = e.toString('utf8').split('\n').filter((l) => l.startsWith('- '));
    const seen = new Map();
    let unbound = 0, bad = 0, dup = 0;
    for (const l of clauses) {
      const m = /receipt:(\S+?)@sha256:([0-9a-f]{64})(?![0-9a-f])/.exec(l);
      if (!m) { unbound += 1; continue; }
      const [, p, want] = m;
      if (seen.has(p)) dup += 1;
      seen.set(p, want);
      const blob = rd(p);
      if (!blob) { bad += 1; out.push(`  E2 blob-absent ${p}`); continue; }
      const got = h(blob);
      if (got !== want) { bad += 1; out.push(`  E2 hash-mismatch ${p} want=${want} got=${got}`); }
    }
    const cond = clauses.length >= 12 && unbound === 0 && dup === 0 && bad === 0;
    ok2 = cond ? 1 : 0;
    out.push(`E2 ${cond ? 'PASS' : 'MISS'} clauses=${clauses.length} unbound=${unbound} duplicate-path=${dup} hash-miss=${bad} distinct-paths=${seen.size}`);
    for (const [p] of seen) out.push(`  E2 bound ${p}`);
  }
}

// E3 — SOURCES rows and capture registry pins, parsed independently of the probe
{
  const s = rd('corpus/SOURCES.md');
  const regRaw = rd('.ufo/pins/source-captures.json');
  let cond = Boolean(s && regRaw);
  if (s) {
    const rows = s.toString('utf8').split('\n').filter((l) => /^\| S11[789] \|/.test(l));
    for (const id of ['S117', 'S118', 'S119']) {
      const row = rows.find((l) => l.startsWith(`| ${id} |`));
      const cells = row ? row.split('|').map((c) => c.trim()) : [];
      const used = cells[11] || '';
      const good = cells[8] === 'mined' && used.includes('corpus/knowledge/worker-heartbeat-liveness.md');
      if (!good) cond = false;
      out.push(`E3 ${id} ${good ? 'PASS' : 'MISS'} status=${JSON.stringify(cells[8])} used-by=${JSON.stringify(used.slice(0, 80))} tier=${JSON.stringify(cells[3])}`);
    }
  } else out.push('E3 miss SOURCES-absent');
  if (regRaw) {
    try {
      const reg = JSON.parse(regRaw.toString('utf8'));
      for (const id of ['S117', 'S118', 'S119', 'S120']) {
        const c = reg.captures.find((x) => x.sourceId === id);
        const b = c ? rd(c.path) : null;
        const good = Boolean(c && b && h(b) === c.sha256);
        if (!good) cond = false;
        out.push(`E3 pin ${id} ${good ? 'PASS' : 'MISS'} path=${c ? c.path : 'no-registry-entry'}`);
      }
    } catch (err) { cond = false; out.push(`E3 miss registry-parse ${err.message}`); }
  } else out.push('E3 miss capture-registry-absent');
  ok3 = cond ? 1 : 0;
  out.push(`E3 ${cond ? 'PASS' : 'MISS'} (aggregate)`);
}

console.log(`XV rev=${rev} E1=${ok1} E2=${ok2} E3=${ok3} — independent recomputation, probe code not imported`);
for (const l of out) console.log(l);
process.exit(ok1 && ok2 && ok3 ? 0 : 1);

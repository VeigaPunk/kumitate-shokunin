#!/usr/bin/env bash
# ExecR56Counters — re-run the FROZEN round-56 counters at every candidate close rev.
# Read-only: probes extract `git archive <rev>` into their own mktemp dirs; no lane writes.
set -u
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
B="$LANE/.ufo/waves/round-57/build/ExecR56Counters"
LOG="$B/run.log"
: > "$LOG"
export TZ=UTC
{
  echo "# ExecR56Counters re-run — $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "# lane=$LANE"
  echo "# probe sha256:"
  sha256sum "$LANE/.ufo/waves/round-56/probe/attest56-probe.mjs" "$LANE/.ufo/waves/round-56/probe/doctrine56-probe.mjs"
  echo "# git HEAD=$(git -C "$LANE" rev-parse HEAD) lane-status-before:"
  git -C "$LANE" status --porcelain
  echo "# revs under test:"
  cat "$B/revs.txt"
  echo
} >> "$LOG"

while read -r short rev; do
  [ -n "${short:-}" ] || continue
  for probe in attest56 doctrine56; do
    out="$B/${probe}@${short}.txt"
    err="$B/${probe}@${short}.err.txt"
    start=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    node "$LANE/.ufo/waves/round-56/probe/${probe}-probe.mjs" "$LANE" "$rev" >"$out" 2>"$err"
    rc=$?
    end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    {
      echo "=== ${probe} rev=${short} (${rev}) start=$start end=$end exit=$rc"
      echo "--- cmd: node .ufo/waves/round-56/probe/${probe}-probe.mjs $LANE $rev"
      echo "--- stdout:"
      cat "$out"
      echo "--- stderr:"
      cat "$err"
      echo
    } >> "$LOG"
  done
done < "$B/revs.txt"

{
  echo "# lane-status-after:"
  git -C "$LANE" status --porcelain
  echo "# done $(date -u +%Y-%m-%dT%H:%M:%SZ)"
} >> "$LOG"

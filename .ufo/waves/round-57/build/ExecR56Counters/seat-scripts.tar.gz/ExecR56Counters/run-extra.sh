#!/usr/bin/env bash
# ExecR56Counters — extra arms: exact reproduction of the committed
# round-57 close transcript rev (b3bd063), the round-56 base do-nothing control
# (3eae059e), and a fail-closed unreadable-rev contract arm.
set -u
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
B="$LANE/.ufo/waves/round-57/build/ExecR56Counters"
LOG="$B/run-extra.log"
: > "$LOG"
export TZ=UTC
{
  echo "# ExecR56Counters extra arms — $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "# HEAD=$(git -C "$LANE" rev-parse HEAD)"
  echo "# revs:"
  for r in b3bd063 3eae059e; do printf '%s %s\n' "$r" "$(git -C "$LANE" rev-parse "$r^{commit}")"; done
  echo
} >> "$LOG"

run_one () { # $1 label, $2 probe, $3 rev
  local label=$1 probe=$2 rev=$3
  local out="$B/${probe}@${label}.txt" err="$B/${probe}@${label}.err.txt"
  local start end rc
  start=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  node "$LANE/.ufo/waves/round-56/probe/${probe}-probe.mjs" "$LANE" "$rev" >"$out" 2>"$err"
  rc=$?
  end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  {
    echo "=== ${probe} label=${label} rev=${rev} start=$start end=$end exit=$rc"
    echo "--- cmd: node .ufo/waves/round-56/probe/${probe}-probe.mjs $LANE $rev"
    echo "--- stdout:"; cat "$out"
    echo "--- stderr:"; cat "$err"
    echo
  } >> "$LOG"
}

run_one b3bd063 attest56 b3bd0633aec43ad2559f980b400e4d7077e10af3
run_one b3bd063 doctrine56 b3bd0633aec43ad2559f980b400e4d7077e10af3
run_one base56 attest56 3eae059e929e4da317c45eba18b4099b90f7541b
run_one base56 doctrine56 3eae059e929e4da317c45eba18b4099b90f7541b
# fail-closed contract: a well-formed but absent 40-hex rev must be exit 2, never a score
run_one norev attest56 0000000000000000000000000000000000000000
run_one norev doctrine56 0000000000000000000000000000000000000000

{ echo "# done $(date -u +%Y-%m-%dT%H:%M:%SZ)"; } >> "$LOG"

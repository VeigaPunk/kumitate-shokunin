#!/usr/bin/env bash
# ReviewMistakeR56V2 — mutation battery against A57 B7 (R56-V2 amendment).
# Runs ONLY inside the sandbox clone; lane untouched.
set -u
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
PROBE="$LANE/.ufo/waves/round-57/probe/attest57-probe.mjs"
SBX="$LANE/.ufo/waves/round-57/build/ReviewMistakeR56V2/sbx"
OUT="$LANE/.ufo/waves/round-57/build/ReviewMistakeR56V2"
cd "$SBX"

run_probe() { # $1 = label, $2 = rev
  node "$PROBE" "$SBX" "$2" > "$OUT/mut-$1.txt" 2>&1
  echo "mut=$1 exit=$?" >> "$OUT/mut-$1.txt"
  grep -o 'B7 [A-Z]* [^|]*' "$OUT/mut-$1.txt" | sed "s/^/[$1] /"
}

I24='- [ ] Frozen-counter registry gate (round 54; contract `kumitate-counter-pins-v1`) — `node scripts/counter-pins.mjs` → exit 0 + `COUNTER_PINS: CLEAN`'
I25='- [ ] Opened-source byte-persistence gate (round 55; contract `kumitate-source-capture-v1`) — `node scripts/source-capture.mjs` → exit 0 + `SOURCE_CAPTURE: CLEAN`'
I26='- [ ] SOURCES duplicate-URL ratchet (round 56; contract `kumitate-source-dupes-v1`) — `node scripts/source-dupes.mjs` → exit 0 + `SOURCE_DUPES: CLEAN`'
I24u='- [ ] Frozen-counter registry gate (round 54; contract `kumitate-counter-pins-v1`) → exit 0 + `COUNTER_PINS: CLEAN`'
I25u='- [ ] Opened-source byte-persistence gate (round 55; contract `kumitate-source-capture-v1`) → exit 0 + `SOURCE_CAPTURE: CLEAN`'
I26u='- [ ] SOURCES duplicate-URL ratchet (round 56; contract `kumitate-source-dupes-v1`) → exit 0 + `SOURCE_DUPES: CLEAN`'

mutate() { # $1 = python transform on stdin -> stdout
  git show HEAD:SKILL.md | python3 -c "$1" > SKILL.md
  git add SKILL.md && git commit -qm "$2"
}

echo '== M1: only-newest shape — items 24,25,26 lose their gate names; item 27 keeps readme-map =='
mutate "
import sys
t = sys.stdin.read()
for a, b in [('''$I24''','''$I24u'''), ('''$I25''','''$I25u'''), ('''$I26''','''$I26u''')]:
    assert a in t, 'M1 anchor missing'
    t = t.replace(a, b)
print(t, end='')
" 'M1: only-newest binding shape (pre-amendment convention)'
run_probe M1 "$(git rev-parse HEAD)"
echo "items=$(git show HEAD:SKILL.md | grep -c '^\\s*- \\[')"

echo '== M2: drop exactly one old binding (item 26 loses source-dupes.mjs) =='
git checkout -q 798d4d23743487d0c642239ca54deba421021af3 -- SKILL.md
mutate "
import sys
t = sys.stdin.read()
assert '''$I26''' in t, 'M2 anchor missing'
print(t.replace('''$I26''', '''$I26u'''), end='')
" 'M2: item 26 unbound, 24/25/27 bound'
run_probe M2 "$(git rev-parse HEAD)"
echo "items=$(git show HEAD:SKILL.md | grep -c '^\\s*- \\[')"

echo '== M3: growth to 28 without re-expression =='
git checkout -q 798d4d23743487d0c642239ca54deba421021af3 -- SKILL.md
mutate "
import sys
t = sys.stdin.read()
anchor = '- [ ] Corpus coverage-map bimap gate (round 57; contract \`kumitate-readme-map-v1\`)'
i = t.index(anchor) + len(anchor)
print(t[:i] + '\n- [ ] Hypothetical round-58 gate — \`node scripts/future-gate.mjs\` → exit 0' + t[i:], end='')
" 'M3: item 28 appended without re-expression'
run_probe M3 "$(git rev-parse HEAD)"
echo "items=$(git show HEAD:SKILL.md | grep -c '^\\s*- \\[')"

echo '== M4: reorder items 24 and 25 =='
git checkout -q 798d4d23743487d0c642239ca54deba421021af3 -- SKILL.md
mutate "
import sys
t = sys.stdin.read()
assert '''$I24\n$I25''' in t, 'M4 anchor missing'
print(t.replace('''$I24\n$I25''', '''$I25\n$I24'''), end='')
" 'M4: items 24/25 swapped'
run_probe M4 "$(git rev-parse HEAD)"
echo "items=$(git show HEAD:SKILL.md | grep -c '^\\s*- \\[')"

echo '== restore sandbox to close rev =='
git checkout -q 798d4d23743487d0c642239ca54deba421021af3 -- SKILL.md
git status --porcelain | wc -l

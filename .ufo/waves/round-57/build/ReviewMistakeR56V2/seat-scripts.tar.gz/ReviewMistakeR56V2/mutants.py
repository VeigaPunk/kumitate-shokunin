#!/usr/bin/env python3
"""ReviewMistakeR56V2 — mutation battery against A57 B7 (R56-V2 amendment).

Sandbox-only: all mutations are commits inside the build-dir clone; the probe
reads via `git archive`, so the lane and its git state are untouched.
"""
import subprocess, sys, os

LANE = "/home/vgpnk/Projects/shokunin/kumitate-shokunin"
PROBE = f"{LANE}/.ufo/waves/round-57/probe/attest57-probe.mjs"
SBX = f"{LANE}/.ufo/waves/round-57/build/ReviewMistakeR56V2/sbx"
OUT = f"{LANE}/.ufo/waves/round-57/build/ReviewMistakeR56V2"
CLOSE = "798d4d23743487d0c642239ca54deba421021af3"

I24 = "- [ ] Frozen-counter registry gate (round 54; contract `kumitate-counter-pins-v1`) — `node scripts/counter-pins.mjs` → exit 0 + `COUNTER_PINS: CLEAN`"
I25 = "- [ ] Opened-source byte-persistence gate (round 55; contract `kumitate-source-capture-v1`) — `node scripts/source-capture.mjs` → exit 0 + `SOURCE_CAPTURE: CLEAN`"
I26 = "- [ ] SOURCES duplicate-URL ratchet (round 56; contract `kumitate-source-dupes-v1`) — `node scripts/source-dupes.mjs` → exit 0 + `SOURCE_DUPES: CLEAN`"
I27 = "- [ ] Corpus coverage-map bimap gate (round 57; contract `kumitate-readme-map-v1`) — `node scripts/readme-map.mjs` → exit 0 + `README_MAP: CLEAN`"
I28 = "- [ ] Hypothetical round-58 gate — `node scripts/future-gate.mjs` → exit 0"
I24u = "- [ ] Frozen-counter registry gate (round 54; contract `kumitate-counter-pins-v1`) → exit 0 + `COUNTER_PINS: CLEAN`"
I25u = "- [ ] Opened-source byte-persistence gate (round 55; contract `kumitate-source-capture-v1`) → exit 0 + `SOURCE_CAPTURE: CLEAN`"
I26u = "- [ ] SOURCES duplicate-URL ratchet (round 56; contract `kumitate-source-dupes-v1`) → exit 0 + `SOURCE_DUPES: CLEAN`"

def git(*args, **kw):
    return subprocess.run(["git", "-C", SBX, *args], check=True, capture_output=True, text=True, **kw).stdout

def close_skill():
    git("checkout", "-q", CLOSE, "--", "SKILL.md")

def commit(msg):
    git("add", "SKILL.md")
    git("commit", "-qm", msg)
    return git("rev-parse", "HEAD").strip()

def replace_once(t, a, b):
    assert t.count(a) == 1, f"anchor not unique/absent: {a[:60]}..."
    return t.replace(a, b)

def probe(label, rev):
    r = subprocess.run(["node", PROBE, SBX, rev], capture_output=True, text=True, timeout=420)
    line = (r.stdout + r.stderr).strip()
    with open(f"{OUT}/mut-{label}.txt", "w") as f:
        f.write(line + f"\nexit={r.returncode}\n")
    b7 = [p.strip() for p in line.split("|") if p.strip().startswith("B7 ")][0]
    verdict = line.split(" | ")[0].split("rev=")[0].strip()
    print(f"[{label}] {verdict} exit={r.returncode}")
    print(f"[{label}] {b7}")
    return r.returncode

# --- replica contrast harness: exact committed predicate lines ---
# A54 B7 (attest54-probe.mjs:357-360): rowOk=/\|\s*counter-pins\s*\|/; items===24 && item24=/node scripts\/counter-pins\.mjs/
# A55 B7 (attest55-probe.mjs:282-285): rowOk=/\|\s*source-capture\s*\|\s*gate\s*\|/; items===25 && item25=/- \[ \][^\n]*source-capture\.mjs/
# A57 B7 (attest57-probe.mjs:323-329): rowOk + items===27 + bind(24..27)
import re
def replicas(t):
    items = [l for l in t.split("\n") if re.match(r"^\s*- \[", l)]
    n = len(items)
    a54 = bool(re.search(r"\|\s*counter-pins\s*\|", t)) and n == 24 and n >= 24 and "node scripts/counter-pins.mjs" in (items[23] if n >= 24 else "")
    a55 = bool(re.search(r"\|\s*source-capture\s*\|\s*gate\s*\|", t)) and n == 25 and bool(re.search(r"- \[ \][^\n]*source-capture\.mjs", t))
    i24 = items[23] if n >= 24 else ""; i25 = items[24] if n >= 25 else ""
    i26 = items[25] if n >= 26 else ""; i27 = items[26] if n >= 27 else ""
    a57 = bool(re.search(r"\|\s*readme-map\s*\|\s*gate\s*\|", t)) and "kumitate-readme-map-v1" in t and n == 27 \
        and ("counter-pins.mjs" in i24 and "source-capture.mjs" in i25 and "source-dupes.mjs" in i26 and "readme-map.mjs" in i27)
    # hypothetical successor that binds ONLY the newest item (the pre-amendment shape applied to a future A58)
    a58_newest_only = n == 28 and "readme-map.mjs" in i27
    return n, a54, a55, a57, a58_newest_only

def contrast(label, rev):
    t = git("show", f"{rev}:SKILL.md")
    n, a54, a55, a57, a58n = replicas(t)
    print(f"[replica {label}] items={n} A54old={a54} A55old={a55} A57new={a57} newestOnly28={a58n}")

MUT = {
    "M1": lambda t: replace_once(replace_once(replace_once(t, I24, I24u), I25, I25u), I26, I26u),
    "M2": lambda t: replace_once(t, I26, I26u),
    "M3": lambda t: replace_once(t, I27, I27 + "\n" + I28),
    "M4": lambda t: replace_once(t, I24 + "\n" + I25, I25 + "\n" + I24),
}
NAMES = {
    "M1": "only-newest shape (24-26 unbound, 27 bound readme-map)",
    "M2": "drop one old binding (26 unbound)",
    "M3": "growth to 28 without re-expression",
    "M4": "reorder items 24/25",
}

close_skill()
contrast("close", CLOSE)
for name, fn in MUT.items():
    close_skill()
    t = git("show", f"{CLOSE}:SKILL.md")
    with open(f"{SBX}/SKILL.md", "w") as f:
        f.write(fn(t))
    rev = commit(name)
    print(f"== {name}: {NAMES[name]} rev={rev[:7]} ==")
    probe(name, rev)
    contrast(name, rev)
close_skill()
print(f"sandbox restored dirty={len(git('status','--porcelain').strip().splitlines()) if git('status','--porcelain').strip() else 0}")

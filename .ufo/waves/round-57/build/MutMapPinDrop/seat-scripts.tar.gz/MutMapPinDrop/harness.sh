#!/usr/bin/env bash
# MutMapPinDrop — mutation probe: drop one middle `covered` entry in the scratch
# registry of a git-archive extraction of the lane rev; verify DRIFT `unpinned`
# for exactly that path and no others. Read-only against the lane.
set -uo pipefail
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
REV=8c6f5b017d149b18134917378cdbed3b492d8e89
B=$LANE/.ufo/waves/round-57/build/MutMapPinDrop
T=$B/scratch
DET="node $T/scripts/readme-map.mjs"   # gate default paths resolve LANE=scratch root
TARGET_INDEX=67
TARGET=lessons/round-23.md

rm -rf "$T"
mkdir -p "$T" "$B/logs" "$B/pristine" "$B/mutant" "$B/restored"

log() { printf '%s\n' "$*" | tee -a "$B/logs/run.log"; }
run_det() { # $1=label
  local out=$B/logs/$1.out
  ( cd "$T" && $DET ) >"$out" 2>"$out.err"
  local rc=$?
  printf 'exit=%d\n' "$rc" | tee -a "$out"
  echo "=== $1 exit=$rc" | tee -a "$B/logs/run.log"
  sed 's/^/    /' "$out" | tee -a "$B/logs/run.log"
  [ -s "$out.err" ] && sed 's/^/    ERR /' "$out.err" | tee -a "$B/logs/run.log"
  return 0
}

log "# MutMapPinDrop probe $(date -u +%FT%TZ) rev=$REV"

# --- extraction of the committed rev (never the working tree) ---
set -o pipefail
git -C "$LANE" archive "$REV" | tar -x -C "$T"
log "archive_exit=$? scratch_files=$(find "$T" -type f | wc -l)"

REG=$T/.ufo/pins/readme-map.json
cp "$REG" "$B/pristine/readme-map.json"
log "pristine_sha256=$(sha256sum "$REG" | cut -d' ' -f1)"
log "pristine_copy_sha256=$(sha256sum "$B/pristine/readme-map.json" | cut -d' ' -f1)"
log "lane_registry_sha256=$(sha256sum "$LANE/.ufo/pins/readme-map.json" | cut -d' ' -f1)"
log "target=$TARGET file_present=$([ -f "$T/corpus/$TARGET" ] && echo yes || echo no) readme_rows=$(grep -c "\`$TARGET\`" "$T/corpus/README.md")"

# --- 1 baseline: pristine bytes ---
log "--- 1 pristine"
run_det 1-pristine

# --- 2 mutant: drop exactly the middle covered entry, single-line deletion ---
node - "$REG" "$TARGET" <<'NODE'
const { readFileSync, writeFileSync } = require('node:fs');
const [reg, target] = process.argv.slice(2);
const raw = readFileSync(reg, 'utf8');
const lines = raw.split('\n');
const hits = lines.map((l, i) => (l.includes(`"${target}"`) ? i : -1)).filter((i) => i >= 0);
if (hits.length !== 1) { console.error(`MUTATE: target occurrences=${hits.length}`); process.exit(9); }
const removed = lines.splice(hits[0], 1)[0];
writeFileSync(reg, lines.join('\n'));
console.log(`MUTATE: removed line ${hits[0] + 1}: ${removed.trim()}`);
NODE
log "mutate_exit=$?"
cp "$REG" "$B/mutant/readme-map.json"
log "mutant_sha256=$(sha256sum "$REG" | cut -d' ' -f1)"
log "mutant_covered_len=$(node -e 'console.log(JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")).covered.length)' "$REG")"
log "--- 2 mutant"
run_det 2-mutant

# --- 3 restore exact pristine bytes ---
cp "$B/pristine/readme-map.json" "$REG"
cp "$REG" "$B/restored/readme-map.json"
log "restored_sha256=$(sha256sum "$REG" | cut -d' ' -f1)"
cmp -s "$B/pristine/readme-map.json" "$REG" && log "restore_cmp=identical" || log "restore_cmp=DIFFERS"
log "--- 3 restored"
run_det 3-restored

# --- 4 verdict extraction from captured outputs ---
printf '%s\n' "--- 4 verdict" | tee -a "$B/logs/run.log"
for f in 1-pristine 2-mutant 3-restored; do
  printf '%s exit=%s last=%s\n' "$f" \
    "$(sed -n 's/^exit=//p' "$B/logs/$f.out")" \
    "$(grep -E '^README_MAP:' "$B/logs/$f.out" | tail -1)" | tee -a "$B/logs/run.log"
done
printf 'mutant_bad_count=%s\n' "$(grep -cE '^README_MAP: (note|DRIFT)' "$B/logs/2-mutant.out")" | tee -a "$B/logs/run.log"
printf 'mutant_notes=%s\n' "$(grep -c '^README_MAP: note ' "$B/logs/2-mutant.out")" | tee -a "$B/logs/run.log"
printf 'mutant_unpinned_paths=%s\n' "$(grep -o 'unpinned:[^ ]*' "$B/logs/2-mutant.out" | sort -u | tr '\n' ' ')" | tee -a "$B/logs/run.log"
printf 'lane_registry_sha256_after=%s\n' "$(sha256sum "$LANE/.ufo/pins/readme-map.json" | cut -d' ' -f1)" | tee -a "$B/logs/run.log"

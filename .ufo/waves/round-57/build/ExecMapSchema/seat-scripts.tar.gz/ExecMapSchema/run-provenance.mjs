#!/usr/bin/env node
// Provenance / integrity record for the ExecMapSchema scratch controls, round 57.
// Read-only git commands against the lane; no writes outside this build dir.
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const LANE = '/home/vgpnk/Projects/shokunin/kumitate-shokunin';
const OUT = join(HERE, 'out');
const sha = (b) => createHash('sha256').update(b).digest('hex');
const shaFile = (p) => sha(readFileSync(p));
const git = (...a) => spawnSync('git', ['-C', LANE, ...a], { encoding: 'utf8' });
const lines = [];
const add = (s) => { lines.push(s); process.stdout.write(`${s}\n`); };

add(`lane=${LANE}`);
add(`HEAD=${git('rev-parse', 'HEAD').stdout.trim()}`);
add(`plan_base=7178bfd3643c0fac74c8eb637cd6e985faadd0cf R1_measured=f0dc6d11`);
for (const rev of ['7178bfd3643c0fac74c8eb637cd6e985faadd0cf', 'f0dc6d11', '8c6f5b0']) {
  const r = git('show', `${rev}:scripts/readme-map.mjs`);
  add(`gate@${rev} sha256=${r.status === 0 ? sha(Buffer.from(r.stdout, 'utf8')) : 'ABSENT'} (git show exit=${r.status})`);
}
const pinDoc = JSON.parse(readFileSync(join(LANE, '.ufo/pins/counter-pins.json'), 'utf8'));
const pin = pinDoc.pins.find((p) => p.round === 57 && p.name === 'readme-map');
add(`counter-pins round57 readme-map sha256=${pin.sha256} path=${pin.path}`);
add(`worktree gate sha256=${shaFile(join(LANE, 'scripts/readme-map.mjs'))}`);
add(`worktree registry sha256=${shaFile(join(LANE, '.ufo/pins/readme-map.json'))}`);
add(`worktree README sha256=${shaFile(join(LANE, 'corpus/README.md'))}`);
const reg = JSON.parse(readFileSync(join(LANE, '.ufo/pins/readme-map.json'), 'utf8'));
add(`registry version=${reg.version} covered=${reg.covered.length} sorted_unique=${JSON.stringify(reg.covered) === JSON.stringify([...new Set(reg.covered)].sort())}`);
add(`corpus knowledge *.md=${readdirSync(join(LANE, 'corpus/knowledge')).filter((n) => n.endsWith('.md')).length} lessons *.md=${readdirSync(join(LANE, 'corpus/lessons')).filter((n) => n.endsWith('.md')).length}`);

// Extracted-tree immutability: my runs must not have written to the extracted copies.
const R1 = join(HERE, 'rev-f0dc6d1');
for (const [rel, gitPath] of [['.ufo/pins/readme-map.json', ':.ufo/pins/readme-map.json'], ['corpus/README.md', ':corpus/README.md']]) {
  const committed = git('show', `f0dc6d11${gitPath}`).stdout;
  add(`extracted ${rel} unchanged_by_runs=${shaFile(join(R1, rel)) === sha(Buffer.from(committed, 'utf8'))} sha256=${shaFile(join(R1, rel))}`);
}
// Lane working tree: scripts/, pins and corpus must be untouched by this seat.
const st = git('status', '--porcelain', '--', 'scripts', '.ufo/pins', 'corpus').stdout.trim();
add(`lane git status (scripts, .ufo/pins, corpus): ${st === '' ? 'CLEAN (no entries)' : st.replace(/\n/g, ' | ')}`);

// Pruned-tree integrity: the revision trees were extracted with `git archive` and then pruned to
// the read set (scripts/readme-map.mjs, corpus/README.md, corpus/{knowledge,lessons}/**, 
// .ufo/pins/readme-map.json). Every retained file must still equal its committed blob.
for (const [rev, dir] of [['f0dc6d11', 'rev-f0dc6d1'], ['8c6f5b0', 'rev-8c6f5b0']]) {
  const ls = git('ls-tree', '-r', rev, '--', 'corpus', 'scripts/readme-map.mjs', '.ufo/pins/readme-map.json')
    .stdout.trim().split('\n').filter(Boolean);
  let match = 0; let pruned = 0; let mismatch = 0; const prunedSample = []; const badSample = [];
  for (const line of ls) {
    const [meta, p] = line.split('\t');
    const want = meta.split(/\s+/)[2];
    const local = join(HERE, dir, p);
    if (!existsSync(local)) { pruned++; if (prunedSample.length < 3) prunedSample.push(p); continue; }
    const got = spawnSync('git', ['-C', LANE, 'hash-object', local], { encoding: 'utf8' }).stdout.trim();
    if (got === want) match++; else { mismatch++; if (badSample.length < 3) badSample.push(p); }
  }
  add(`tree ${dir}@${rev} ls_tree_entries=${ls.length} matched=${match} pruned=${pruned} mismatched=${mismatch}` +
    `${prunedSample.length ? ` pruned_sample=${prunedSample.join(',')}` : ''}${badSample.length ? ` MISMATCH=${badSample.join(',')}` : ''}`);
}

// Fixture provenance: the four assigned arms are append/field mutations of the committed registry.
const valid = reg.covered;
for (const [id, file] of [
  ['c1-malformed-json', 'c1-malformed-json.json'],
  ['c2-version-2', 'c2-version-2.json'],
  ['c3-covered-not-array', 'c3-covered-not-array.json'],
  ['c3b-covered-string-x', 'c3b-covered-string-x.json'],
  ['c12-covered-object', 'c12-covered-object.json'],
  ['c4-covered-outside-namespace', 'c4-covered-outside.json'],
]) {
  const p = join(HERE, 'scratch', file);
  let summary;
  try {
    const d = JSON.parse(readFileSync(p, 'utf8'));
    const extra = Array.isArray(d.covered) ? d.covered.filter((x) => !valid.includes(x)) : [];
    const missing = Array.isArray(d.covered) ? valid.filter((x) => !d.covered.includes(x)) : valid;
    summary = `version=${JSON.stringify(d.version)} covered_type=${Array.isArray(d.covered) ? 'array' : JSON.stringify(typeof d.covered)} covered_len=${Array.isArray(d.covered) ? d.covered.length : JSON.stringify(d.covered)} added_vs_committed=${JSON.stringify(extra)} removed_from_committed=${missing.length}`;
  } catch (e) {
    summary = 'unparseable by design (raw bytes): ' + JSON.stringify(readFileSync(p, 'utf8'));
  }
  add(`fixture ${id} sha256=${shaFile(p)} ${summary}`);
}
const m3obj = JSON.parse(readFileSync(join(OUT, 'mutants.json'), 'utf8'));
const c12 = m3obj.find((m) => m.id === 'm3-covered-array-guard-deleted').arms.find((a) => a.arm === 'c12-covered-object');
add(`m3 c12-covered-object stderr_first_line=${JSON.stringify(c12.stderr)} exit=${c12.mutant}`);

writeFileSync(join(OUT, 'provenance.txt'), `${lines.join('\n')}\n`);

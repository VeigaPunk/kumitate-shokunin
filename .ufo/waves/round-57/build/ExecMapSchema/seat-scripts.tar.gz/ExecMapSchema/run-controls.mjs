#!/usr/bin/env node
// Scratch execution controls for gate `readme-map` (contract kumitate-readme-map-v1),
// round 57 seat ExecMapSchema. Reads only the scratch copy under this build dir and
// writes only under this build dir. Never touches lane production files.
//
// Each fixture is a registry file; the README and corpus dirs are the byte-identical
// scratch copy of the lane's corpus. The gate never writes.
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
// --root <dir> selects the tree under test; default is the byte-identical scratch copy.
const rootArg = process.argv.indexOf('--root');
const ROOT = rootArg > -1 ? resolve(process.argv[rootArg + 1]) : join(HERE, 'scratch');
const LABEL = rootArg > -1 ? process.argv[rootArg + 1].replace(/[^A-Za-z0-9._-]+/g, '_') : 'scratch-copy';
const GATE = join(ROOT, 'scripts', 'readme-map.mjs');
const README = join(ROOT, 'corpus', 'README.md');
const KD = join(ROOT, 'corpus', 'knowledge');
const LD = join(ROOT, 'corpus', 'lessons');
const OUT = join(HERE, 'out');
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');
const valid = JSON.parse(readFileSync(join(ROOT, '.ufo', 'pins', 'readme-map.json'), 'utf8'));

const write = (name, value) => {
  const p = join(HERE, 'scratch', name);
  writeFileSync(p, typeof value === 'string' ? value : `${JSON.stringify(value, null, 2)}\n`);
  return p;
};

// c0 positive / c1..c4 the four assigned FAIL-CLOSED arms / c5..c8 uncovered branches of
// the same schema guard (duplicate, non-string, missing key, null) / c9..c11 boundary of
// the namespace predicate (subdirectory, traversal-looking, root-level file).
const mkdirpRegistry = () => { const d = join(HERE, 'scratch', 'registry-as-dir'); rmSync(d, { recursive: true, force: true }); mkdirSync(d, { recursive: true }); return d; };
const cases = [
  { id: 'c0-valid', expect: 0, why: 'positive control: scratch copy of the committed registry must be CLEAN (harness is wired)', reg: join(ROOT, '.ufo', 'pins', 'readme-map.json') },
  { id: 'c1-malformed-json', expect: 2, why: 'assigned arm 1: registry is not parseable JSON', reg: write('c1-malformed-json.json', '{ "version": 1, "covered": [ "knowledge/a.md",\n') },
  { id: 'c2-version-2', expect: 2, why: 'assigned arm 2: registry version 2', reg: write('c2-version-2.json', { version: 2, covered: valid.covered }) },
  { id: 'c3-covered-not-array', expect: 2, why: 'assigned arm 3: covered is a string, not an array', reg: write('c3-covered-not-array.json', { version: 1, covered: 'knowledge/agent-isolation-substrates.md' }) },
  { id: 'c4-covered-outside-namespace', expect: 2, why: 'assigned arm 4: covered entry outside knowledge|lessons/', reg: write('c4-covered-outside.json', { version: 1, covered: [...valid.covered, 'scripts/readme-map.md'] }) },
  { id: 'c5-covered-duplicated', expect: 2, why: 'same guard, not in the gate selftest: duplicated covered entry', reg: write('c5-covered-duplicated.json', { version: 1, covered: [...valid.covered, valid.covered[0]] }) },
  { id: 'c6-covered-non-string', expect: 2, why: 'same guard, not in the gate selftest: covered entry is a number', reg: write('c6-covered-non-string.json', { version: 1, covered: [...valid.covered, 7] }) },
  { id: 'c7-covered-key-missing', expect: 2, why: 'same guard, not in the gate selftest: `covered` key absent', reg: write('c7-covered-missing.json', { version: 1 }) },
  { id: 'c8-covered-null', expect: 2, why: 'same guard, not in the gate selftest: `covered` is null', reg: write('c8-covered-null.json', { version: 1, covered: null }) },
  { id: 'c9-covered-subdirectory', expect: 2, why: 'namespace boundary: entry names a nested path, regex admits one segment only', reg: write('c9-covered-subdir.json', { version: 1, covered: [...valid.covered, 'knowledge/sub/a.md'] }) },
  { id: 'c10-covered-traversal', expect: 2, why: 'namespace boundary: entry tries to climb out of the namespace', reg: write('c10-covered-traversal.json', { version: 1, covered: [...valid.covered, 'lessons/../knowledge/agent-isolation-substrates.md'] }) },
  { id: 'c11-covered-root-file', expect: 2, why: 'namespace boundary: entry names a root-level README', reg: write('c11-covered-root.json', { version: 1, covered: [...valid.covered, 'README.md'] }) },
  { id: 'c3b-covered-string-x', expect: 2, why: 'assigned arm 3, probe-exact shape: the frozen B4(c) arm sets covered to the string "x"', reg: write('c3b-covered-string-x.json', { version: 1, covered: 'x' }) },
  { id: 'c12-covered-object', expect: 2, why: 'assigned arm 3, second shape: covered is an object (a bare for-of would throw, not fail closed)', reg: write('c12-covered-object.json', { version: 1, covered: {} }) },
  { id: 'c13-namespace-case', expect: 2, why: 'namespace boundary: capitalized namespace must not pass', reg: write('c13-covered-case.json', { version: 1, covered: [...valid.covered, 'Knowledge/agent-isolation-substrates.md'] }) },
  { id: 'c14-wrong-extension', expect: 2, why: 'namespace boundary: .markdown is not the covered extension', reg: write('c14-covered-ext.json', { version: 1, covered: [...valid.covered, 'lessons/x.markdown'] }) },
  { id: 'c15-trailing-slash', expect: 2, why: 'namespace boundary: trailing slash names no file', reg: write('c15-covered-slash.json', { version: 1, covered: [...valid.covered, 'lessons/x.md/'] }) },
  { id: 'c18-registry-array', expect: 2, why: 'schema guard not in the gate selftest: registry is a top-level array', reg: write('c18-registry-array.json', [1, 2, 3]) },
  { id: 'c19-registry-string', expect: 2, why: 'schema guard not in the gate selftest: registry is a top-level string', reg: write('c19-registry-string.json', '"v1"') },
  { id: 'c20-registry-directory', expect: 2, why: 'schema guard not in the gate selftest: registry path is a directory', reg: mkdirpRegistry() },
  { id: 'c16-readme-absent', expect: 2, why: 'the fifth frozen B4 arm: corpus/README.md removed, valid registry', reg: join(ROOT, '.ufo', 'pins', 'readme-map.json'), readme: join(HERE, 'scratch', 'no-such-README.md') },
  { id: 'c17-corpus-dir-absent', expect: 2, why: 'fail-closed sibling: a corpus dir missing (proves the fail-closed family stays wired)', reg: join(ROOT, '.ufo', 'pins', 'readme-map.json'), corpus_override: true },
];

const rows = [];
for (const c of cases) {
  const argv = [GATE, '--registry', resolve(c.reg), '--readme', c.readme || README, '--corpus', KD, '--corpus', c.corpus_override ? join(HERE, 'scratch', 'no-such-dir', 'lessons') : LD];
  const r = spawnSync(process.execPath, argv, { encoding: 'utf8', timeout: 120_000 });
  const rec = {
    id: c.id, why: c.why, expect: c.expect, status: r.status, signal: r.signal,
    stdout: (r.stdout || '').trim(), stderr: (r.stderr || '').trim(),
    registry_sha256: (() => { try { return sha(c.reg); } catch { return 'not-a-regular-file'; } })(), argv,
  };
  rec.ok = r.status === c.expect;
  rows.push(rec);
  process.stdout.write(`[${rec.ok ? 'OK  ' : 'MISS'}] ${c.id} exit=${r.status} expect=${c.expect} :: ${rec.stdout}\n`);
}

const summary = {
  root: ROOT, label: LABEL, gate: GATE, gate_sha256: sha(GATE), readme: README, readme_sha256: sha(README),
  corpus_dirs: [KD, LD], cases: rows,
  passed: rows.filter((r) => r.ok).length, total: rows.length,
};
writeFileSync(join(OUT, `controls-${LABEL}.json`), `${JSON.stringify(summary, null, 2)}\n`);
const lines = [];
for (const r of rows) {
  lines.push(`=== ${r.id} (expect ${r.expect}) ===`);
  lines.push(`# ${r.why}`);
  lines.push(`$ node ${r.argv.map((a) => (a.includes(' ') ? JSON.stringify(a) : a)).join(' ')}`);
  lines.push(`registry_sha256=${r.registry_sha256}`);
  if (r.stdout) lines.push(`stdout: ${r.stdout.split('\n').join('\n        ')}`);
  if (r.stderr) lines.push(`stderr: ${r.stderr.split('\n').join('\n        ')}`);
  lines.push(`exit=${r.status}${r.signal ? ` signal=${r.signal}` : ''} ${r.ok ? 'CONTROL-OK' : 'CONTROL-MISS'}`);
  lines.push('');
}
lines.push(`CONTROLS: ${summary.passed}/${summary.total} at ${new Date().toISOString()}`);
writeFileSync(join(OUT, `controls-${LABEL}.txt`), `${lines.join('\n')}\n`);
process.stdout.write(`CONTROLS: ${summary.passed}/${summary.total}\n`);
process.exit(summary.passed === summary.total ? 0 : 1);

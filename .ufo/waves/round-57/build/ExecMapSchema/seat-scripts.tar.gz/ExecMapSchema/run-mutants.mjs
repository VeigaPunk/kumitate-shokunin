#!/usr/bin/env node
// Mutation controls for gate `readme-map`, round 57 seat ExecMapSchema.
// Each mutant is a private copy of the R1 extracted tree (rev-f0dc6d1) with ONE
// surgical change to scripts/readme-map.mjs. Baseline exits come from
// out/controls-rev-f0dc6d1.json (the unmutated run of the same fixtures).
// Writes only under this build dir.
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpSync, existsSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const BASE = join(HERE, 'rev-f0dc6d1');
const OUT = join(HERE, 'out');
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');
const base = JSON.parse(readFileSync(join(OUT, 'controls-rev-f0dc6d1.json'), 'utf8'));
const baseExit = Object.fromEntries(base.cases.map((c) => [c.id, c.status]));
const fixture = (id) => ({
  'c1-malformed-json': 'c1-malformed-json.json',
  'c2-version-2': 'c2-version-2.json',
  'c3-covered-not-array': 'c3-covered-not-array.json',
  'c3b-covered-string-x': 'c3b-covered-string-x.json',
  'c4-covered-outside-namespace': 'c4-covered-outside.json',
  'c9-covered-subdirectory': 'c9-covered-subdir.json',
  'c11-covered-root-file': 'c11-covered-root.json',
  'c12-covered-object': 'c12-covered-object.json',
  'c13-namespace-case': 'c13-covered-case.json',
  'c14-wrong-extension': 'c14-covered-ext.json',
  'c15-trailing-slash': 'c15-covered-slash.json',
}[id]);

// Each mutation is (label, find, replace, arms[fixture ids we expect to move]).
const mutants = [
  {
    id: 'm1-namespace-regex-weakened',
    note: 'COVERED_RE loses its filename/extension part: any path under knowledge|lessons is accepted',
    find: 'const COVERED_RE = /^(knowledge|lessons)\\/[A-Za-z0-9._-]+\\.md$/;',
    replace: 'const COVERED_RE = /^(knowledge|lessons)\\//;',
    arms: ['c4-covered-outside-namespace', 'c9-covered-subdirectory', 'c11-covered-root-file', 'c13-namespace-case', 'c14-wrong-extension', 'c15-trailing-slash'],
  },
  {
    id: 'm2-version-guard-inverted',
    note: 'the version guard accepts 2 instead of 1',
    find: 'if (doc.version !== 1) {',
    replace: 'if (doc.version !== 2) {',
    arms: ['c2-version-2'],
  },
  {
    id: 'm3-covered-array-guard-deleted',
    note: 'the `covered` array guard (and its reason string) is deleted; iteration proceeds on whatever shape',
    find: "  if (!Array.isArray(doc.covered)) {\n    return { ok: false, reason: 'registry covered not an array' };\n  }\n",
    replace: '',
    arms: ['c3-covered-not-array', 'c3b-covered-string-x', 'c12-covered-object'],
  },
  {
    id: 'm4-per-entry-scope-guard-deleted',
    note: 'the per-entry namespace/type guard is deleted; only the duplicate check remains',
    find: '    if (typeof p !== \'string\' || !COVERED_RE.test(p)) {',
    replace: '    if (typeof p !== \'string\') {',
    arms: ['c4-covered-outside-namespace', 'c9-covered-subdirectory', 'c11-covered-root-file'],
  },
];

const lines = [];
const records = [];
for (const m of mutants) {
  const root = join(HERE, `mut-${m.id}`);
  rmSync(root, { recursive: true, force: true });
  cpSync(BASE, root, { recursive: true });
  const gate = join(root, 'scripts', 'readme-map.mjs');
  const before = readFileSync(gate, 'utf8');
  const hits = before.split(m.find).length - 1;
  if (hits !== 1) {
    lines.push(`### ${m.id}: ABORT, anchor matched ${hits} times (want exactly 1)`);
    records.push({ id: m.id, abort: `anchor hits=${hits}` });
    continue;
  }
  const after = before.replace(m.find, m.replace);
  writeFileSync(gate, after);
  writeFileSync(join(OUT, `${m.id}.diff.txt`), `# ${m.note}\n# find:\n${m.find}\n# replace:\n${m.replace}\n# gate_sha256_before=${sha(join(BASE, 'scripts', 'readme-map.mjs'))}\n# gate_sha256_after=${sha(gate)}\n`);
  lines.push(`### ${m.id} — ${m.note}`);
  lines.push(`gate_sha256 before=${sha(join(BASE, 'scripts', 'readme-map.mjs'))} after=${sha(gate)}`);
  const armRecs = [];
  for (const armId of m.arms) {
    const reg = join(HERE, 'scratch', fixture(armId));
    const r = spawnSync(process.execPath, [gate, '--registry', reg, '--readme', join(root, 'corpus', 'README.md'),
      '--corpus', join(root, 'corpus', 'knowledge'), '--corpus', join(root, 'corpus', 'lessons')],
    { encoding: 'utf8', timeout: 120_000 });
    const rec = { arm: armId, baseline: baseExit[armId], mutant: r.status, stdout: (r.stdout || '').trim(), stderr: (r.stderr || '').trim().split('\n')[0] };
    armRecs.push(rec);
    lines.push(`  ${armId}: baseline_exit=${rec.baseline} mutant_exit=${r.status} ${r.status === rec.baseline ? 'UNCHANGED' : 'FLIPPED'} :: ${rec.stdout || rec.stderr}`);
  }
  records.push({ id: m.id, note: m.note, gate_sha256: sha(gate), arms: armRecs });
  lines.push('');
}

writeFileSync(join(OUT, 'mutants.json'), `${JSON.stringify(records, null, 2)}\n`);
writeFileSync(join(OUT, 'mutants.txt'), `${lines.join('\n')}\n`);
process.stdout.write(`${lines.join('\n')}\n`);
process.exit(0);

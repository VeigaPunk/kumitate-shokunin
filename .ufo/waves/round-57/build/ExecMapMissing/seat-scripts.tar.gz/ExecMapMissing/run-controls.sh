#!/usr/bin/env bash
# ExecMapMissing — scratch FAIL-CLOSED controls for scripts/readme-map.mjs
# (round 57, claim C1). Never writes the lane: every mutation happens in a
# per-arm copy under this build directory, extracted from git archive <REV>.
set -u
set -o pipefail

ROOT=/home/vgpnk/Projects/shokunin/kumitate-shokunin
B=$ROOT/.ufo/waves/round-57/build/ExecMapMissing
S=$B/scratch
E=$B/evidence
REV=${REV:-f0dc6d1160e66af65355bd353665adac22bbf4a9}
GATE=scripts/readme-map.mjs
README=corpus/README.md
mkdir -p "$S" "$E"

SUMMARY=$E/99-summary.txt
: > "$SUMMARY"
say() { printf '%s\n' "$*" >> "$SUMMARY"; }

# run_case <evidence-file> <cwd> <argv...>
# Records argv, cwd, stdout, stderr and the exact exit code.
run_case() {
  local out=$1 cwd=$2; shift 2
  {
    printf '$ (cd %s && node %s)\n' "$cwd" "$*"
    printf -- '--- stdout ---\n'
  } > "$out"
  local so se rc
  so=$(cd "$cwd" && node "$@" 2>"$out.stderr"); rc=$?
  se=$(cat "$out.stderr"); rm -f "$out.stderr"
  {
    printf '%s\n' "$so"
    printf -- '--- stderr ---\n%s\n' "$se"
    printf -- '--- exit: %d\n' "$rc"
  } >> "$out"
  return $rc
}

# ---------------------------------------------------------------- 00 context
{
  printf 'date: %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  printf 'node: %s\n' "$(node --version)"
  printf 'lane: %s\n' "$ROOT"
  printf 'tested rev (plan R1 integration tip): %s\n' "$REV"
  printf 'lane HEAD at run: %s\n' "$(git -C "$ROOT" rev-parse HEAD)"
  printf 'gate/registry/README blobs at tested rev:\n'
  git -C "$ROOT" ls-tree "$REV" "$GATE" "$README" .ufo/pins/readme-map.json
  printf 'gate/registry/README blobs at lane HEAD:\n'
  git -C "$ROOT" ls-tree HEAD "$GATE" "$README" .ufo/pins/readme-map.json
  printf 'lane worktree sha256 of the three files (read-only witness):\n'
  (cd "$ROOT" && sha256sum "$GATE" "$README" .ufo/pins/readme-map.json)
  printf 'lane git status --porcelain before run:\n'
  git -C "$ROOT" status --porcelain
  printf 'git archive %s sha256 (revision identity):\n' "$REV"
  git -C "$ROOT" archive "$REV" | sha256sum
} > "$E/00-context.txt" 2>&1

# ---------------------------------------------------------------- 10 pristine
rm -rf "$S/pristine"
mkdir -p "$S/pristine"
P=$S/pristine
git -C "$ROOT" archive "$REV" | tar -x -C "$P"
ex=$?
if [ "$ex" -ne 0 ] || [ ! -f "$P/$GATE" ] || [ ! -f "$P/$README" ] \
   || [ ! -d "$P/corpus/knowledge" ] || [ ! -d "$P/corpus/lessons" ]; then
  printf 'EXTRACTION FAILED exit=%s gate=%s readme=%s\n' "$ex" \
    "$(test -f "$P/$GATE" && echo present || echo absent)" \
    "$(test -f "$P/$README" && echo present || echo absent)" > "$E/10-pristine.txt"
  exit 3
fi
{
  printf 'pristine extracted from %s\n' "$REV"
  printf 'gate present: %s\n' "$(test -f "$P/$GATE" && echo yes || echo no)"
  printf 'README present: %s\n' "$(test -f "$P/$README" && echo yes || echo no)"
  printf 'registry present: %s\n' "$(test -f "$P/.ufo/pins/readme-map.json" && echo yes || echo no)"
  printf 'corpus entries:\n'
  ls -1 "$P/corpus"
  printf 'knowledge *.md count: %s\n' "$(ls -1 "$P/corpus/knowledge"/*.md | wc -l)"
  printf 'lessons *.md count: %s\n' "$(ls -1 "$P/corpus/lessons"/*.md | wc -l)"
  printf 'pristine tar sha256 (before arms):\n'
  tar -C "$P" -cf - . | sha256sum
} > "$E/10-pristine.txt"
tar -C "$P" -cf - . | sha256sum > "$E/10-pristine-manifest-before.sha256"

# ------------------------------------------------------- 11 baseline control
run_case "$E/11-baseline-pristine.txt" "$P" "$P/$GATE" || true
if [ "$(tail -n1 "$E/11-baseline-pristine.txt")" = '--- exit: 0' ]; then
  say "11 baseline pristine: PASS exit 0 ($(grep -m1 '^README_MAP' "$E/11-baseline-pristine.txt"))"
else
  say "11 baseline pristine: UNEXPECTED $(tail -n1 "$E/11-baseline-pristine.txt")"
fi

# ------------------------------------- 12 gate selftest (fixture-level cases)
run_case "$E/12-selftest.txt" "$P" "$P/$GATE" --selftest || true
say "12 selftest: $(grep -m1 'README_MAP_SELFTEST' "$E/12-selftest.txt"); $(grep -m1 '^VERDICT' "$E/12-selftest.txt"); readme-absent: $(grep -m1 '^case readme-absent' "$E/12-selftest.txt"); corpus-dir-missing: $(grep -m1 '^case corpus-dir-missing' "$E/12-selftest.txt"); $(tail -n1 "$E/12-selftest.txt")"

# ------------------------------------------- 20 arm A: corpus/README.md gone
rm -rf "$S/arm-readme-removed"
cp -a "$P" "$S/arm-readme-removed"
A=$S/arm-readme-removed
rm -f "$A/$README"
{
  printf 'mutation: rm -f %s/corpus/README.md\n' "$A"
  printf 'post-mutation corpus listing:\n'
  ls -1 "$A/corpus"
} > "$E/20-arm-readme-removed-mutation.txt"
run_case "$E/20-arm-readme-removed.txt" "$A" "$A/$GATE" || true
line20=$(grep -m1 '^README_MAP' "$E/20-arm-readme-removed.txt")
exit20=$(tail -n1 "$E/20-arm-readme-removed.txt")
if [ "$line20" = 'README_MAP: FAIL-CLOSED reason=README unreadable: ENOENT' ] && [ "$exit20" = '--- exit: 2' ]; then
  say "20 arm README removed: PASS \"$line20\" $exit20"
else
  say "20 arm README removed: UNEXPECTED \"$line20\" $exit20"
fi
# 21 — restore the same tree's README and re-run: verdict must flip back to CLEAN
cp -a "$P/$README" "$A/$README"
run_case "$E/21-arm-readme-restored.txt" "$A" "$A/$GATE" || true
line21=$(grep -m1 '^README_MAP' "$E/21-arm-readme-restored.txt")
exit21=$(tail -n1 "$E/21-arm-readme-restored.txt")
case "$line21" in
  "README_MAP: CLEAN files="*) ok21=1 ;;
  *) ok21=0 ;;
esac
if [ "$ok21" = 1 ] && [ "$exit21" = '--- exit: 0' ]; then
  say "21 same tree, README restored: PASS \"$line21\" $exit21"
else
  say "21 same tree, README restored: UNEXPECTED \"$line21\" $exit21"
fi

# ------------------------------------------- 30 arm B: corpus/lessons removed
rm -rf "$S/arm-dir-lessons-removed"
cp -a "$P" "$S/arm-dir-lessons-removed"
A=$S/arm-dir-lessons-removed
rm -rf "$A/corpus/lessons"
{
  printf 'mutation: rm -rf %s/corpus/lessons\n' "$A"
  printf 'post-mutation corpus listing (README intact):\n'
  ls -1 "$A/corpus"
  printf 'README sha256 after mutation (must equal pristine):\n'
  sha256sum "$A/$README"
} > "$E/30-arm-dir-lessons-removed-mutation.txt"
run_case "$E/30-arm-dir-lessons-removed.txt" "$A" "$A/$GATE" || true
line30=$(grep -m1 '^README_MAP' "$E/30-arm-dir-lessons-removed.txt")
exit30=$(tail -n1 "$E/30-arm-dir-lessons-removed.txt")
case "$line30" in
  "README_MAP: FAIL-CLOSED reason=corpus dir unreadable: $A/corpus/lessons (ENOENT)")
    ok30=1 ;;
  *) ok30=0 ;;
esac
if [ "$ok30" = 1 ] && [ "$exit30" = '--- exit: 2' ]; then
  say "30 arm corpus/lessons removed: PASS \"$line30\" $exit30"
else
  say "30 arm corpus/lessons removed: UNEXPECTED \"$line30\" $exit30"
fi
# 31 — restore corpus/lessons in the same tree: verdict must flip back to CLEAN
cp -a "$P/corpus/lessons" "$A/corpus/lessons"
run_case "$E/31-arm-dir-lessons-restored.txt" "$A" "$A/$GATE" || true
line31=$(grep -m1 '^README_MAP' "$E/31-arm-dir-lessons-restored.txt")
exit31=$(tail -n1 "$E/31-arm-dir-lessons-restored.txt")
case "$line31" in
  "README_MAP: CLEAN files="*) ok31=1 ;;
  *) ok31=0 ;;
esac
if [ "$ok31" = 1 ] && [ "$exit31" = '--- exit: 0' ]; then
  say "31 same tree, corpus/lessons restored: PASS \"$line31\" $exit31"
else
  say "31 same tree, corpus/lessons restored: UNEXPECTED \"$line31\" $exit31"
fi

# ------------------------------------------ 40 arm C: corpus/knowledge removed
rm -rf "$S/arm-dir-knowledge-removed"
cp -a "$P" "$S/arm-dir-knowledge-removed"
A=$S/arm-dir-knowledge-removed
rm -rf "$A/corpus/knowledge"
{
  printf 'mutation: rm -rf %s/corpus/knowledge\n' "$A"
  printf 'post-mutation corpus listing (README intact):\n'
  ls -1 "$A/corpus"
} > "$E/40-arm-dir-knowledge-removed-mutation.txt"
run_case "$E/40-arm-dir-knowledge-removed.txt" "$A" "$A/$GATE" || true
line40=$(grep -m1 '^README_MAP' "$E/40-arm-dir-knowledge-removed.txt")
exit40=$(tail -n1 "$E/40-arm-dir-knowledge-removed.txt")
case "$line40" in
  "README_MAP: FAIL-CLOSED reason=corpus dir unreadable: $A/corpus/knowledge (ENOENT)")
    ok40=1 ;;
  *) ok40=0 ;;
esac
if [ "$ok40" = 1 ] && [ "$exit40" = '--- exit: 2' ]; then
  say "40 arm corpus/knowledge removed: PASS \"$line40\" $exit40"
else
  say "40 arm corpus/knowledge removed: UNEXPECTED \"$line40\" $exit40"
fi
# 41 — restore corpus/knowledge in the same tree: verdict must flip back to CLEAN
cp -a "$P/corpus/knowledge" "$A/corpus/knowledge"
run_case "$E/41-arm-dir-knowledge-restored.txt" "$A" "$A/$GATE" || true
line41=$(grep -m1 '^README_MAP' "$E/41-arm-dir-knowledge-restored.txt")
exit41=$(tail -n1 "$E/41-arm-dir-knowledge-restored.txt")
case "$line41" in
  "README_MAP: CLEAN files="*) ok41=1 ;;
  *) ok41=0 ;;
esac
if [ "$ok41" = 1 ] && [ "$exit41" = '--- exit: 0' ]; then
  say "41 same tree, corpus/knowledge restored: PASS \"$line41\" $exit41"
else
  say "41 same tree, corpus/knowledge restored: UNEXPECTED \"$line41\" $exit41"
fi

# ------------------------------- 50 both dirs removed (whole corpus gone but README kept)
rm -rf "$S/arm-both-dirs-removed"
cp -a "$P" "$S/arm-both-dirs-removed"
A=$S/arm-both-dirs-removed
rm -rf "$A/corpus/knowledge" "$A/corpus/lessons"
run_case "$E/50-arm-both-dirs-removed.txt" "$A" "$A/$GATE" || true
line50=$(grep -m1 '^README_MAP' "$E/50-arm-both-dirs-removed.txt")
exit50=$(tail -n1 "$E/50-arm-both-dirs-removed.txt")
case "$line50" in
  "README_MAP: FAIL-CLOSED reason=corpus dir unreadable: $A/corpus/knowledge (ENOENT)")
    ok50=1 ;;
  *) ok50=0 ;;
esac
if [ "$ok50" = 1 ] && [ "$exit50" = '--- exit: 2' ]; then
  say "50 arm both corpus dirs removed: PASS \"$line50\" $exit50"
else
  say "50 arm both corpus dirs removed: UNEXPECTED \"$line50\" $exit50"
fi

# 55 — adjacent branch in the same FAIL-CLOSED class: dirs present but emptied
rm -rf "$S/arm-empty-corpus"
cp -a "$P" "$S/arm-empty-corpus"
A=$S/arm-empty-corpus
rm -f "$A/corpus/knowledge"/*.md "$A/corpus/lessons"/*.md
{
  printf 'mutation: rm -f %s/corpus/knowledge/*.md %s/corpus/lessons/*.md\n' "$A" "$A"
  printf 'post-mutation *.md counts: knowledge=%s lessons=%s\n' \
    "$(ls -1 "$A/corpus/knowledge"/*.md 2>/dev/null | wc -l)" \
    "$(ls -1 "$A/corpus/lessons"/*.md 2>/dev/null | wc -l)"
} > "$E/55-arm-empty-corpus-mutation.txt"
run_case "$E/55-arm-empty-corpus.txt" "$A" "$A/$GATE" || true
line55=$(grep -m1 '^README_MAP' "$E/55-arm-empty-corpus.txt")
exit55=$(tail -n1 "$E/55-arm-empty-corpus.txt")
case "$line55" in
  "README_MAP: FAIL-CLOSED reason=no *.md under $A/corpus/knowledge + $A/corpus/lessons (empty corpus)")
    ok55=1 ;;
  *) ok55=0 ;;
esac
if [ "$ok55" = 1 ] && [ "$exit55" = '--- exit: 2' ]; then
  say "55 adjacency empty corpus dirs: PASS \"$line55\" $exit55"
else
  say "55 adjacency empty corpus dirs: UNEXPECTED \"$line55\" $exit55"
fi
# 56 — restore both dirs in that tree: verdict must flip back to CLEAN
cp -a "$P/corpus/knowledge/." "$A/corpus/knowledge/"
cp -a "$P/corpus/lessons/." "$A/corpus/lessons/"
run_case "$E/56-arm-empty-corpus-restored.txt" "$A" "$A/$GATE" || true
line56=$(grep -m1 '^README_MAP' "$E/56-arm-empty-corpus-restored.txt")
exit56=$(tail -n1 "$E/56-arm-empty-corpus-restored.txt")
case "$line56" in
  "README_MAP: CLEAN files="*) ok56=1 ;;
  *) ok56=0 ;;
esac
if [ "$ok56" = 1 ] && [ "$exit56" = '--- exit: 0' ]; then
  say "56 same tree, corpus restored: PASS \"$line56\" $exit56"
else
  say "56 same tree, corpus restored: UNEXPECTED \"$line56\" $exit56"
fi

# -------------------------------------------------- 60 pristine isolation check
tar -C "$P" -cf - . | sha256sum > "$E/60-pristine-manifest-after.sha256"
if [ -s "$E/10-pristine-manifest-before.sha256" ] && cmp -s "$E/10-pristine-manifest-before.sha256" "$E/60-pristine-manifest-after.sha256"; then
  say "60 pristine isolation: PASS (pristine manifest unchanged before/after all arms)"
else
  say "60 pristine isolation: FAIL (pristine bytes changed)"
fi

# -------------------------------------------------- 70 lane integrity witness
{
  printf 'lane worktree sha256 after run:\n'
  (cd "$ROOT" && sha256sum "$GATE" "$README" .ufo/pins/readme-map.json)
  printf 'lane git status --porcelain after run:\n'
  git -C "$ROOT" status --porcelain
  printf 'HEAD (must be unchanged): %s\n' "$(git -C "$ROOT" rev-parse HEAD)"
} > "$E/70-lane-integrity-after.txt" 2>&1

unexpected=$(grep -cE 'UNEXPECTED|isolation: FAIL' "$SUMMARY" || true)
: "${unexpected:=0}"
say "unexpected_arms=$unexpected"
say "overall: $([ "$unexpected" = 0 ] && echo PASS || echo FAIL)"
cat "$SUMMARY"
exit "$([ "$unexpected" = 0 ] && echo 0 || echo 1)"

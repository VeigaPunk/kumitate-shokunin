#!/usr/bin/env bash
# Usage: run-probe.sh <label> <probe.mjs> <lane> <rev>
# Captures command line, stdout, stderr, exit code under this directory.
set -u
label=$1; probe=$2; lane=$3; rev=$4
outdir=$(cd "$(dirname "$0")" && pwd)
printf 'cwd=%s\ncmd=node %s %s %s\n' "$outdir" "$probe" "$lane" "$rev" > "$outdir/$label.cmd"
node "$probe" "$lane" "$rev" > "$outdir/$label.stdout" 2> "$outdir/$label.stderr"
code=$?
printf '%s\n' "$code" > "$outdir/$label.exit"
printf '%s exit=%s\n' "$label" "$code"
printf 'stdout:\n'
cat "$outdir/$label.stdout"
printf 'stderr:\n'
cat "$outdir/$label.stderr"

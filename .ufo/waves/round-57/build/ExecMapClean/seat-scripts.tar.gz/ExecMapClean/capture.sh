#!/bin/sh
# Self-contained transcript capture for one readme-map gate invocation.
# usage: capture.sh <workdir> <outfile-base>
set -u
work="$1"
out="$2"
cd "$work" || exit 90
node scripts/readme-map.mjs > "$out.stdout" 2> "$out.stderr"
code=$?
{
  echo "cwd: $work"
  echo "\$ node scripts/readme-map.mjs"
  echo "--- stdout ---"
  cat "$out.stdout"
  echo "--- stderr ---"
  cat "$out.stderr"
  echo "--- exit: $code"
} > "$out"
exit "$code"

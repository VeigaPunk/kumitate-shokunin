#!/bin/sh
# Rebuild the pristine committed-revision extraction used by ExecMapClean.
# Reads only git objects (no index/worktree writes); output stays in this build dir.
set -eu
REV=8c6f5b017d149b18134917378cdbed3b492d8e89
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
HERE=$(cd "$(dirname "$0")" && pwd)
git -C "$LANE" archive --format=tar "$REV" > "$HERE/committed-tree.tar"
rm -rf "$HERE/committed-tree"
mkdir -p "$HERE/committed-tree"
tar -xf "$HERE/committed-tree.tar" -C "$HERE/committed-tree"
printf 'rebuilt from %s files=%s\n' "$REV" "$(find "$HERE/committed-tree" -type f | wc -l)"

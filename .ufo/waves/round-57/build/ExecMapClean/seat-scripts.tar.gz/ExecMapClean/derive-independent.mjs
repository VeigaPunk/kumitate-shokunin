#!/usr/bin/env node
// Independent re-derivation of the kumitate-readme-map-v1 bimap.
// Deliberately does NOT import or copy scripts/readme-map.mjs code paths:
// it parses README rows, lists corpus files and reads the pin registry itself,
// then reports the three sets and their symmetric differences.
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';

const LANE = process.argv[2] || process.cwd();
const REG = '.ufo/pins/readme-map.json';
const README = 'corpus/README.md';
const DIRS = ['knowledge', 'lessons'];

const problems = [];
const pinRaw = readFileSync(resolve(LANE, REG), 'utf8');
let pin;
try { pin = JSON.parse(pinRaw); } catch { problems.push('pin: not JSON'); }
const covered = Array.isArray(pin?.covered) ? pin.covered : [];
if (pin?.version !== 1) problems.push(`pin: version ${JSON.stringify(pin?.version)} !== 1`);
if (!Array.isArray(pin?.covered)) problems.push('pin: covered not array');
for (const c of covered) {
  if (typeof c !== 'string' || !/^(knowledge|lessons)\/[A-Za-z0-9._-]+\.md$/.test(c)) {
    problems.push(`pin: malformed entry ${JSON.stringify(c)}`);
  }
}
if (new Set(covered).size !== covered.length) problems.push('pin: duplicate entries');
const coveredSet = new Set(covered);

const text = readFileSync(resolve(LANE, README), 'utf8');
const rows = [];
const malformed = [];
for (const rawLine of text.split('\n')) {
  const line = rawLine.replace(/^ {0,3}/, '');
  if (!line.startsWith('|')) continue;
  const m = line.match(/^\|\s*`((?:knowledge|lessons)\/[^`]+)`\s*\|/);
  if (m) { rows.push(m[1]); continue; }
  const cell = line.split('|')[1] ?? '';
  if (/^\s*`?(knowledge|lessons)\//.test(cell)) malformed.push(cell.trim().slice(0, 100));
}
const rowSet = new Set(rows);
const dupRows = [...new Set(rows.filter((r, i) => rows.indexOf(r) !== i))];

const files = [];
const perDir = {};
for (const d of DIRS) {
  const names = readdirSync(resolve(LANE, 'corpus', d)).filter((n) => n.endsWith('.md'));
  perDir[d] = names.length;
  for (const n of names) files.push(`${d}/${n}`);
}
files.sort();
const fileSet = new Set(files);

const uncovered = files.filter((f) => !rowSet.has(f));
const orphanRows = [...rowSet].filter((r) => !fileSet.has(r));
const unpinned = files.filter((f) => !coveredSet.has(f));
const staleCovered = covered.filter((c) => !fileSet.has(c));

const clean = problems.length === 0 && uncovered.length === 0 && orphanRows.length === 0 &&
  unpinned.length === 0 && staleCovered.length === 0 && malformed.length === 0 &&
  dupRows.length === 0 && rows.length === files.length && covered.length === files.length;

console.log(JSON.stringify({
  derived: 'independent',
  files: files.length, rows: rows.length, covered: covered.length,
  perDir, distinctRows: rowSet.size, duplicateRows: dupRows, malformedRows: malformed,
  pinProblems: problems, uncovered, orphanRows, unpinned, staleCovered,
  filesMinusCovered: files.filter((f) => !coveredSet.has(f)),
  coveredMinusFiles: covered.filter((c) => !fileSet.has(c)),
  rowsMinusFiles: [...rowSet].filter((r) => !fileSet.has(r)).sort(),
  filesMinusRows: files.filter((f) => !rowSet.has(f)),
  verdict: clean ? 'CONSISTENT' : 'INCONSISTENT',
}, null, 2));
process.exit(clean ? 0 : 1);

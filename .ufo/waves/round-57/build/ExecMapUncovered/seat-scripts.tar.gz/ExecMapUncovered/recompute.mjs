#!/usr/bin/env node
// Independent recomputation of the corpus file <-> README row bimap.
// Deliberately does not import scripts/readme-map.mjs: it re-derives the sets
// from the files on disk so the gate's DRIFT verdict can be corroborated
// (A57 B10 style, but for the mutant copy under this seat's build dir).
// usage: node recompute.mjs <tree-root>
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const root = process.argv[2];
if (!root) { process.stderr.write('usage: node recompute.mjs <tree-root>\n'); process.exit(64); }

const files = [];
for (const d of ['knowledge', 'lessons']) {
  for (const n of readdirSync(join(root, 'corpus', d))) if (n.endsWith('.md')) files.push(`${d}/${n}`);
}
files.sort();

const readme = readFileSync(join(root, 'corpus', 'README.md'), 'utf8');
const rows = [];
for (const line of readme.split('\n')) {
  const m = line.replace(/^ {0,3}/, '').match(/^\|\s*`((?:knowledge|lessons)\/[^`]+)`\s*\|/);
  if (m) rows.push(m[1]);
}

const reg = JSON.parse(readFileSync(join(root, '.ufo', 'pins', 'readme-map.json'), 'utf8'));

const fileSet = new Set(files);
const rowSet = new Set(rows);
const covered = new Set(reg.covered);
const uncovered = files.filter((f) => !rowSet.has(f));
const orphans = rows.filter((r) => !fileSet.has(r));
const dupes = [...new Set(rows.filter((r, i) => rows.indexOf(r) !== i))];
const stale = [...covered].filter((c) => !fileSet.has(c));
const uncoveredCovered = [...covered].filter((c) => !rowSet.has(c));
const unpinned = files.filter((f) => !covered.has(f));

const fmt = (a) => (a.length ? a.join(',') : '-');
console.log(`RECOMPUTE root=${root}`);
console.log(`files=${files.length} rows=${rows.length} covered=${reg.covered.length}`);
console.log(`uncovered=${fmt(uncovered)}`);
console.log(`orphans=${fmt(orphans)}`);
console.log(`dupes=${fmt(dupes)}`);
console.log(`stale=${fmt(stale)}`);
console.log(`uncoveredCovered=${fmt(uncoveredCovered)}`);
console.log(`unpinned=${fmt(unpinned)}`);
process.exit(0);

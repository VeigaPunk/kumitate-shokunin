#!/usr/bin/env node
// Mutant probes: do the committed cases (selftest + A57 B4 arms) pin the
// covered-entry validation rules? Mutations run only in build-dir scratch copies.
import { spawnSync } from 'node:child_process';
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const LANE = '/home/vgpnk/Projects/shokunin/kumitate-shokunin';
const B = join(LANE, '.ufo/waves/round-57/build/SentinelRegistryPaths');
const BASE = JSON.parse(readFileSync(join(LANE, '.ufo/pins/readme-map.json'), 'utf8'));
const BASE_COVERED = [...BASE.covered];

function scratch(id) {
  const S = join(B, 'mutants', id);
  rmSync(S, { recursive: true, force: true });
  mkdirSync(join(S, 'scripts'), { recursive: true });
  mkdirSync(join(S, 'corpus'), { recursive: true });
  cpSync(join(LANE, 'corpus/knowledge'), join(S, 'corpus/knowledge'), { recursive: true });
  cpSync(join(LANE, 'corpus/lessons'), join(S, 'corpus/lessons'), { recursive: true });
  cpSync(join(LANE, 'corpus/README.md'), join(S, 'corpus/README.md'));
  return S;
}

function runGate(S, reg, extraArgs) {
  const r = spawnSync(process.execPath, [
    join(S, 'scripts/readme-map.mjs'), '--registry', reg,
    '--readme', join(S, 'corpus/README.md'),
    '--corpus', join(S, 'corpus/knowledge'), '--corpus', join(S, 'corpus/lessons'),
  ], { encoding: 'utf8', timeout: 60_000 });
  const lines = `${r.stdout || ''}`.trim().split('\n');
  return { status: r.status, last: lines[lines.length - 1] || '', stdout: `${r.stdout || ''}` };
}

const writeReg = (S, id, covered, version) => {
  const p = join(S, `${id}.json`);
  writeFileSync(p, JSON.stringify({ version: version === undefined ? 1 : version, covered }));
  return p;
};

const out = [];
function probe(label, S, covered, version) {
  const reg = writeReg(S, 'reg-' + label.replace(/[^a-z0-9]+/gi, '-'), covered, version);
  const r = runGate(S, reg);
  out.push({ label, status: r.status, last: r.last });
}

// b4 arms as coded in attest57-probe.mjs B4 (a..e)
function b4(S) {
  const arms = {};
  // (a) malformed JSON
  {
    const p = join(S, 'b4a.json'); writeFileSync(p, '{ not json');
    arms.a_malformed = runGate(S, p).status;
  }
  // (b) version 2
  arms.b_version2 = runGate(S, writeReg(S, 'b4b', BASE_COVERED, 2)).status;
  // (c) covered non-array
  {
    const p = join(S, 'b4c.json'); writeFileSync(p, JSON.stringify({ version: 1, covered: 'x' }));
    arms.c_nonarray = runGate(S, p).status;
  }
  // (d) covered push scripts/escape.md
  arms.d_scope = runGate(S, writeReg(S, 'b4d', [...BASE_COVERED, 'scripts/escape.md'])).status;
  // (e) README removed
  {
    const rp = join(S, 'corpus/README.md');
    const before = readFileSync(rp);
    rmSync(rp);
    arms.e_readme = runGate(S, writeReg(S, 'b4e', BASE_COVERED)).status;
    writeFileSync(rp, before);
  }
  return arms;
}

function selftest(S) {
  const r = spawnSync(process.execPath, [join(S, 'scripts/readme-map.mjs'), '--selftest'], { encoding: 'utf8', timeout: 120_000 });
  const m = `${r.stdout}`.match(/README_MAP_SELFTEST: PASS \((\d+)\/(\d+)\)/);
  return { status: r.status, line: m ? m[0] : 'none' };
}

// ---- unmutated control
{
  const S = scratch('control');
  cpSync(join(LANE, 'scripts/readme-map.mjs'), join(S, 'scripts/readme-map.mjs'));
  probe('dup', S, [...BASE_COVERED, BASE_COVERED[0]]);
  probe('trav', S, [...BASE_COVERED, 'knowledge/../scripts/x.md']);
  probe('subdir', S, [...BASE_COVERED, 'lessons/sub/x.md']);
  out.push({ label: 'b4', ...b4(S) }, { label: 'selftest', ...selftest(S) });
}

// ---- MUT-D: delete the duplicate-entry check
{
  const S = scratch('mutD');
  const src = readFileSync(join(LANE, 'scripts/readme-map.mjs'), 'utf8');
  const start = src.indexOf('    if (seen.has(p)) {');
  const end = src.indexOf('    seen.add(p);', start);
  if (start < 0 || end < 0) throw new Error('mutD patch anchors missing');
  const patched = src.slice(0, start) + src.slice(end);
  if (patched === src) throw new Error('mutD patch no-op');
  writeFileSync(join(S, 'scripts/readme-map.mjs'), patched);
  probe('dup', S, [...BASE_COVERED, BASE_COVERED[0]]);
  probe('dup3', S, [...BASE_COVERED, BASE_COVERED[0], BASE_COVERED[0]]);
  probe('trav', S, [...BASE_COVERED, 'knowledge/../scripts/x.md']);
  out.push({ label: 'b4', ...b4(S) }, { label: 'selftest', ...selftest(S) });
}

// ---- MUT-R: relax COVERED_RE to allow nested segments
{
  const S = scratch('mutR');
  const src = readFileSync(join(LANE, 'scripts/readme-map.mjs'), 'utf8');
  const patched = src.replace(
    'const COVERED_RE = /^(knowledge|lessons)\\/[A-Za-z0-9._-]+\\.md$/;',
    'const COVERED_RE = /^(knowledge|lessons)\\/.+\\.md$/;');
  if (patched === src) throw new Error('mutR patch no-op');
  writeFileSync(join(S, 'scripts/readme-map.mjs'), patched);
  probe('trav', S, [...BASE_COVERED, 'knowledge/../scripts/x.md']);
  probe('subdir', S, [...BASE_COVERED, 'lessons/sub/x.md']);
  probe('abs', S, [...BASE_COVERED, '/etc/passwd.md']);
  out.push({ label: 'b4', ...b4(S) }, { label: 'selftest', ...selftest(S) });
}

const txt = out.map((o) => JSON.stringify(o)).join('\n') + '\n';
writeFileSync(join(B, 'mutants.txt'), txt);
console.log(txt);

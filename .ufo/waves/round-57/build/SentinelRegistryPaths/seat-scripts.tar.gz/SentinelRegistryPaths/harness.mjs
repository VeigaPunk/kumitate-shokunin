#!/usr/bin/env node
// SentinelRegistryPaths — attack harness for the readme-map registry surface.
// Runs entirely inside .ufo/waves/round-57/build/SentinelRegistryPaths/.
// Never writes to the lane tree outside this build dir.
import { spawnSync } from 'node:child_process';
import {
  appendFileSync, cpSync, lstatSync, mkdirSync, readFileSync, readdirSync,
  rmSync, symlinkSync, writeFileSync,
} from 'node:fs';
import { join } from 'node:path';

const LANE = '/home/vgpnk/Projects/shokunin/kumitate-shokunin';
const B = join(LANE, '.ufo/waves/round-57/build/SentinelRegistryPaths');
const SB = join(B, 'sandbox');
const GATE = join(SB, 'scripts/readme-map.mjs');
const README = join(SB, 'corpus/README.md');
const KD = join(SB, 'corpus/knowledge');
const LD = join(SB, 'corpus/lessons');
const BASE = JSON.parse(readFileSync(join(LANE, '.ufo/pins/readme-map.json'), 'utf8'));
const BASE_COVERED = [...BASE.covered];
const REGDIR = join(B, 'regs');

mkdirSync(REGDIR, { recursive: true });

function resetSandbox() {
  rmSync(SB, { recursive: true, force: true });
  mkdirSync(join(SB, 'scripts'), { recursive: true });
  mkdirSync(join(SB, 'corpus'), { recursive: true });
  cpSync(join(LANE, 'scripts/readme-map.mjs'), GATE);
  cpSync(join(LANE, 'corpus/knowledge'), KD, { recursive: true });
  cpSync(join(LANE, 'corpus/lessons'), LD, { recursive: true });
  cpSync(join(LANE, 'corpus/README.md'), README);
}

function writeReg(id, doc) {
  const p = join(REGDIR, `${id}.json`);
  writeFileSync(p, typeof doc === 'string' ? doc : JSON.stringify(doc, null, 2));
  return p;
}

function runGate(reg, extra = []) {
  const r = spawnSync(process.execPath,
    [GATE, '--registry', reg, '--readme', README, '--corpus', KD, '--corpus', LD, ...extra],
    { encoding: 'utf8', timeout: 60_000 });
  const out = `${r.stdout || ''}`;
  const lines = out.trim().split('\n');
  return { status: r.status, last: lines[lines.length - 1] || '', stdout: out, stderr: `${r.stderr || ''}`.trim() };
}

const results = [];
function caseReg(id, cls, desc, covered, expect, mutate) {
  if (mutate) mutate();
  const reg = writeReg(id, { version: 1, covered });
  const r = runGate(reg);
  record(id, cls, desc, expect, r);
}
function record(id, cls, desc, expect, r, detail) {
  const pass = expect === 'CLEAN' ? r.status === 0
    : expect === 'DRIFT' ? r.status === 1
      : r.status === 2;
  results.push({
    id, cls, desc, expect,
    status: r.status, verdict: (r.last.match(/^README_MAP: (\S+)/) || [])[1] || 'none',
    last: r.last, stderr: r.stderr, pass, detail: detail || null,
    silent_accept: expect !== 'CLEAN' && r.status === 0,
  });
}

// ---------------------------------------------------------------- baseline
resetSandbox();
{
  const reg = writeReg('base', BASE);
  record('base', 'baseline', 'shipped registry against shipped corpus+README', 'CLEAN', runGate(reg),
    { files: readdirSync(KD).filter((n) => n.endsWith('.md')).length + readdirSync(LD).filter((n) => n.endsWith('.md')).length });
}

// ------------------------------------------------- registry JSON injections
const A = (id, cls, desc, extra, expect) => caseReg(id, cls, desc, [...BASE_COVERED, ...extra], expect);

A('trav-1', 'traversal', 'covered entry knowledge/../scripts/x.md', ['knowledge/../scripts/x.md'], 'FC');
A('trav-2', 'traversal', 'covered entry knowledge/../../../../etc/passwd.md', ['knowledge/../../../../etc/passwd.md'], 'FC');
A('trav-3', 'traversal', 'covered entry lessons/../../corpus/knowledge/a.md', ['lessons/../../corpus/knowledge/a.md'], 'FC');
A('abs-1', 'absolute', 'covered entry /etc/passwd.md', ['/etc/passwd.md'], 'FC');
A('abs-2', 'absolute', 'covered entry absolute lane path to a live doc',
  [`${LANE}/corpus/knowledge/agent-isolation-substrates.md`], 'FC');
A('sub-1', 'subdir', 'covered entry lessons/sub/x.md', ['lessons/sub/x.md'], 'FC');
A('sub-2', 'subdir', 'covered entry knowledge/sub/agent-isolation-substrates.md', ['knowledge/sub/agent-isolation-substrates.md'], 'FC');
A('dup-1', 'duplicate', 'covered repeats an existing entry once', [BASE_COVERED[0]], 'FC');
A('dup-2', 'duplicate', 'covered repeats the same entry twice more', [BASE_COVERED[5], BASE_COVERED[5]], 'FC');
A('type-num', 'non-string', 'covered entry 42', [42], 'FC');
A('type-null', 'non-string', 'covered entry null', [null], 'FC');
A('type-bool', 'non-string', 'covered entry true', [true], 'FC');
A('type-obj', 'non-string', 'covered entry {"path":"knowledge/x.md"}', [{ path: 'knowledge/x.md' }], 'FC');
A('type-arr', 'non-string', 'covered entry ["knowledge/x.md"]', [['knowledge/x.md']], 'FC');
A('fmt-empty', 'format', 'covered entry ""', [''], 'FC');
A('fmt-dironly', 'format', 'covered entry knowledge/', ['knowledge/'], 'FC');
A('fmt-dslash', 'format', 'covered entry knowledge//agent-isolation-substrates.md', ['knowledge//agent-isolation-substrates.md'], 'FC');
A('fmt-dotseg', 'format', 'covered entry knowledge/./agent-isolation-substrates.md', ['knowledge/./agent-isolation-substrates.md'], 'FC');
A('fmt-trail', 'format', 'covered entry with trailing slash', ['knowledge/agent-isolation-substrates.md/'], 'FC');
A('fmt-nul', 'format', 'covered entry with trailing NUL', ['knowledge/agent-isolation-substrates.md\u0000'], 'FC');
A('fmt-nl', 'format', 'covered entry with trailing newline', ['knowledge/agent-isolation-substrates.md\n'], 'FC');
A('fmt-space', 'format', 'covered entry with leading space', [' knowledge/agent-isolation-substrates.md'], 'FC');
A('fmt-case', 'format', 'covered entry with Knowledge/ case', ['Knowledge/agent-isolation-substrates.md'], 'FC');
A('fmt-backslash', 'format', 'covered entry knowledge\\..\\x.md', ['knowledge\\..\\x.md'], 'FC');
A('fmt-urlenc', 'format', 'covered entry knowledge/%2e%2e/x.md', ['knowledge/%2e%2e/x.md'], 'FC');
A('fmt-prefix', 'format', 'covered entry knowledgex/a.md', ['knowledgex/a.md'], 'FC');
A('stale-shape', 'semantic', 'covered entry valid shape, no file (knowledge/definitely-not-here.md)',
  ['knowledge/definitely-not-here.md'], 'DRIFT');
A('dot-dot-md', 'semantic', 'covered entry knowledge/..md (regex-legal literal name, no file)', ['knowledge/..md'], 'DRIFT');

// non-array / version shapes
const docCase = (id, desc, doc, expect) => {
  const reg = writeReg(id, doc);
  record(id, 'schema', desc, expect, runGate(reg));
};
docCase('covered-string', 'covered is a string, not array', { version: 1, covered: BASE_COVERED[0] }, 'FC');
docCase('covered-obj', 'covered is an object', { version: 1, covered: {} }, 'FC');
docCase('version-absent', 'version key absent', { covered: BASE_COVERED }, 'FC');
docCase('version-2', 'version 2', { version: 2, covered: BASE_COVERED }, 'FC');
docCase('version-str', 'version "1" (string)', { version: '1', covered: BASE_COVERED }, 'FC');
docCase('version-float', 'version 1.0 (JSON float, JS-numeric 1)', { version: 1.0, covered: BASE_COVERED }, 'CLEAN');
docCase('version-null', 'version null', { version: null, covered: BASE_COVERED }, 'FC');
docCase('covered-empty', 'covered [] while corpus present', { version: 1, covered: [] }, 'DRIFT');
docCase('extra-key', 'extra top-level key "note"', { version: 1, covered: BASE_COVERED, note: 'x' }, 'CLEAN');
docCase('proto-key', 'payload carries a __proto__ key', '{"version":1,"covered":' + JSON.stringify(BASE_COVERED) + ',"__proto__":{"covered":[]}}', 'CLEAN');

// registry file-type / path attacks
{
  rmSync(join(B, 'regdir'), { recursive: true, force: true });
  mkdirSync(join(B, 'regdir'));
  record('path-dir', 'registry-type', 'registry path is a directory', 'FC', runGate(join(B, 'regdir')));

  const good = writeReg('good-target', BASE);
  const linkGood = join(B, 'reg-link-good.json');
  rmSync(linkGood, { force: true });
  symlinkSync(good, linkGood);
  record('path-symlink-good', 'registry-type', 'registry path is a symlink to a valid registry', 'FC', runGate(linkGood));

  const linkDangling = join(B, 'reg-link-dangling.json');
  rmSync(linkDangling, { force: true });
  symlinkSync(join(B, 'does-not-exist.json'), linkDangling);
  record('path-symlink-dangling', 'registry-type', 'registry path is a dangling symlink', 'FC', runGate(linkDangling));

  record('path-devnull', 'registry-type', 'registry path is /dev/null', 'FC', runGate('/dev/null'));

  const bad = writeReg('bad-json', '{ not json');
  record('json-malformed', 'registry-type', 'registry body is not JSON', 'FC', runGate(bad));
  const empty = join(REGDIR, 'empty.json');
  writeFileSync(empty, '');
  record('json-empty', 'registry-type', 'registry body is zero bytes', 'FC', runGate(empty));
  const truncated = join(REGDIR, 'trunc.json');
  writeFileSync(truncated, JSON.stringify(BASE).slice(0, 200));
  record('json-truncated', 'registry-type', 'registry body truncated JSON', 'FC', runGate(truncated));
}

// --------------------------------------------------- corpus member members
function freshCorpusCase(id, desc, mutate, expect, extraCovered, extraRow) {
  resetSandbox();
  mutate({ KD, LD, README });
  const covered = extraCovered ? [...BASE_COVERED, ...extraCovered] : [...BASE_COVERED];
  const reg = writeReg(id, { version: 1, covered });
  if (extraRow) for (const nm of extraRow) appendFileSync(README, `| \`${nm}\` | sentinel probe | x |\n`);
  const r = runGate(reg);
  const memberType = extraCovered && extraCovered[0]
    ? (() => { try { return lstatSync(join(SB, 'corpus', extraCovered[0])); } catch { return null; } })() : null;
  record(id, 'corpus-member', desc, expect, r, memberType ? {
    lstat_isFile: memberType.isFile(), lstat_isDirectory: memberType.isDirectory(),
    lstat_isSymbolicLink: memberType.isSymbolicLink(),
  } : null);
}

freshCorpusCase('mem-symlink-out', 'corpus member knowledge/zlinkout.md -> /etc/hostname (row+covered added)',
  ({ KD: k }) => symlinkSync('/etc/hostname', join(k, 'zlinkout.md')),
  'CLEAN', ['knowledge/zlinkout.md'], ['knowledge/zlinkout.md']);
freshCorpusCase('mem-symlink-dangling', 'corpus member knowledge/zlinkdang.md -> /nonexistent/target.md (row+covered added)',
  ({ KD: k }) => symlinkSync('/nonexistent/target.md', join(k, 'zlinkdang.md')),
  'CLEAN', ['knowledge/zlinkdang.md'], ['knowledge/zlinkdang.md']);
freshCorpusCase('mem-symlink-sibling', 'corpus member knowledge/zlinksib.md -> agent-isolation-substrates.md (row+covered added)',
  ({ KD: k }) => symlinkSync('agent-isolation-substrates.md', join(k, 'zlinksib.md')),
  'CLEAN', ['knowledge/zlinksib.md'], ['knowledge/zlinksib.md']);
freshCorpusCase('mem-dir-md', 'corpus member lessons/zdirmember.md is a DIRECTORY (row+covered added)',
  ({ LD: d }) => mkdirSync(join(d, 'zdirmember.md')),
  'CLEAN', ['lessons/zdirmember.md'], ['lessons/zdirmember.md']);
freshCorpusCase('mem-symlink-unpoliced', 'dangling symlink member present with NO row and NO covered entry',
  ({ KD: k }) => symlinkSync('/nonexistent/target.md', join(k, 'zlinkdang.md')),
  'DRIFT', [], []);
freshCorpusCase('mem-replace-with-dir', 'live doc knowledge/agent-isolation-substrates.md replaced by a DIRECTORY, row+covered untouched',
  ({ KD: k }) => { rmSync(join(k, 'agent-isolation-substrates.md')); mkdirSync(join(k, 'agent-isolation-substrates.md')); },
  'CLEAN', [], []);
freshCorpusCase('mem-remove-file', 'live doc knowledge/agent-isolation-substrates.md deleted, row+covered untouched',
  ({ KD: k }) => rmSync(join(k, 'agent-isolation-substrates.md')),
  'DRIFT', [], []);
freshCorpusCase('mem-corpusdir-symlink', 'corpus dir itself is a symlink to the real corpus/knowledge',
  () => {
    rmSync(KD, { recursive: true, force: true });
    symlinkSync(join(LANE, 'corpus/knowledge'), KD);
  },
  'FC', [], []);

// ------------------------------------------------------------------ output
const summary = results.map((r) => ({
  id: r.id, class: r.cls, expect: r.expect, status: r.status, verdict: r.verdict,
  pass: r.pass, silent_accept: r.silent_accept, detail: r.detail,
  last: r.last.slice(0, 200),
}));
writeFileSync(join(B, 'results.json'), JSON.stringify(summary, null, 2) + '\n');
writeFileSync(join(B, 'results.ndjson'), summary.map((s) => JSON.stringify(s)).join('\n') + '\n');

const pad = (s, n) => `${s}`.padEnd(n);
console.log(pad('id', 24) + pad('class', 15) + pad('exp', 8) + pad('status', 7) + pad('verdict', 12) + 'last');
for (const s of summary) {
  console.log(pad(s.id, 24) + pad(s.class, 15) + pad(s.expect, 8) + pad(s.status, 7) + pad(s.verdict, 12) + s.last);
}
const fails = summary.filter((s) => !s.pass);
const silent = summary.filter((s) => s.silent_accept);
console.log('');
console.log(`CASES total=${summary.length} pass=${summary.length - fails.length} mismatch=${fails.length} silent_accept=${silent.length}`);
if (fails.length) console.log('MISMATCH ' + fails.map((f) => `${f.id}(exp=${f.expect},got=${f.status})`).join(' '));
if (silent.length) console.log('SILENT ' + silent.map((s) => s.id).join(' '));
process.exit(0);

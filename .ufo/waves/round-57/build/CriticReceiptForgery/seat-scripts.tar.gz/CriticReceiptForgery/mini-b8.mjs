#!/usr/bin/env node
/**
 * mini-b8.mjs — byte-faithful reimplementation of attest57-probe.mjs arm B8
 * (attest57-probe.mjs:334-363) applied to an arbitrary receipts dir inside an
 * arbitrary extraction. Used to score FORGED receipt sets with the probe's
 * own logic: same file list, same verify --ledger, same nonce sweep command,
 * same span rule.
 *
 *   node mini-b8.mjs <lane> <rev> <dir> <f1,f2,f3>
 */
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const [laneArg, rev, dirArg, filesCsv] = process.argv.slice(2);
const lane = resolve(laneArg);
const dir = resolve(dirArg);
const files = filesCsv.split(',');
const run = (args, opts = {}) => spawnSync(args[0], args.slice(1), { encoding: 'utf8', timeout: 120_000, maxBuffer: 32 << 20, ...opts });
const git = (args) => run(['git', '-C', lane, ...args]);
const nodeRun = (args) => spawnSync(process.execPath, args, { cwd: dir, encoding: 'utf8', timeout: 120_000, maxBuffer: 32 << 20 });
const SCRIPT = join(lane, 'scripts/receipt-attest.mjs');

let ok = files.every((f) => existsSync(join(dir, f)) && existsSync(join(dir, `${f}.sha256`)));
const nonces = new Set(); const times = [];
const verdicts = [];
if (ok) {
  for (const f of files) {
    const r = nodeRun([SCRIPT, 'verify', '--ledger', dir, join(dir, f)]);
    const vline = `${r.stdout}`.match(/RECEIPT: (\w+)/);
    verdicts.push(`${f}=${vline ? vline[1] : `exit${r.status}`}`);
    if (r.status !== 0 || !vline || vline[1] !== 'VALID') { ok = false; }
    const body = readFileSync(join(dir, f));
    const j = body.toString('utf8').match(/"nonce":\s*"([^"]+)"/);
    const w = body.toString('utf8').match(/run-at:\s*([^\n]+)/) || body.toString('utf8').match(/"wall_start":\s*"([^"]+)"/);
    if (j) nonces.add(j[1]); else ok = false;
    if (w) times.push(Date.parse(w[1].trim()));
  }
  // exact B8 sweep (wildcard pathspecs, git -C lane grep at rev):
  const older = git(['grep', '-ohE', '"nonce":\\s*"[0-9a-f]+"', rev, '--', '.ufo/waves/round-4[89]', '.ufo/waves/round-5[0-6]']);
  let swept = 0, collided = false;
  if (older.status === 0) {
    for (const line of older.stdout.split('\n')) {
      const m = line.match(/"nonce":\s*"([^"]+)"/);
      if (m) { swept += 1; if (nonces.has(m[1])) { ok = false; collided = true; } }
    }
  }
  const span = times.length === files.length ? Math.max(...times) - Math.min(...times) : 0;
  ok = ok && nonces.size === files.length && span >= 300_000;
  console.log(`mini-B8 verdicts: ${verdicts.join(' | ')}`);
  console.log(`mini-B8 sweep: git status=${older.status} nonce_literals_swept=${swept} collision=${collided}`);
  console.log(`mini-B8 nonces=${nonces.size} span_ms=${span}`);
  console.log(`mini-B8 ${ok ? 'PASS' : 'MISS'} (files=${files.length})`);
} else {
  console.log('mini-B8 MISS receipt files missing');
}
process.exit(ok ? 0 : 1);

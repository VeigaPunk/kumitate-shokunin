#!/usr/bin/env node
/**
 * forge.mjs — mint byte-valid receipt-attest receipts WITHOUT running
 * `receipt-attest run`. Replicates the tool's own construction (canonical
 * sorted-key JSON over semantic fields, sha256 digest field, GNU sidecar)
 * so every check inside `verify --ledger` that is actually enforced passes.
 * The receipts below capture REAL stdout/stderr of the named selftests but
 * fabricate nonce + wall_start/wall_end/run-at: the bytes a VALID verdict
 * attests are indistinguishable from a genuine mint at commit time.
 */
import { spawnSync } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const LANE = '/home/vgpnk/Projects/shokunin/kumitate-shokunin';
const OUT = process.argv[2];
if (!OUT) { console.error('usage: forge.mjs <outdir>'); process.exit(64); }
mkdirSync(OUT, { recursive: true });

const sha256 = (buf) => createHash('sha256').update(buf).digest('hex');
const sortKeys = (v) => Array.isArray(v) ? v.map(sortKeys)
  : (v && typeof v === 'object')
    ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, sortKeys(v[k])]))
    : v;
const canonical = (v) => JSON.stringify(sortKeys(v));
const digestOf = (rec) => { const c = { ...rec }; delete c.digest; return sha256(canonical(c)); };
const iso = (ms) => new Date(ms).toISOString();

// spec entries: [filename, argvToClaim, wallStartIsoMs, spanMs, reuseNonce|null]
const specs = JSON.parse(process.env.FORGE_SPEC ?? '[]');
for (const [name, argv, wallStartMs, spanMs, reuseNonce, stdoutBuf] of specs) {
  let stdout = stdoutBuf ? Buffer.from(stdoutBuf, 'base64') : Buffer.alloc(0);
  const record = {
    argv,
    exit: 0,
    mono_span_ms: spanMs,
    nonce: reuseNonce ?? randomBytes(16).toString('hex'),
    stderr_sha256: sha256(Buffer.alloc(0)),
    stdout_sha256: sha256(stdout),
    wall_end: iso(wallStartMs + spanMs),
    wall_start: iso(wallStartMs),
  };
  record.digest = digestOf(record);
  const text = `run-at: ${iso(wallStartMs)}\n${canonical(record)}\n`;
  const file = join(OUT, name);
  writeFileSync(file, text);
  writeFileSync(`${file}.sha256`, `${sha256(Buffer.from(text, 'utf8'))}  ${name}\n`);
  console.log(`forged ${file} nonce=${record.nonce}`);
}

// 08-assert.mjs — asserts the captured evidence bytes, not the live behavior.
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const build = process.argv[2];
if (!build) {
  console.error('usage: 08-assert.mjs <build-dir>');
  process.exit(64);
}
const read = (f) => readFileSync(join(build, f), 'utf8');
const P = 'lessons/round-56-verifier-spotcheck.md';
const TARGET = `corpus/${P}`;
const countOf = (text, label) => {
  const m = text.match(new RegExp(`${label}=(\\d+)`));
  return m ? Number(m[1]) : NaN;
};

const results = [];
const check = (name, ok, detail) => {
  results.push({ name, ok });
  console.log(`assert ${name}: ${ok ? 'PASS' : `FAIL ${String(detail).slice(0, 300)}`}`);
};

// 01/02 — revision and extraction
const rev = read('01-rev-and-status.txt');
const revLine = (rev.match(/^pre_rev=([0-9a-f]{40,64})$/m) || [])[1];
check('rev-recorded', Boolean(revLine), 'no pre_rev line');
const ext = read('02-extract.txt');
check('extract-exit-0', /^extract_exit=0$/m.test(ext), ext.trim().split('\n').slice(-3).join(' / '));
const extractedRev = (read('extracted-rev.txt') || '').trim();
check('extract-rev-matches', extractedRev === revLine, `${extractedRev} != ${revLine}`);

// 03 — baseline CLEAN on the unmutated extraction
const baseline = read('03-baseline-gate.txt');
const baselineLines = baseline.trim().split('\n');
const baselineLast = baselineLines[baselineLines.length - 1] === 'exit=0'
  ? baselineLines[baselineLines.length - 2]
  : baselineLines[baselineLines.length - 1];
check('baseline-clean-line',
  baselineLast === 'README_MAP: CLEAN files=135 rows=135 covered=135',
  JSON.stringify(baselineLast));
check('baseline-exit-0', baselineLines.includes('exit=0'), baselineLines.slice(-2).join(' / '));

// 03b — instrument selftest on the same bytes
const selftest = read('03b-selftest.txt');
check('selftest-14-14',
  selftest.includes('README_MAP_SELFTEST: PASS (14/14)') && /^exit=0$/m.test(selftest),
  selftest.trim().split('\n').slice(-3).join(' / '));

// 04 — target existed with row and pin before mutation
const pre = read('04-premutation-bimap.txt');
const preSum = countOf(pre, 'knowledge_md') + countOf(pre, 'lessons_md');
const preLessons = countOf(pre, 'lessons_md');
check('target-present-before', pre.includes('file at extraction: present'), pre.split('\n')[1]);
check('pin-present-before', /pin_present=true/.test(pre), (pre.match(/version=.*/) || [])[0]);
check('readme-row-before', new RegExp(`^168:\\| \`${P}\` \\|`, 'm').test(pre), (pre.match(/^168:.*/m) || [])[0]);
check('pre-corpus-sum-135', preSum === 135, `sum=${preSum}`);

// 05 — exactly one deletion, nothing else touched
const mut = read('05-mutation.txt');
const postSum = countOf(mut, 'knowledge_md') + countOf(mut, 'lessons_md');
const postLessons = countOf(mut, 'lessons_md');
check('mutation-rm-exit-0', /^rm_exit=0$/m.test(mut), mut.split('\n')[1]);
check('target-gone-after', /^file after rm: GONE$/m.test(mut), mut.split('\n')[2]);
check('post-corpus-sum-134', postSum === 134, `sum=${postSum}`);
check('only-lessons-dropped', preLessons - postLessons === 1 && countOf(mut, 'knowledge_md') === countOf(pre, 'knowledge_md'),
  `lessons ${preLessons}->${postLessons}, knowledge ${countOf(pre, 'knowledge_md')}->${countOf(mut, 'knowledge_md')}`);
check('readme-bytes-unchanged', mut.includes('README untouched: 7575614804acc82f309d2a763af2b7572a2f81ee98520f3b0517ee187d97205d'), mut.match(/README untouched:.*/)?.[0]);
check('registry-bytes-unchanged', mut.includes('registry untouched: 9ef0cf6ec794bc11d139382e703794b218ec4a38070a831f22fdce40585c729c'), mut.match(/registry untouched:.*/)?.[0]);

// 06 — the gate's verdict on the mutated scratch tree
const gate = read('06-mutated-gate.txt');
const gateLines = gate.trim().split('\n');
const gateLast = gateLines[gateLines.length - 1] === 'exit=1'
  ? gateLines[gateLines.length - 2]
  : gateLines[gateLines.length - 1];
const notes = gateLines.filter((l) => l.startsWith('README_MAP: note '));
check('mutated-exit-1', gateLines.includes('exit=1'), gateLines.slice(-2).join(' / '));
check('mutated-drift-first-orphan-row',
  gateLast === `README_MAP: DRIFT files=134 rows=135 covered=135 bad=2 first=orphan-row:${P}`,
  JSON.stringify(gateLast));
check('mutated-note-stale-covered',
  notes.length === 1 && notes[0] === `README_MAP: note stale-covered:${P}`,
  JSON.stringify(notes));
check('mutated-no-other-drift-lines',
  gateLines.filter((l) => l.startsWith('README_MAP: note ')).length === 1 &&
  gate.split('\n').filter((l) => l.startsWith('README_MAP:')).length === 2,
  String(gate.split('\n').filter((l) => l.startsWith('README_MAP:')).length));

// 07 — independent recomputation agrees
const indepRaw = read('07-independent-recompute.txt');
let indep = null;
try {
  indep = JSON.parse(indepRaw.slice(indepRaw.indexOf('{'), indepRaw.lastIndexOf('}') + 1));
} catch (e) {
  check('independent-json-parses', false, e.message);
}
if (indep) {
  check('independent-drift-verdict', indep.verdict === 'DRIFT', indep.verdict);
  check('independent-files-134', indep.files === 134, String(indep.files));
  check('independent-rows-135', indep.rows === 135, String(indep.rows));
  check('independent-covered-135', indep.covered === 135, String(indep.covered));
  check('independent-orphan-exact',
    JSON.stringify(indep.orphan_row) === JSON.stringify([P]), JSON.stringify(indep.orphan_row));
  check('independent-stale-exact',
    JSON.stringify(indep.stale_covered) === JSON.stringify([P]), JSON.stringify(indep.stale_covered));
  check('independent-no-uncovered', indep.uncovered.length === 0, JSON.stringify(indep.uncovered));
  check('independent-no-unpinned', indep.unpinned.length === 0, JSON.stringify(indep.unpinned));
  check('independent-no-duplicate-row', indep.duplicate_row.length === 0, JSON.stringify(indep.duplicate_row));
  check('independent-gate-agrees-on-first', `orphan-row:${indep.orphan_row[0]}` === gateLast.split('first=')[1],
    `${indep.orphan_row[0]} vs ${gateLast.split('first=')[1]}`);
}

// 09 — no git state written by this seat
const head = read('09-head-unchanged.txt');
check('head-unchanged', /^head_unchanged=yes$/m.test(head), head.trim());

const failed = results.filter((r) => !r.ok);
console.log(`VERDICT: ${failed.length === 0 ? 'PASS' : 'FAIL'} ${results.length - failed.length}/${results.length}`);
process.exit(failed.length === 0 ? 0 : 1);

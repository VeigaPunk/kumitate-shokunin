#!/usr/bin/env bash
# ExecMapOrphan — readme-map orphan-row mutation probe (round 57, seat ExecMapOrphan).
# Scratch-only: extracts <rev> with `git archive` into this build dir, deletes ONE
# corpus file there, re-runs the gate. Production lane is never written.
# Fail-fast: every stage asserts its own success before the next runs.
set -u
BUILD="$(cd "$(dirname "$0")" && pwd)"
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
TARGET=corpus/lessons/round-56-verifier-spotcheck.md
SCRATCH="$BUILD/scratch"
TREE="$SCRATCH/tree"
die() { echo "DRIVER-FAIL: $*" >&2; exit 90; }

rm -rf "$SCRATCH"
mkdir -p "$TREE" || die "mkdir tree"

{
  echo "== seat ExecMapOrphan round-57 =="
  echo "date: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "lane: $LANE"
  echo "node: $(node --version)"
  echo "bash: $BASH_VERSION"
  echo "== rev record (read-only) =="
  git -C "$LANE" rev-parse HEAD
  git -C "$LANE" log -1 --format='%H %s'
  git -C "$LANE" status --porcelain
  echo "== pre-extraction HEAD =="
  PRE=$(git -C "$LANE" rev-parse HEAD) || die "rev-parse"
  echo "pre_rev=$PRE"
  echo "$PRE" > "$BUILD/pre-rev.txt"
} > "$BUILD/01-rev-and-status.txt" 2>&1 || die "01 capture"

PRE=$(cat "$BUILD/pre-rev.txt") || die "read pre-rev"
[[ "$PRE" =~ ^[0-9a-f]{40,64}$ ]] || die "bad rev $PRE"

{
  echo "\$ mkdir -p $TREE"
  echo "\$ git -C $LANE archive $PRE | tar -x -C $TREE"
  set -o pipefail
  git -C "$LANE" archive "$PRE" | tar -x -C "$TREE"
  rc=$?
  echo "extract_exit=$rc"
  [[ $rc -eq 0 ]] || exit 21
  [[ -f "$TREE/scripts/readme-map.mjs" ]] || { echo "missing gate in extraction"; exit 21; }
  [[ -f "$TREE/corpus/README.md" ]] || { echo "missing README in extraction"; exit 21; }
  [[ -f "$TREE/.ufo/pins/readme-map.json" ]] || { echo "missing registry in extraction"; exit 21; }
  echo "extracted_files=$(find "$TREE" -type f | wc -l)"
  echo "$PRE" > "$BUILD/extracted-rev.txt"
} > "$BUILD/02-extract.txt" 2>&1 || die "extract -> $BUILD/02-extract.txt"
echo "driver: extraction ok"

run_gate() { # $1 = evidence file
  {
    echo "\$ cd $TREE && node scripts/readme-map.mjs"
    cd "$TREE" || exit 22
    node scripts/readme-map.mjs
    echo "exit=$?"
  } > "$1" 2>&1
}

# ---- 03 baseline: gate CLEAN on the unmutated extraction (defaults resolve inside scratch)
run_gate "$BUILD/03-baseline-gate.txt" || die "baseline gate"
grep -q '^README_MAP: CLEAN files=135 rows=135 covered=135$' "$BUILD/03-baseline-gate.txt" \
  || die "baseline not CLEAN at extracted rev"
grep -q '^exit=0$' "$BUILD/03-baseline-gate.txt" || die "baseline exit != 0"
echo "driver: baseline CLEAN 135/135/135 exit 0"

# ---- 03b instrument selftest on the same extracted bytes (hermetic)
{
  echo "\$ cd $TREE && node scripts/readme-map.mjs --selftest"
  cd "$TREE" || exit 22
  node scripts/readme-map.mjs --selftest
  echo "exit=$?"
} > "$BUILD/03b-selftest.txt" 2>&1 || die "selftest run"
grep -q 'README_MAP_SELFTEST: PASS (14/14)' "$BUILD/03b-selftest.txt" || die "selftest not 14/14"
echo "driver: selftest 14/14"

# ---- 04 pre-mutation proof of the bimap triple (file, row, pin)
{
  echo "== target: $TARGET =="
  test -f "$TREE/$TARGET" && echo "file at extraction: present" || echo "file at extraction: ABSENT"
  sha256sum "$TREE/$TARGET"
  echo "README row (grep -n):"
  grep -n 'round-56-verifier-spotcheck' "$TREE/corpus/README.md"
  echo "registry pin:"
  node -e 'const d=require(process.argv[1]);const p="lessons/round-56-verifier-spotcheck.md";console.log("version="+d.version+" covered_n="+d.covered.length+" pin_present="+d.covered.includes(p));' "$TREE/.ufo/pins/readme-map.json"
  echo "knowledge_md=$(ls "$TREE"/corpus/knowledge/*.md | wc -l) lessons_md=$(ls "$TREE"/corpus/lessons/*.md | wc -l)"
} > "$BUILD/04-premutation-bimap.txt" 2>&1
grep -q '^file at extraction: present$' "$BUILD/04-premutation-bimap.txt" || die "target absent pre-mutation"
grep -q 'pin_present=true' "$BUILD/04-premutation-bimap.txt" || die "target unpinned pre-mutation"
grep -q '^168:| `lessons/round-56-verifier-spotcheck.md` |' "$BUILD/04-premutation-bimap.txt" || die "no README row pre-mutation"
echo "driver: pre-mutation triple present (file, row@168, pin)"

# ---- 05 mutation: delete exactly one corpus file in the scratch tree
{
  echo "\$ rm -- $TREE/$TARGET"
  rm -- "$TREE/$TARGET"
  echo "rm_exit=$?"
  echo "file after rm: $(test -e "$TREE/$TARGET" && echo PRESENT || echo GONE)"
  echo "knowledge_md=$(ls "$TREE"/corpus/knowledge/*.md | wc -l) lessons_md=$(ls "$TREE"/corpus/lessons/*.md | wc -l)"
  echo "README untouched: $(sha256sum "$TREE/corpus/README.md")"
  echo "registry untouched: $(sha256sum "$TREE/.ufo/pins/readme-map.json")"
} > "$BUILD/05-mutation.txt" 2>&1
grep -q '^rm_exit=0$' "$BUILD/05-mutation.txt" || die "rm failed"
grep -q '^file after rm: GONE$' "$BUILD/05-mutation.txt" || die "target still present"
echo "driver: exactly one file deleted"

# ---- 06 mutated gate run
run_gate "$BUILD/06-mutated-gate.txt" || die "mutated gate run"
echo "driver: mutated gate captured"

# ---- 07 independent recomputation (own parser from the documented contract, not gate code)
{
  echo "\$ node $BUILD/07-independent-recompute.mjs $TREE"
  node "$BUILD/07-independent-recompute.mjs" "$TREE"
  echo "exit=$?"
} > "$BUILD/07-independent-recompute.txt" 2>&1
grep -q '"verdict": "DRIFT"' "$BUILD/07-independent-recompute.txt" || die "independent recompute not DRIFT"
echo "driver: independent recomputation DRIFT"

# ---- 09 post-run HEAD unchanged (no git state written by this seat) — run before assertions
{
  echo "post_rev=$(git -C "$LANE" rev-parse HEAD)"
  echo "pre_rev=$(cat "$BUILD/pre-rev.txt")"
  git -C "$LANE" rev-parse HEAD | diff - "$BUILD/pre-rev.txt" && echo "head_unchanged=yes"
} > "$BUILD/09-head-unchanged.txt" 2>&1
grep -q '^head_unchanged=yes$' "$BUILD/09-head-unchanged.txt" || die "HEAD moved during probe"
echo "driver: HEAD unchanged"

# ---- 08 machine assertions over the captured bytes
{
  echo "== assertions =="
  node "$BUILD/08-assert.mjs" "$BUILD"
} > "$BUILD/08-assertions.txt" 2>&1
grep -q '^VERDICT: PASS' "$BUILD/08-assertions.txt" || die "assertions failed -> $BUILD/08-assertions.txt"
echo "driver: assertions PASS"

echo "DRIVER: COMPLETE"

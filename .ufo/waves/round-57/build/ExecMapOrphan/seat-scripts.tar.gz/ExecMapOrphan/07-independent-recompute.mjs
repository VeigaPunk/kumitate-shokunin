// 07-independent-recompute.mjs — re-derives the file<->row<->pin bimap from the
// contract text alone (own regexes/readdir), never importing the gate's code.
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const tree = process.argv[2];
if (!tree) {
  console.error('usage: 07-independent-recompute.mjs <tree>');
  process.exit(64);
}

const registry = JSON.parse(readFileSync(join(tree, '.ufo/pins/readme-map.json'), 'utf8'));
const readme = readFileSync(join(tree, 'corpus/README.md'), 'utf8');

const files = [];
for (const dir of ['knowledge', 'lessons']) {
  for (const n of readdirSync(join(tree, 'corpus', dir))) {
    if (n.endsWith('.md')) files.push(`${dir}/${n}`);
  }
}
files.sort();

const rows = [];
for (const line of readme.split('\n')) {
  const m = line.replace(/^ {0,3}/, '').match(/^\|\s*`((?:knowledge|lessons)\/[^`]+)`\s*\|/);
  if (m) rows.push(m[1]);
}

const fileSet = new Set(files);
const rowSet = new Set(rows);
const covered = Array.isArray(registry.covered) ? registry.covered : [];
const covSet = new Set(covered);

const orphan = rows.filter((r) => !fileSet.has(r));
const uncovered = files.filter((f) => !rowSet.has(f));
const stale = covered.filter((c) => !fileSet.has(c));
const unpinned = files.filter((f) => !covSet.has(f));
const dupRows = rows.filter((r, i) => rows.indexOf(r) !== i);

const out = {
  version: registry.version,
  files: files.length,
  rows: rows.length,
  covered: covered.length,
  orphan_row: [...new Set(orphan)].sort(),
  stale_covered: stale.sort(),
  uncovered,
  unpinned,
  duplicate_row: [...new Set(dupRows)],
  verdict: orphan.length || uncovered.length || stale.length || unpinned.length || dupRows.length ? 'DRIFT' : 'CLEAN',
};
console.log(JSON.stringify(out, null, 2));

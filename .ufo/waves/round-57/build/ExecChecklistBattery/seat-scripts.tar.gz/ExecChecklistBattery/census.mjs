#!/usr/bin/env node
// ExecChecklistBattery — static census of SKILL.md `## Verifiable checklist`.
// Read-only: parses <skillPath>, prints item numbering, command tokens and the
// item 24..27 id->gate bindings. Usage: node census.mjs <skill.md> [label]
import { readFileSync } from 'node:fs';

const [skillPath, label = 'live'] = process.argv.slice(2);
if (!skillPath) { process.stderr.write('usage: node census.mjs <skill.md> [label]\n'); process.exit(64); }
const lines = readFileSync(skillPath, 'utf8').split('\n');

// Section = from `## Verifiable checklist` to the next `## ` heading.
const start = lines.findIndex((l) => /^## Verifiable checklist\s*$/.test(l));
if (start < 0) { process.stderr.write('CENSUS: FAIL-CLOSED section heading absent\n'); process.exit(2); }
let end = lines.length;
for (let i = start + 1; i < lines.length; i++) if (/^## /.test(lines[i])) { end = i; break; }

const section = lines.slice(start, end);
const items = [];
for (let i = 0; i < section.length; i++) {
  const m = section[i].match(/^- \[( |x)\]\s+(.*)$/);
  if (!m) continue;
  const body = m[2];
  const cmd = (body.match(/`([^`]*(?:node|bash|scripts\/)[^`]*)`/g) || [])
    .map((s) => s.slice(1, -1))
    .filter((s) => /^(?:node|bash)\s/.test(s) || /^scripts\//.test(s));
  items.push({ n: items.length + 1, line: start + i + 1, checked: m[1] === 'x', cmd: cmd[0] ?? null, all: cmd, body });
}

// Prose census literals above the list (the intro paragraph of the section).
const prose = section.filter((l) => /\b(?:Twenty|twenty-\w+|Twenty-\w+|\d+ items)\b/.test(l)).slice(0, 3);
const countWord = section.find((l) => /^(?:Twenty|Thirty|Forty)/.test(l)) || '';

const EXPECT = ['counter-pins.mjs', 'source-capture.mjs', 'source-dupes.mjs', 'readme-map.mjs'];
const bindings = [24, 25, 26, 27].map((n, idx) => {
  const it = items[n - 1];
  return {
    n,
    line: it?.line ?? null,
    names: it ? it.cmd : null,
    expect: EXPECT[idx],
    ok: !!it && typeof it.cmd === 'string' && it.cmd.includes(`scripts/${EXPECT[idx]}`),
  };
});

const out = {
  label,
  skillPath,
  section: { headingLine: start + 1, endLine: end },
  items,
  count: items.length,
  checked: items.filter((i) => i.checked).length,
  proseFirstLine: (countWord || '').slice(0, 220),
  proseMentionsRound57: prose.join(' ').includes('round 57'),
  bindings,
  allBindingsOk: bindings.every((b) => b.ok),
};
process.stdout.write(JSON.stringify(out, null, 2) + '\n');

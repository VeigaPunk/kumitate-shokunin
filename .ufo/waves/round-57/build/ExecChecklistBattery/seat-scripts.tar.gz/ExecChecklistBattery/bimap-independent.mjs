#!/usr/bin/env node
// ExecChecklistBattery — INDEPENDENT recomputation of the coverage-map bimap.
// Does not import or execute scripts/readme-map.mjs: re-derives the six finding
// classes from the contract text (`kumitate-readme-map-v1`) so a CLEAN verdict
// can be corroborated (or falsified) by a second implementation.
// Usage: node bimap-independent.mjs <lane-root>
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const lane = process.argv[2];
if (!lane) { process.stderr.write('usage: node bimap-independent.mjs <lane-root>\n'); process.exit(64); }
const ROW = /^\|\s*`((?:knowledge|lessons)\/[^`]+)`\s*\|/;

const files = [];
for (const d of ['knowledge', 'lessons']) {
  for (const n of readdirSync(join(lane, 'corpus', d))) if (n.endsWith('.md')) files.push(`${d}/${n}`);
}
files.sort();

const rows = [];
const formatUnmapped = [];
for (const line0 of readFileSync(join(lane, 'corpus', 'README.md'), 'utf8').split('\n')) {
  const line = line0.replace(/^ {0,3}/u, '');
  if (!line.startsWith('|')) continue;
  const m = line.match(ROW);
  if (m) { rows.push(m[1]); continue; }
  const cell = line.split('|')[1];
  if (cell && /^\s*`?(knowledge|lessons)\//u.test(cell)) formatUnmapped.push(cell.trim().slice(0, 80));
}

const regDoc = JSON.parse(readFileSync(join(lane, '.ufo/pins/readme-map.json'), 'utf8'));
const covered = regDoc.covered;

const fileSet = new Set(files);
const rowSet = new Set(rows);
const coveredSet = new Set(covered);
const findings = {
  'format-unmapped': formatUnmapped,
  'duplicate-row': [...new Set(rows.filter((r, i) => rows.indexOf(r) !== i))],
  'orphan-row': [...new Set(rows.filter((r) => !fileSet.has(r)))],
  uncovered: files.filter((f) => !rowSet.has(f)),
  'stale-covered': covered.filter((c) => !fileSet.has(c)),
  unpinned: files.filter((f) => !coveredSet.has(f)),
};
const bad = Object.values(findings).flat();

process.stdout.write(JSON.stringify({
  lane,
  registry: { version: regDoc.version, covered: covered.length, unique: new Set(covered).size },
  files: files.length,
  rows: rows.length,
  findings,
  verdict: bad.length === 0 ? 'CLEAN' : 'DRIFT',
  bad: bad.length,
}, null, 2) + '\n');
process.exit(bad.length === 0 ? 0 : 1);

#!/usr/bin/env bash
# ScribeScorecardAudit — independent recomputation of SCORECARD stanza terms
# over committed trees (git archive, same extraction method as attest57-probe).
# Writes only inside this seat's own build dir. Lane tree untouched.
set -u
LANE=/home/vgpnk/Projects/shokunin/kumitate-shokunin
B="$LANE/.ufo/waves/round-57/build/ScribeScorecardAudit"
R1=f0dc6d1160e66af65355bd353665adac22bbf4a9   # measured integration rev cited by scorecard
HEADREV=8c6f5b017d149b18134917378cdbed3b492d8e89  # lane tip at audit time
BASE=7178bfd3643c0fac74c8eb637cd6e985faadd0cf # round-57 base

terms() {
  local REV="$1"
  local D="$B/tree-$REV"
  rm -rf "$D"; mkdir -p "$D"
  git -C "$LANE" archive "$REV" | tar -x -C "$D"
  echo "=== rev $REV ==="
  echo "-- A: find . -path ./.git -prune -o -type f ( -name '*.mjs' -o -name '*.js' -o -name '*.sh' -o -name '*.py' ) -print | wc -l"
  (cd "$D" && find . -path ./.git -prune -o -type f \( -name '*.mjs' -o -name '*.js' -o -name '*.sh' -o -name '*.py' \) -print | wc -l)
  echo "-- C: grep -c '^\s*- \[' SKILL.md"
  (cd "$D" && grep -c '^\s*- \[' SKILL.md)
  echo "-- C2 rows: grep -c '^| \`\(knowledge\|lessons\)/' corpus/README.md"
  (cd "$D" && grep -c '^| `\(knowledge\|lessons\)/' corpus/README.md)
  echo "-- C2 files: find corpus/knowledge corpus/lessons -name '*.md' | wc -l"
  (cd "$D" && find corpus/knowledge corpus/lessons -name '*.md' | wc -l)
}

terms "$R1"
terms "$HEADREV"
terms "$BASE"

echo "=== diff SCORECARD.md R1..HEAD ==="
git -C "$LANE" diff "$R1" "$HEADREV" -- SCORECARD.md > "$B/scorecard-r1-to-head.diff"
echo "diff exit=$? lines=$(wc -l < "$B/scorecard-r1-to-head.diff")"

echo "=== live gates at HEAD extraction ==="
if [ -d /home/vgpnk/Projects/origin-work/ufo-fsd-alpha ]; then
  export UFO_SRC=/home/vgpnk/Projects/origin-work/ufo-fsd-alpha
elif [ -d /home/vgpnk/Projects/ufo-fsd-alpha ]; then
  export UFO_SRC=/home/vgpnk/Projects/ufo-fsd-alpha
fi
echo "UFO_SRC=$UFO_SRC"
(cd "$B/tree-$HEADREV" && node scripts/readme-map.mjs; echo "readme-map exit=$?")
(cd "$B/tree-$HEADREV" && node scripts/proxy-check.mjs --strict; echo "proxy-check exit=$?")
(cd "$B/tree-$HEADREV" && node scripts/readme-map.mjs --selftest 2>&1 | tail -3; echo "readme-map-selftest exit=$?")

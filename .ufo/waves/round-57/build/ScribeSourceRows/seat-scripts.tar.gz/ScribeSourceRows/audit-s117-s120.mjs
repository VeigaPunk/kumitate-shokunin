#!/usr/bin/env node
/**
 * audit-s117-s120.mjs — ScribeSourceRows mechanical audit, kumitate round 57.
 *
 * Audits corpus/SOURCES.md rows S117, S118, S119, S120 against the frozen
 * fleet contract SOURCES-CONTRACT-v1 (carried in fleet CORPUS.md) and the
 * lane validator rules encoded in scripts/sources-check.mjs:
 *   - 13 cells (line.split('|') length 13; 11 named columns + 2 edge fields)
 *   - id form S\d{3,}, unique across the registry
 *   - kind/tier/status enums legal; community never tier A
 *   - id + source + kind + tier + scope + anchor + teaches + status +
 *     opened + recheck + used-by all populated
 *   - opened a real proleptic-Gregorian ISO date on/before today
 *   - recheck an ISO date, Nd cadence, or on-release
 *   - rejected row teaches carries `REJECTED:` and `flip:`
 *   - mined row used-by names existing repo-relative paths
 *   - anchor cell sha256/bytes match .ufo/pins/source-captures.json, and the
 *     pinned capture file exists on disk with the pinned digest and size
 * Corroborates (read-only): sources-check.mjs --json on the live lane, the
 * knowledge entry provenance trio, and lane rev / dirty state of audited paths.
 * Writes only under .ufo/waves/round-57/build/ScribeSourceRows/.
 */
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { isAbsolute, join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const LANE = resolve('/home/vgpnk/Projects/shokunin/kumitate-shokunin');
const BUILD = join(LANE, '.ufo/waves/round-57/build/ScribeSourceRows');
const TARGETS = ['S117', 'S118', 'S119', 'S120'];
const TODAY = '2026-10-24';
const KINDS = new Set(['spec', 'docs', 'paper', 'code', 'tool', 'dataset', 'talk', 'book', 'community', 'own-work']);
const TIERS = new Set(['A', 'B', 'C']);
const STATUSES = new Set(['queued', 'mined', 'rejected']);

const sha256 = (b) => createHash('sha256').update(b).digest('hex');
/** Real proleptic-Gregorian ISO date -> integer UTC day; null otherwise. */
function isoDay(value) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!m) return null;
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  const ok = d.getUTCFullYear() === Number(m[1]) && d.getUTCMonth() + 1 === Number(m[2]) && d.getUTCDate() === Number(m[3]);
  return ok ? Math.floor(d.getTime() / 86400000) : null;
}

const log = [];
const P = (...a) => { const s = a.join(' '); log.push(s); console.log(s); };

// ---------------------------------------------------------------- provenance
const srcPath = join(LANE, 'corpus/SOURCES.md');
const srcBytes = readFileSync(srcPath);
P('# provenance');
P(`sources.md sha256=${sha256(srcBytes)} bytes=${srcBytes.length}`);
const git = (args) => spawnSync('git', args, { cwd: LANE, encoding: 'utf8' });
const head = git(['rev-parse', 'HEAD']);
const headRev = (head.stdout || '').trim();
P(`head=${headRev} git-exit=${head.status}`);
const headInfo = git(['log', '-1', '--format=%ci %s']);
P(`head-commit=${(headInfo.stdout || '').trim()}`);
const st = git(['status', '--porcelain', '--', 'corpus/SOURCES.md', '.ufo/pins/source-captures.json', 'corpus/knowledge/worker-heartbeat-liveness.md']);
const dirty = (st.stdout || '').split('\n').map((s) => s.trim()).filter(Boolean);
P(`dirty(audited paths)=${dirty.length === 0 ? 'none' : JSON.stringify(dirty)}`);
P(`today=${TODAY}`);

// ------------------------------------------------------- registry line index
const lines = srcBytes.toString('utf8').split('\n');
const idCount = new Map();
const rowAt = new Map();
for (let i = 0; i < lines.length; i++) {
  const m = /^\|\s*(S\d{3,})\s*\|/.exec(lines[i]);
  if (!m) continue;
  idCount.set(m[1], (idCount.get(m[1]) || 0) + 1);
  if (!rowAt.has(m[1])) rowAt.set(m[1], { n: i + 1, raw: lines[i] });
}
const dups = [...idCount.entries()].filter(([, c]) => c > 1);
P(`registry S-rows=${idCount.size} duplicate-ids=${dups.length === 0 ? 'none' : JSON.stringify(dups)}`);

// ------------------------------------------------------------ capture pins
const pins = JSON.parse(readFileSync(join(LANE, '.ufo/pins/source-captures.json'), 'utf8'));
P(`source-captures.json version=${pins.version} captures=${pins.captures.length}`);
const pinById = new Map(pins.captures.map((c) => [c.sourceId, c]));

// ------------------------------------------------------------ per-row audit
let failures = 0;
const perRow = {};
for (const id of TARGETS) {
  const R = [];
  const chk = (name, ok, detail = '') => { R.push({ check: name, ok, detail }); if (!ok) failures++; };
  const ent = rowAt.get(id);
  if (!ent) { chk('row-present', false, 'row not found in corpus/SOURCES.md'); perRow[id] = R; continue; }
  chk('row-present', true, `line ${ent.n}`);
  const line = ent.raw;
  const fields = line.split('|');
  chk('cells-13', fields.length === 13, `split-fields=${fields.length}; expected 13`);
  const pipes = (line.match(/\|/g) || []).length;
  chk('pipes-12', pipes === 12, `pipes=${pipes}; expected 12 for 11 columns`);
  const t = (i) => (fields[i] ?? '').trim();
  const idCell = t(1);
  chk('id-form', /^S\d{3,}$/.test(idCell), idCell);
  const row = {
    source: t(2), kind: t(3), tier: t(4), scope: t(5), anchor: t(6),
    teaches: t(7), status: t(8), opened: t(9), recheck: t(10), usedBy: t(11),
  };
  chk('kind-enum', KINDS.has(row.kind), row.kind);
  chk('tier-enum', TIERS.has(row.tier), row.tier);
  chk('status-enum', STATUSES.has(row.status), row.status);
  chk('community-not-tier-A', !(row.kind === 'community' && row.tier === 'A'), `kind=${row.kind} tier=${row.tier}`);
  for (const [k, v] of Object.entries({ id: idCell, ...row })) {
    chk(`populated:${k}`, v !== '', k);
  }
  const od = isoDay(row.opened);
  const td = isoDay(TODAY);
  chk('opened-iso-real-and-not-future', od !== null && od <= td, `opened=${row.opened}`);
  const recheckOk = isoDay(row.recheck) !== null || /^(\d+)d$/.test(row.recheck) || row.recheck === 'on-release';
  chk('recheck-form', recheckOk, `recheck=${row.recheck}`);
  if (row.status === 'rejected') {
    chk('rejected-reason-REJECTED:', row.teaches.includes('REJECTED:'), 'teaches lacks REJECTED:');
    chk('rejected-flip:', /\bflip:/u.test(row.teaches), 'teaches lacks flip:');
  }
  if (row.status === 'mined') {
    const parts = row.usedBy.split(',').map((s) => s.trim()).filter((p) => p !== '' && p !== '—');
    chk('mined-usedby-nonempty', parts.length > 0, `used-by=${row.usedBy}`);
    for (const p of parts) {
      const exists = !isAbsolute(p) && existsSync(join(LANE, p));
      chk('usedby-path-exists', exists, p);
    }
  }
  const pin = pinById.get(id);
  if (!pin) {
    chk('capture-pin-present', false, `no .ufo/pins/source-captures.json entry for ${id}`);
  } else {
    const mSha = /body sha256 ([0-9a-f]{64})/.exec(row.anchor);
    const mBy = /([\d,]+) bytes/.exec(row.anchor);
    const anchorSha = mSha ? mSha[1] : null;
    const anchorBytes = mBy ? Number(mBy[1].replace(/,/g, '')) : null;
    chk('anchor-sha256-matches-pin', anchorSha !== null && anchorSha === pin.sha256, `anchor=${anchorSha} pin=${pin.sha256}`);
    chk('anchor-bytes-matches-pin', anchorBytes !== null && anchorBytes === pin.bytes, `anchor=${anchorBytes} pin=${pin.bytes}`);
    chk('pin-captured-date', typeof pin.captured === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(pin.captured), `captured=${pin.captured}`);
    const capPath = join(LANE, pin.path);
    if (!existsSync(capPath)) {
      chk('capture-file-exists', false, pin.path);
    } else {
      const cb = readFileSync(capPath);
      chk('capture-file-exists', true, pin.path);
      chk('capture-file-sha256', sha256(cb) === pin.sha256, `${pin.path} sha256=${sha256(cb)}`);
      chk('capture-file-bytes', cb.length === pin.bytes, `${pin.path} bytes=${cb.length} pin=${pin.bytes}`);
    }
  }
  perRow[id] = R;
}

// ------------------------- mined trio cited by the knowledge entry (asymmetry)
const entryPath = join(LANE, 'corpus/knowledge/worker-heartbeat-liveness.md');
if (!existsSync(entryPath)) {
  P('knowledge-entry MISSING corpus/knowledge/worker-heartbeat-liveness.md');
} else {
  const head5 = readFileSync(entryPath, 'utf8').split('\n').slice(0, 5).join('\n');
  for (const id of ['S117', 'S118', 'S119']) {
    P(`knowledge-entry-cites ${id}=${head5.includes(id) ? 'yes' : 'NO'}`);
  }
  P(`knowledge-entry-trio source=${head5.includes('source:')} verified-at=${head5.includes('verified-at:')} recheck=${head5.includes('recheck:')}`);
}

// --------------------------- corroborating lane validator run (read-only)
P('# corroborating-run node scripts/sources-check.mjs --json (live lane, read-only)');
const v = spawnSync('node', ['scripts/sources-check.mjs', '--json'], { cwd: LANE, encoding: 'utf8' });
P(`sources-check exit=${v.status}`);
P(`sources-check stdout=${(v.stdout || '').trim().slice(0, 4000)}`);
if ((v.stderr || '').trim()) P(`sources-check stderr=${(v.stderr || '').trim().slice(0, 2000)}`);

// ------------------------------------------------------------------ summary
P('# summary');
P(`failures=${failures}`);
for (const id of TARGETS) {
  const R = perRow[id] || [];
  const bad = R.filter((r) => !r.ok);
  P(`${id}: pass=${R.filter((r) => r.ok).length}/${R.length}${bad.length ? ' FAIL: ' + bad.map((r) => `${r.check}[${r.detail}]`).join('; ') : ''}`);
}

writeFileSync(join(BUILD, 'audit-s117-s120.json'), JSON.stringify({ today: TODAY, head: headRev, dirty, sourcesSha256: sha256(srcBytes), perRow, failures }, null, 2) + '\n');
writeFileSync(join(BUILD, 'audit-s117-s120.out.txt'), log.join('\n') + '\n');
process.exitCode = failures === 0 ? 0 : 1;

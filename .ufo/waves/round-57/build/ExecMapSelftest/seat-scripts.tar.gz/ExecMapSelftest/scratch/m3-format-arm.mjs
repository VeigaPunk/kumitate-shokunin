#!/usr/bin/env node
/**
 * readme-map.mjs — gate `readme-map` (contract `kumitate-readme-map-v1`, round 57).
 *
 * The corpus coverage-map bimap gate. `proxy-check`'s C2 term compares only the
 * *counts* of `corpus/README.md` map rows against corpus `*.md` files — so a
 * file landing without a row surfaces one count drift, named and repaired by
 * hand (r52, r55, r56 verifier spotchecks; routed defect R56-V3). This gate
 * makes the mapping itself the contract: every `*.md` under
 * `corpus/knowledge` + `corpus/lessons` must carry exactly one README row
 * `| `path` |`, every such row must name an existing file, and every live
 * file must be pinned in the `covered` set.
 *
 *   node scripts/readme-map.mjs [--registry <path>] [--readme <path>]
 *                               [--corpus <dir>] ...
 *   node scripts/readme-map.mjs --selftest
 *
 * Verdicts (one line on stdout, after optional per-item notes):
 *   README_MAP: CLEAN files=<n> rows=<n> covered=<n>   exit 0
 *   README_MAP: DRIFT files=<n> rows=<n> covered=<m> bad=<k> first=<item>   exit 1
 *   README_MAP: FAIL-CLOSED reason=<why>                exit 2 (could not evaluate)
 *   README_MAP: USAGE ...                               exit 64
 *
 * Registry (default `.ufo/pins/readme-map.json`, lane-root-relative):
 *   { "version": 1, "covered": ["knowledge/x.md", "lessons/y.md", ...] }
 *
 * `covered` is the pinned set of corpus paths (`knowledge/` or `lessons/`
 * relpath, unique) that must BOTH exist AND keep a README row — the ratchet:
 * a corpus file can never lose its row or disappear silently again.
 *
 * Row rule: a coverage-map row is a table line whose FIRST cell is a single
 * backticked `knowledge/…` or `lessons/…` path — `| `knowledge/x.md` | …`.
 * Rows of any other shape in the README are ignored; a row whose first cell
 * *looks* corpus-bound (starts `knowledge/` or `lessons/` but is not a clean
 * backticked path) is DRIFT `format-unmapped`, never silently dropped.
 *
 * Findings:
 *   - DRIFT `uncovered:<path>` — a live `*.md` with no row.
 *   - DRIFT `orphan-row:<path>` — a row naming a path with no file.
 *   - DRIFT `duplicate-row:<path>` — two or more rows for one path.
 *   - DRIFT `format-unmapped:<cell>` — a corpus-shaped first cell that does
 *     not parse as a clean `| `path` |` row.
 *   - DRIFT `stale-covered:<path>` — a `covered` entry whose file is gone.
 *   - DRIFT `unpinned:<path>` — a live file absent from `covered` (the pin
 *     grows by append when a file lands; the registry is never rewritten).
 *   - FAIL-CLOSED (exit 2, never a score): registry unreadable / not JSON /
 *     version ≠ 1 / `covered` not an array / a covered entry malformed,
 *     duplicated or outside `knowledge|lessons/`; README unreadable; a corpus
 *     directory missing; zero `*.md` files across the corpus dirs.
 *
 * The gate never writes. It reads the registry, the README and the corpus
 * directories only.
 *
 * Selftest: hermetic fixtures under mkdtemp, fourteen cases, one red-before
 * per rule; the final line reads `README_MAP_SELFTEST: PASS (14/14)` +
 * `VERDICT: PASS`, exit 0.
 *
 * Exit map: 0 clean · 1 a real defect (drift) · 2 fail-closed · 64 usage.
 * Owner: kumitate L1. Row: SKILL.md §Gate registry (`readme-map`, gate);
 * pin: SCORECARD.md `kumitate-gate-pins-v1` (`pin.readme-map`).
 */
import { spawnSync } from 'node:child_process';
import { lstatSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';

const SELF = fileURLToPath(import.meta.url);
const LANE = resolve(dirname(SELF), '..');
const DEFAULT_REGISTRY = '.ufo/pins/readme-map.json';
const DEFAULT_README = 'corpus/README.md';
const DEFAULT_DIRS = ['corpus/knowledge', 'corpus/lessons'];
const COVERED_RE = /^(knowledge|lessons)\/[A-Za-z0-9._-]+\.md$/;

function usage() {
  process.stderr.write('README_MAP: USAGE node scripts/readme-map.mjs [--registry <path>] [--readme <path>] [--corpus <dir>]... | --selftest\n');
  process.exit(64);
}

function loadRegistry(regPath) {
  let raw;
  try {
    if (!lstatSync(regPath).isFile()) {
      return { ok: false, reason: 'registry not a regular file' };
    }
    raw = readFileSync(regPath);
  } catch (e) {
    return { ok: false, reason: `registry unreadable: ${e.code || 'EIO'}` };
  }
  let doc;
  try {
    doc = JSON.parse(raw.toString('utf8'));
  } catch {
    return { ok: false, reason: 'registry not valid JSON' };
  }
  if (!doc || typeof doc !== 'object' || Array.isArray(doc)) {
    return { ok: false, reason: 'registry not an object' };
  }
  if (doc.version !== 1) {
    return { ok: false, reason: `registry version ${JSON.stringify(doc.version)} !== 1` };
  }
  if (!Array.isArray(doc.covered)) {
    return { ok: false, reason: 'registry covered not an array' };
  }
  const seen = new Set();
  for (const p of doc.covered) {
    if (typeof p !== 'string' || !COVERED_RE.test(p)) {
      return { ok: false, reason: `covered entry malformed: ${JSON.stringify(p)}` };
    }
    if (seen.has(p)) {
      return { ok: false, reason: `covered entry duplicated: ${JSON.stringify(p)}` };
    }
    seen.add(p);
  }
  return { ok: true, covered: doc.covered };
}


function loadRows(readmePath) {
  let raw;
  try {
    if (!lstatSync(readmePath).isFile()) {
      return { ok: false, reason: 'README not a regular file' };
    }
    raw = readFileSync(readmePath, 'utf8');
  } catch (e) {
    return { ok: false, reason: `README unreadable: ${e.code || 'EIO'}` };
  }
  const rows = [];
  const bad = [];
  for (const line0 of raw.split('\n')) {
    const line = line0.replace(/^ {0,3}/, '');
    if (!line.startsWith('|')) continue;
    const m = line.match(/^\|\s*`((?:knowledge|lessons)\/[^`]+)`\s*\|/);
    if (m) { rows.push(m[1]); continue; }
    const firstCell = line.split('|')[1];
    if (firstCell && /^\s*`?(knowledge|lessons)\//.test(firstCell)) {
      void `format-unmapped:${firstCell.trim().slice(0, 80)}`;
    }
  }
  return { ok: true, rows, bad };
}

function loadFiles(dirs) {
  const files = [];
  for (const d of dirs) {
    const base = basename(d);
    if (base !== 'knowledge' && base !== 'lessons') {
      return { ok: false, reason: `corpus dir outside the covered namespace (want knowledge|lessons): ${d}` };
    }
    let names;
    try {
      if (!lstatSync(d).isDirectory()) {
        return { ok: false, reason: `corpus dir not a directory: ${d}` };
      }
      names = readdirSync(d);
    } catch (e) {
      return { ok: false, reason: `corpus dir unreadable: ${d} (${e.code || 'EIO'})` };
    }
    for (const n of names) if (n.endsWith('.md')) files.push(`${base}/${n}`);
  }
  if (files.length === 0) {
    return { ok: false, reason: `no *.md under ${dirs.join(' + ')} (empty corpus)` };
  }
  return { ok: true, files: files.sort() };
}

function evaluate(registryPath, readmePath, dirs) {
  const reg = loadRegistry(registryPath);
  if (!reg.ok) return { verdict: 'FAIL-CLOSED', reason: reg.reason, exit: 2 };
  const rd = loadRows(readmePath);
  if (!rd.ok) return { verdict: 'FAIL-CLOSED', reason: rd.reason, exit: 2 };
  const cf = loadFiles(dirs);
  if (!cf.ok) return { verdict: 'FAIL-CLOSED', reason: cf.reason, exit: 2 };

  const fileSet = new Set(cf.files);
  const bad = [...rd.bad];
  const seen = new Map();
  for (const r of rd.rows) {
    if (seen.has(r)) {
      bad.push(`duplicate-row:${r}`);
    } else {
      seen.set(r, true);
      if (!fileSet.has(r)) bad.push(`orphan-row:${r}`);
    }
  }
  const rowSet = new Set(rd.rows);
  for (const f of cf.files) {
    if (!rowSet.has(f)) bad.push(`uncovered:${f}`);
  }
  const covered = new Set(reg.covered);
  for (const c of reg.covered) {
    if (!fileSet.has(c)) bad.push(`stale-covered:${c}`);
  }
  for (const f of cf.files) {
    if (!covered.has(f)) bad.push(`unpinned:${f}`);
  }
  const stats = { files: cf.files.length, rows: rd.rows.length, covered: reg.covered.length };
  if (bad.length > 0) return { verdict: 'DRIFT', ...stats, bad, exit: 1 };
  return { verdict: 'CLEAN', ...stats, exit: 0 };
}

function emit(result) {
  if (result.verdict === 'CLEAN') {
    process.stdout.write(`README_MAP: CLEAN files=${result.files} rows=${result.rows} covered=${result.covered}\n`);
  } else if (result.verdict === 'DRIFT') {
    for (const b of result.bad.slice(1)) process.stdout.write(`README_MAP: note ${b}\n`);
    process.stdout.write(`README_MAP: DRIFT files=${result.files} rows=${result.rows} covered=${result.covered} bad=${result.bad.length} first=${result.bad[0]}\n`);
  } else {
    process.stdout.write(`README_MAP: FAIL-CLOSED reason=${result.reason}\n`);
  }
  process.exit(result.exit);
}

function selftest() {
  const root = mkdtempSync(join(tmpdir(), 'readme-map-st.'));
  const results = [];
  const pass = (name, ok, detail) => {
    results.push({ name, ok });
    process.stdout.write(`case ${name}: ${ok ? 'PASS' : `FAIL ${detail || ''}`}\n`);
  };
  const run = (args, opts = {}) => spawnSync(process.execPath, [SELF, ...args],
    { encoding: 'utf8', timeout: 60_000, ...opts });
  const last = (r) => `${r.stdout || ''}`.trim().split('\n').pop() || '';
  const mkdirp = (d) => { rmSync(d, { recursive: true, force: true }); mkdirSync(d, { recursive: true }); };
  const fixture = (dir, { files = ['knowledge/a.md', 'lessons/b.md'], rows, covered } = {}) => {
    mkdirp(dir);
    mkdirp(join(dir, 'corpus')); mkdirp(join(dir, 'corpus/knowledge')); mkdirp(join(dir, 'corpus/lessons'));
    for (const f of files) writeFileSync(join(dir, 'corpus', f), `# ${f}\n`);
    const rowText = rows !== undefined ? rows : files.map((f) => `| \`${f}\` | desc | ptr |\n`).join('');
    writeFileSync(join(dir, 'corpus/README.md'), `# README\n\n## Coverage map\n\n${rowText}`);
    writeFileSync(join(dir, 'reg.json'), JSON.stringify({ version: 1, covered: covered !== undefined ? covered : files }, null, 2));
    return { reg: join(dir, 'reg.json'), rm: join(dir, 'corpus/README.md'), kd: join(dir, 'corpus/knowledge'), ld: join(dir, 'corpus/lessons') };
  };
  const argsOf = (f) => ['--registry', f.reg, '--readme', f.rm, '--corpus', f.kd, '--corpus', f.ld];

  try {
    // 1 — clean bimap
    {
      const f = fixture(join(root, 'd1'));
      const r = run(argsOf(f));
      pass('clean', r.status === 0 && last(r) === 'README_MAP: CLEAN files=2 rows=2 covered=2',
        `exit=${r.status} last=${JSON.stringify(last(r))}`);
    }
    // 2 — uncovered: file without row
    {
      const f = fixture(join(root, 'd2'), { rows: '| `knowledge/a.md` | d | p |\n' });
      const r = run(argsOf(f));
      pass('uncovered', r.status === 1 && `${r.stdout}`.includes('uncovered:lessons/b.md'),
        `exit=${r.status} out=${JSON.stringify(`${r.stdout}`.slice(-160))}`);
    }
    // 3 — orphan-row: row without file
    {
      const f = fixture(join(root, 'd3'), { rows: '| `knowledge/a.md` | d | p |\n| `lessons/b.md` | d | p |\n| `lessons/gone.md` | d | p |\n' });
      const r = run(argsOf(f));
      pass('orphan-row', r.status === 1 && `${r.stdout}`.includes('orphan-row:lessons/gone.md'),
        `exit=${r.status} out=${JSON.stringify(`${r.stdout}`.slice(-160))}`);
    }
    // 4 — duplicate-row
    {
      const f = fixture(join(root, 'd4'), { rows: '| `knowledge/a.md` | d | p |\n| `knowledge/a.md` | d2 | p2 |\n| `lessons/b.md` | d | p |\n' });
      const r = run(argsOf(f));
      pass('duplicate-row', r.status === 1 && `${r.stdout}`.includes('duplicate-row:knowledge/a.md'),
        `exit=${r.status} out=${JSON.stringify(`${r.stdout}`.slice(-160))}`);
    }
    // 5 — format-unmapped: corpus-shaped first cell, not a clean row
    {
      const f = fixture(join(root, 'd5'), { rows: '| `knowledge/a.md` | d | p |\n| `lessons/b.md` | d | p |\n| knowledge/stray.md | d | p |\n' });
      const r = run(argsOf(f));
      pass('format-unmapped', r.status === 1 && `${r.stdout}`.includes('format-unmapped:'),
        `exit=${r.status} out=${JSON.stringify(`${r.stdout}`.slice(-160))}`);
    }
    // 6 — stale-covered: covered entry whose file is gone (orphan too)
    {
      const f = fixture(join(root, 'd6'), { covered: ['knowledge/a.md', 'lessons/b.md', 'lessons/gone.md'] });
      const r = run(argsOf(f));
      pass('stale-covered', r.status === 1 && `${r.stdout}`.includes('stale-covered:lessons/gone.md'),
        `exit=${r.status} out=${JSON.stringify(`${r.stdout}`.slice(-160))}`);
    }
    // 7 — unpinned: live file absent from covered
    {
      const f = fixture(join(root, 'd7'), { covered: ['knowledge/a.md'] });
      const r = run(argsOf(f));
      pass('unpinned', r.status === 1 && `${r.stdout}`.includes('unpinned:lessons/b.md'),
        `exit=${r.status} out=${JSON.stringify(`${r.stdout}`.slice(-160))}`);
    }
    // 8 — covered=[] while files remain: unpinned, never vacuous CLEAN
    {
      const f = fixture(join(root, 'd8'), { covered: [] });
      const r = run(argsOf(f));
      pass('empty-covered', r.status === 1 && `${r.stdout}`.includes('unpinned:'),
        `exit=${r.status} out=${JSON.stringify(`${r.stdout}`.slice(-160))}`);
    }
    // 9 — malformed registry JSON: FAIL-CLOSED exit 2
    {
      const f = fixture(join(root, 'd9'));
      writeFileSync(f.reg, '{ not json');
      const r = run(argsOf(f));
      pass('malformed-registry', r.status === 2, `exit=${r.status}`);
    }
    // 10 — registry version 2: FAIL-CLOSED
    {
      const f = fixture(join(root, 'd10'));
      writeFileSync(f.reg, JSON.stringify({ version: 2, covered: [] }));
      const r = run(argsOf(f));
      pass('registry-version', r.status === 2, `exit=${r.status}`);
    }
    // 11 — covered entry outside knowledge|lessons: FAIL-CLOSED
    {
      const f = fixture(join(root, 'd11'), { covered: ['knowledge/a.md', 'lessons/b.md', 'scripts/x.md'] });
      const r = run(argsOf(f));
      pass('covered-scope', r.status === 2, `exit=${r.status}`);
    }
    // 12 — README removed: FAIL-CLOSED
    {
      const f = fixture(join(root, 'd12'));
      rmSync(f.rm);
      const r = run(argsOf(f));
      pass('readme-absent', r.status === 2, `exit=${r.status}`);
    }
    // 13 — corpus dir missing: FAIL-CLOSED
    {
      const f = fixture(join(root, 'd13'));
      rmSync(f.ld, { recursive: true, force: true });
      const r = run(argsOf(f));
      pass('corpus-dir-missing', r.status === 2, `exit=${r.status}`);
    }
    // 14 — non-corpus rows ignored (backticked other paths; prose rows)
    {
      const f = fixture(join(root, 'd14'), {
        rows: '| `knowledge/a.md` | d | `scripts/x.mjs` |\n| `lessons/b.md` | mentions `knowledge/other.md` inside | p |\n| `scripts/tool.mjs` | not corpus | p |\n',
      });
      const r = run(argsOf(f));
      pass('non-corpus-rows', r.status === 0 && last(r) === 'README_MAP: CLEAN files=2 rows=2 covered=2',
        `exit=${r.status} last=${JSON.stringify(last(r))}`);
    }
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
  const passed = results.filter((r) => r.ok).length;
  process.stdout.write(`README_MAP_SELFTEST: PASS (${passed}/${results.length})\n`);
  process.stdout.write(`VERDICT: ${passed === results.length ? 'PASS' : 'FAIL'}\n`);
  process.exit(passed === results.length ? 0 : 1);
}

const argv = process.argv.slice(2);
if (argv.includes('--selftest')) selftest();
let registry = join(LANE, DEFAULT_REGISTRY);
let readme = join(LANE, DEFAULT_README);
const dirs = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--registry' && argv[i + 1]) registry = resolve(argv[++i]);
  else if (a === '--readme' && argv[i + 1]) readme = resolve(argv[++i]);
  else if (a === '--corpus' && argv[i + 1]) dirs.push(resolve(argv[++i]));
  else usage();
}
emit(evaluate(registry, readme, dirs.length ? dirs : DEFAULT_DIRS.map((d) => join(LANE, d))));

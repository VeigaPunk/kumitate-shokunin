#!/usr/bin/env bash
# SentinelArtifacts — follow-up: operator-corpus scope, strace non-read proof, live lane run.
set -u
B=/home/vgpnk/Projects/shokunin/kumitate-shokunin/.ufo/waves/round-57/build/SentinelArtifacts
GATE=/home/vgpnk/Projects/shokunin/kumitate-shokunin/scripts/readme-map.mjs
ROOT=$B/fx2
rm -rf "$ROOT"; mkdir -p "$ROOT" "$B/canary"
printf '# canary\n' > "$B/canary/secret.md"

# E7b — --corpus names a directory OUTSIDE the lane whose basename is "lessons".
C=$ROOT/E7b
mkdir -p "$C/corpus/knowledge" "$C/elsewhere/lessons"
printf '# a\n' > "$C/corpus/knowledge/a.md"
printf '# x\n' > "$C/elsewhere/lessons/x.md"
{ echo '# README'; echo; echo '| Entry | Covers | Sources |'; echo '|---|---|---|';
  printf '%s\n' '| `knowledge/a.md` | d | p |' '| `lessons/x.md` | d | p |'; } > "$C/corpus/README.md"
printf '{"version":1,"covered":["knowledge/a.md","lessons/x.md"]}\n' > "$C/reg.json"
echo "----- E7b: --corpus outside lane (basename lessons), real lane lessons/b.md NOT supplied -----"
node "$GATE" --registry "$C/reg.json" --readme "$C/corpus/README.md" \
     --corpus "$C/corpus/knowledge" --corpus "$C/elsewhere/lessons"
echo "exit=$?"

# E9 — strace: traversal rows, canary resolvable from cwd; prove no open of any row path.
C=$ROOT/E9
mkdir -p "$C/corpus/knowledge" "$C/corpus/lessons"
printf '# a\n' > "$C/corpus/knowledge/a.md"
printf '# b\n' > "$C/corpus/lessons/b.md"
{ echo '# README'; echo; echo '| Entry | Covers | Sources |'; echo '|---|---|---|';
  printf '%s\n' \
    '| `knowledge/a.md` | d | p |' \
    '| `lessons/b.md` | d | p |' \
    '| `knowledge/../../../../canary/secret.md` | d | p |' \
    '| `knowledge/../../../../../../etc/passwd` | d | p |'; } > "$C/corpus/README.md"
printf '{"version":1,"covered":["knowledge/a.md","lessons/b.md"]}\n' > "$C/reg.json"
echo "----- E9: strace of the gate over traversal rows (cwd=$C/corpus) -----"
( cd "$C/corpus" && strace -f -qq -e trace=openat,open,stat,statx,newfstatat,readlink \
    -o "$B/02-strace.log" node "$GATE" --registry "$C/reg.json" --readme "$C/corpus/README.md" \
    --corpus "$C/corpus/knowledge" --corpus "$C/corpus/lessons"; echo "exit=$?" )
echo "--- strace lines mentioning canary: ---"
grep -c 'canary/secret.md' "$B/02-strace.log" || true
grep 'canary/secret.md' "$B/02-strace.log" || echo "(none)"
echo "--- strace lines mentioning /etc/passwd: ---"
grep -c '/etc/passwd' "$B/02-strace.log" || true
grep '/etc/passwd' "$B/02-strace.log" || echo "(none)"
echo "--- any open/stat of corpus *.md content (a.md/b.md): ---"
grep -E '(a|b)\.md' "$B/02-strace.log" || echo "(none)"
echo "--- line count: ---"; wc -l < "$B/02-strace.log"

# E10 — decoration classes before a backticked corpus path (format-unmapped reach).
C=$ROOT/E10
mkdir -p "$C/corpus/knowledge" "$C/corpus/lessons"
printf '# a\n' > "$C/corpus/knowledge/a.md"
printf '# b\n' > "$C/corpus/lessons/b.md"
printf '{"version":1,"covered":["knowledge/a.md","lessons/b.md"]}\n' > "$C/reg.json"
i=0
for cell in '``knowledge/gone.md``' '```knowledge/gone.md```' '*`knowledge/gone.md`*' '**`knowledge/gone.md`**' '_`knowledge/gone.md`_' '[`knowledge/gone.md`](x)' '`knowledge/gone.md`' 'knowledge/gone.md'; do
  i=$((i+1))
  { echo '# README'; echo; echo '| Entry | Covers | Sources |'; echo '|---|---|---|';
    printf '%s\n' '| `knowledge/a.md` | d | p |' '| `lessons/b.md` | d | p |' "| $cell | d | p |"; } > "$C/corpus/README.md"
  printf '%-32s ' "$cell"
  node "$GATE" --registry "$C/reg.json" --readme "$C/corpus/README.md" \
       --corpus "$C/corpus/knowledge" --corpus "$C/corpus/lessons" | tr '\n' ' '
  echo "exit=${PIPESTATUS[0]}"
done

#!/usr/bin/env bash
# SentinelArtifacts — round 57, C1 readme-map: crafted README row / namespace-escape probe.
# Scratch only. Gate is invoked read-only with explicit --registry/--readme/--corpus.
set -u
B=/home/vgpnk/Projects/shokunin/kumitate-shokunin/.ufo/waves/round-57/build/SentinelArtifacts
GATE=/home/vgpnk/Projects/shokunin/kumitate-shokunin/scripts/readme-map.mjs
ROOT=$B/fx
rm -rf "$ROOT" "$B/canary"
mkdir -p "$B/canary" "$ROOT"
printf '# canary\n' > "$B/canary/secret.md"

# fixture <case> <knowledge-file-names-csv> <lessons-file-names-csv> <rows-hex-or-file>
mk() { # mk <case>
  local c=$1
  mkdir -p "$ROOT/$c/corpus/knowledge" "$ROOT/$c/corpus/lessons"
  printf '# a\n'   > "$ROOT/$c/corpus/knowledge/a.md"
  printf '# b\n'   > "$ROOT/$c/corpus/lessons/b.md"
}

row_a='| `knowledge/a.md` | d | p |'
row_b='| `lessons/b.md` | d | p |'

run() { # run <case> <label>
  local c=$1 lbl=$2 d=$ROOT/$1
  echo "----- CASE $c : $lbl -----"
  echo "README bytes:"; cat "$d/corpus/README.md"
  echo "registry:"; cat "$d/reg.json" 2>/dev/null || echo "(absent)"
  node "$GATE" --registry "$d/reg.json" --readme "$d/corpus/README.md" \
       --corpus "$d/corpus/knowledge" --corpus "$d/corpus/lessons"
  echo "exit=$?"
}

reg() { printf '{"version":1,"covered":["knowledge/a.md","lessons/b.md"]}\n' > "$1/reg.json"; }
readme() { { echo '# README'; echo; echo '## Coverage map'; echo; echo '| Entry | Covers | Sources |'; echo '|---|---|---|'; printf '%s\n' "$@"; } > "$ROOT/$CASE/corpus/README.md"; }

# ---------- E0 clean baseline ----------
CASE=E0; mk E0; reg "$ROOT/E0"; readme "$row_a" "$row_b"
run E0 "clean baseline"

# ---------- E1 traversal row, dangling target, live files fully mapped ----------
CASE=E1; mk E1; reg "$ROOT/E1"
readme "$row_a" "$row_b" '| `knowledge/../../../../canary/secret.md` | d | p |'
run E1 "traversal row -> dangling outside corpus"

# ---------- E2 traversal row that normalizes onto a live corpus file ----------
CASE=E2; mk E2; reg "$ROOT/E2"
readme "$row_a" "$row_b" '| `knowledge/../knowledge/a.md` | d | p |'
run E2 "traversal spelling of an existing file"

# ---------- E2b same, but the normal row is deleted (does the traversal spelling cover it?) ----------
CASE=E2b; mk E2b; reg "$ROOT/E2b"
readme "$row_b" '| `knowledge/../knowledge/a.md` | d | p |'
run E2b "traversal row as the ONLY row for a.md"

# ---------- E3 leading double backtick, dangling path (silent-drop test) ----------
CASE=E3; mk E3; reg "$ROOT/E3"
readme "$row_a" "$row_b" '| ``knowledge/gone.md`` | d | p |'
run E3 "leading double-backtick dangling row"

# ---------- E3b leading double backtick on a LIVE file (coverage side) ----------
CASE=E3b; mk E3b; reg "$ROOT/E3b"
readme "$row_b" '| ``knowledge/a.md`` | d | p |'
run E3b "double-backtick row for live a.md, no normal row"

# ---------- E3c triple backtick dangling ----------
CASE=E3c; mk E3c; reg "$ROOT/E3c"
readme "$row_a" "$row_b" '| ```knowledge/gone.md``` | d | p |'
run E3c "triple-backtick dangling row"

# ---------- E3d trailing double backtick ----------
CASE=E3d; mk E3d; reg "$ROOT/E3d"
readme "$row_a" "$row_b" '| `knowledge/gone.md`` | d | p |'
run E3d "trailing double-backtick dangling row"

# ---------- E4 pipe inside the backticked cell ----------
CASE=E4; mk E4; reg "$ROOT/E4"
readme "$row_a" "$row_b" '| `knowledge/a.md | ../..` | d | p |'
run E4 "pipe smuggled inside backticks"

# ---------- E5 registry traversal entry ----------
CASE=E5; mk E5
printf '{"version":1,"covered":["knowledge/a.md","lessons/b.md","knowledge/../../../../canary/secret.md"]}\n' > "$ROOT/E5/reg.json"
readme "$row_a" "$row_b"
run E5 "registry covered entry with traversal"

# ---------- E6 registry dot-dot but inside namespace spelling ----------
CASE=E6; mk E6
printf '{"version":1,"covered":["knowledge/a.md","lessons/b.md","knowledge/../lessons/b.md"]}\n' > "$ROOT/E6/reg.json"
readme "$row_a" "$row_b"
run E6 "registry covered knowledge/../lessons/b.md"

# ---------- E7 operator --corpus outside the lane, basename lessons ----------
CASE=E7; mk E7; reg "$ROOT/E7"
mkdir -p "$B/fx/E7/elsewhere/lessons"
printf '# x\n' > "$B/fx/E7/elsewhere/lessons/x.md"
{ echo '# README'; printf '%s\n' "$row_a" "$row_b" '| `lessons/x.md` | d | p |'; } > "$ROOT/E7/corpus/README.md"
printf '{"version":1,"covered":["knowledge/a.md","lessons/b.md","lessons/x.md"]}\n' > "$ROOT/E7/reg.json"
echo "----- CASE E7 : --corpus points outside lane (basename lessons) -----"
node "$GATE" --registry "$ROOT/E7/reg.json" --readme "$ROOT/E7/corpus/README.md" \
     --corpus "$ROOT/E7/corpus/knowledge" --corpus "$B/fx/E7/elsewhere/lessons"
echo "exit=$?"

# ---------- E8 symlinked corpus dir ----------
CASE=E8; mk E8; reg "$ROOT/E8"; readme "$row_a" "$row_b"
ln -s "$ROOT/E8/corpus/knowledge" "$ROOT/E8/knowledge-link"
echo "----- CASE E8 : symlinked corpus dir (basename not knowledge) -----"
node "$GATE" --registry "$ROOT/E8/reg.json" --readme "$ROOT/E8/corpus/README.md" \
     --corpus "$ROOT/E8/knowledge-link" --corpus "$ROOT/E8/corpus/lessons"
echo "exit=$?"
ln -sfn "$ROOT/E8/corpus/knowledge" "$ROOT/E8/linkless/knowledge" 2>/dev/null || { mkdir -p "$ROOT/E8/linkless"; ln -sfn "$ROOT/E8/corpus/knowledge" "$ROOT/E8/linkless/knowledge"; }
echo "----- CASE E8b : symlink whose basename IS knowledge -----"
node "$GATE" --registry "$ROOT/E8/reg.json" --readme "$ROOT/E8/corpus/README.md" \
     --corpus "$ROOT/E8/linkless/knowledge" --corpus "$ROOT/E8/corpus/lessons"
echo "exit=$?"
